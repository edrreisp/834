#r "Newtonsoft.Json"
#r "Microsoft.Azure.Workflows.Scripting"

using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Workflows.Scripting;
using Newtonsoft.Json.Linq;

// Primera prueba: X12_OUTPUT_ROOT sin configurar => solo genera un .exp local.
// Publicacion: X12_OUTPUT_ROOT = directorio montado que contiene las carpetas PMC, etc.
public static async Task<Results> Run(WorkflowContext context, ILogger log)
{
    var clock = Stopwatch.StartNew();
    var traceId = Guid.NewGuid().ToString("N");
    var work = Path.Combine(Path.GetTempPath(), "x12-" + traceId);
    Directory.CreateDirectory(work);
    var xmlPath = Path.Combine(work, "transformed.xml");
    var expPath = Path.Combine(work, "result.exp");
    try
    {
        log.LogInformation("834: {TraceId} inicio.", traceId);
        var root = Environment.GetEnvironmentVariable("AzureWebJobsScriptRoot");
        if (string.IsNullOrWhiteSpace(root))
            root = Path.Combine(Environment.GetEnvironmentVariable("HOME") ?? "C:\\home", "site", "wwwroot");

        var trigger = (await context.GetTriggerResults().ConfigureAwait(false)).Outputs;
        var payload = trigger["body"];
        var company = Required(payload, "company").Trim().ToUpperInvariant();
        SafePart(company, "company");
        var mapPath = Path.Combine(root, "Artifacts", "Maps", "X12_834_Inbound_Mapping_" + company + ".xslt");
        var schemaPath = Path.Combine(root, "Artifacts", "Schemas", "EnrollmentRequestInbound.xsd");
        var layout = ReadLayout(schemaPath);
        var transform = new XslCompiledTransform();
        // StringReader evita el error de declaracion UTF-16 en un mapa guardado como UTF-8.
        using (var text = new StringReader(File.ReadAllText(mapPath)))
        using (var reader = XmlReader.Create(text, ReaderSettings()))
            transform.Load(reader, XsltSettings.Default, null);

        log.LogInformation("834: {TraceId} obteniendo Decode_X12.", traceId);
        var decode = (await context.GetActionResults("Decode_X12").ConfigureAwait(false)).Outputs;
        var groups = decode["body"]?["interchange"]?["functionalGroups"] as JArray;
        if (groups == null || groups.Count != 1)
            throw new InvalidOperationException("Este script requiere exactamente un grupo funcional.");
        var sets = groups[0]["transactionSets"] as JArray;
        if (sets == null || sets.Count != 1)
            throw new InvalidOperationException("Este script requiere exactamente un transaction set.");
        var base64 = sets[0]["transactionSetContent"]?["$content"]?.Value<string>();
        if (string.IsNullOrEmpty(base64)) throw new InvalidOperationException("Decode sin XML de transaccion.");
        // isFailedTransactionSet puede ser true aunque exista XML: se conserva el comportamiento
        // de las pruebas actuales. Corregir los errores EDI por separado antes de produccion.
        bool ediFailed = sets[0]["isFailedTransactionSet"]?.Value<bool>() ?? false;
        if (ediFailed) log.LogWarning("834: {TraceId} Decode reporta isFailedTransactionSet=true.", traceId);
        var bytes = Convert.FromBase64String(base64);
        long xmlBytes = bytes.LongLength;
        base64 = null;
        groups = null; sets = null; decode = null;

        log.LogInformation("834: {TraceId} iniciando XSLT. XML bytes={Bytes}.", traceId, xmlBytes);
        
        using (var probeStream = new MemoryStream(bytes, false))
        using (var probe = XmlReader.Create(probeStream, ReaderSettings()))
        {
            probe.MoveToContent();

            log.LogInformation("834: {TraceId} company={Company}; mapa={Map}; hashMapa={Hash}; raiz={Root}; namespace={Namespace}.",
            traceId,
            company,
            Path.GetFileName(mapPath),
            Hash(mapPath),
            probe.LocalName,
            probe.NamespaceURI);
        }
        var timer = Stopwatch.StartNew();
        using (var input = new MemoryStream(bytes, false))
        using (var reader = XmlReader.Create(input, ReaderSettings()))
        using (var output = new FileStream(xmlPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536))
        using (var writer = XmlWriter.Create(output, transform.OutputSettings))
            transform.Transform(reader, null, writer);
        double transformSeconds = timer.Elapsed.TotalSeconds;
        bytes = null;
        
        log.LogInformation("834: {TraceId} XML de salida: {Bytes} bytes.",traceId,new FileInfo(xmlPath).Length);
        
        log.LogInformation("834: {TraceId} XSLT terminado. Iniciando formato plano.", traceId);

        timer.Restart();
        var counts = EncodeFlat(xmlPath, expPath, layout, traceId, log);
        double flatSeconds = timer.Elapsed.TotalSeconds;
        long size = new FileInfo(expPath).Length;
        string hash = Hash(expPath);
        string outputPath = expPath;
        string mode = "ValidationLocal";

        var outputRoot = Environment.GetEnvironmentVariable("X12_OUTPUT_ROOT");
        if (!string.IsNullOrWhiteSpace(outputRoot))
        {
            // Misma regla del Compose_File_Name original (indices 3 y 4).
            var parts = Required(payload, "fileName").Split('_');
            if (parts.Length < 5 || parts[3].Length < 8)
                throw new InvalidOperationException("fileName no cumple el patron usado por Compose_File_Name.");
            var fileName = Required(payload, "companyCode") + parts[3].Substring(2, 6)
                + "_" + parts[4].Split('.')[0] + ".exp";
            SafePart(fileName, "nombre de salida");
            var folder = Path.Combine(outputRoot, company);
            if (!Directory.Exists(folder))
                throw new DirectoryNotFoundException("No existe o no es accesible la carpeta destino configurada.");
            outputPath = Path.Combine(folder, fileName);
            if (File.Exists(outputPath))
                throw new IOException("El archivo final ya existe; no se sobrescribe. Revisar duplicados o reintentos.");
            var pending = outputPath + "." + traceId + ".processing";
            try
            {
                log.LogInformation("834: {TraceId} copiando .exp a SMB.", traceId);
                using (var source = new FileStream(expPath, FileMode.Open, FileAccess.Read, FileShare.Read, 65536))
                using (var target = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536))
                    source.CopyTo(target, 65536);
                if (new FileInfo(pending).Length != size || Hash(pending) != hash)
                    throw new IOException("La verificacion del archivo copiado no coincide.");
                // Mismo directorio y sin sobrescribir: consumidores deben ignorar *.processing.
                File.Move(pending, outputPath);
            }
            catch
            {
                TryDelete(pending);
                throw;
            }
            mode = "PublishedSMB";
        }
        else
        {
            // Guardar la prueba en HOME permite descargarla desde Kudu.
            // TEMP es local al worker y puede no ser visible desde el sitio SCM.
            var validationRoot = Environment.GetEnvironmentVariable("X12_VALIDATION_ROOT");
            if (string.IsNullOrWhiteSpace(validationRoot))
                validationRoot = Path.Combine(Environment.GetEnvironmentVariable("HOME") ?? "C:\\home", "data", "x12-validation");
            Directory.CreateDirectory(validationRoot);
            outputPath = Path.Combine(validationRoot, traceId + ".all");
            File.Copy(expPath, outputPath, false);
        }

        log.LogInformation("834: {TraceId} completado. Members={Members}, Lines={Lines}, Bytes={Bytes}, Mode={Mode}.",
            traceId, counts.Members, counts.Lines, size, mode);
        return new Results {
            Status = "Completed", Mode = mode, TraceId = traceId,
            OutputPath = outputPath, OutputBytes = size, Sha256 = hash,
            MembersProcessed = counts.Members, RecordsWritten = counts.Lines,
            EdiTransactionFailed = ediFailed,
            TransformSeconds = transformSeconds, FlatFileSeconds = flatSeconds,
            TotalSeconds = clock.Elapsed.TotalSeconds
        };
    }
    catch (Exception ex)
    {
        // No registrar XML, valores de campos, SSN ni otra informacion de afiliados.
        log.LogError("834: {TraceId} fallo. Tipo={Type}; detalle={Detail}", traceId, ex.GetType().Name, ex.Message);
        throw;
    }
    finally
    {
        TryDelete(xmlPath);
        TryDelete(expPath);
        try { Directory.Delete(work); } catch { }
    }
}

public static XmlReaderSettings ReaderSettings()
{
    return new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
}

public static string Required(JToken body, string name)
{
    var value = body?[name]?.Value<string>();
    if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException("Falta " + name + " en el trigger.");
    return value;
}

public static void SafePart(string value, string name)
{
    foreach (char c in value)
        if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z') &&
            !(c >= '0' && c <= '9') && c != '_' && c != '-' && c != '.')
            throw new InvalidOperationException("Caracter no permitido en " + name + ".");
    if (value == "." || value == "..") throw new InvalidOperationException("Nombre no permitido.");
}

// Soporta especificamente el esquema EnrollmentRequestInbound proporcionado.
// No sustituye un validador XSD ni implementa todas las opciones de BizTalk.
public static FlatLayout ReadLayout(string path)
{
    var doc = new XmlDocument { XmlResolver = null };
    using (var reader = XmlReader.Create(path, ReaderSettings())) doc.Load(reader);
    var ns = new XmlNamespaceManager(doc.NameTable);
    ns.AddNamespace("x", "http://www.w3.org/2001/XMLSchema");
    ns.AddNamespace("b", "http://schemas.microsoft.com/BizTalk/2003");
    var info = doc.SelectSingleNode("/x:schema/x:annotation/x:appinfo/b:schemaInfo", ns) as XmlElement;
    if (info == null || info.GetAttribute("codepage") != "65001" ||
        info.GetAttribute("count_positions_by_byte") != "false" || info.GetAttribute("default_pad_char") != " ")
        throw new InvalidOperationException("Configuracion de esquema no soportada: requiere UTF-8, posiciones por caracter y relleno espacio.");
    var layout = new FlatLayout();
    layout.RootNamespace = doc.DocumentElement.GetAttribute("targetNamespace");
    var member = doc.SelectSingleNode("/x:schema/x:element[@name='Root']/x:complexType/x:sequence/x:element[@name='Member']", ns);
    if (member == null) throw new InvalidOperationException("No se encontro Root/Member en el XSD.");
    var delimiter = member.SelectSingleNode("x:annotation/x:appinfo/b:recordInfo", ns) as XmlElement;
    if (delimiter == null || delimiter.GetAttribute("child_order") != "postfix" ||
        delimiter.GetAttribute("child_delimiter") != "0xD 0xA")
        throw new InvalidOperationException("El esquema requiere un delimitador no soportado.");
    foreach (XmlElement record in member.SelectNodes("x:complexType/x:sequence/x:element", ns))
    {
        var spec = new RecordSpec { Name = record.GetAttribute("name"), Order = layout.Records.Count };
        var ri = record.SelectSingleNode("x:annotation/x:appinfo/b:recordInfo", ns) as XmlElement;
        if (ri == null || ri.GetAttribute("structure") != "positional")
            throw new InvalidOperationException("Registro no posicional no soportado.");
        foreach (XmlElement field in record.SelectNodes("x:complexType/x:sequence/x:element", ns))
        {
            var fi = field.SelectSingleNode("x:annotation/x:appinfo/b:fieldInfo", ns) as XmlElement;
            if (fi == null || fi.GetAttribute("justification") != "left" || fi.GetAttribute("pos_offset") != "0")
                throw new InvalidOperationException("Anotacion de campo no soportada.");
            int length;
            if (!int.TryParse(fi.GetAttribute("pos_length"), out length) || length <= 0)
                throw new InvalidOperationException("Longitud de campo invalida.");
            spec.Fields.Add(new FieldSpec { Name = field.GetAttribute("name"), Length = length });
            spec.Length += length;
        }
        if (spec.Fields.Count == 0 || spec.Length != 739)
            throw new InvalidOperationException("Se esperaba el esquema proporcionado: registros de 739 caracteres.");
        layout.Records.Add(spec);
    }
    if (layout.Records.Count != 5) throw new InvalidOperationException("Se esperaban cinco tipos de registro.");
    return layout;
}

public static FlatCounts EncodeFlat(string inputPath, string outputPath, FlatLayout layout, string traceId, ILogger log)
{
    var counts = new FlatCounts();
    using (var reader = XmlReader.Create(inputPath, ReaderSettings()))
    using (var file = new FileStream(outputPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536))
    using (var writer = new StreamWriter(file, new UTF8Encoding(false, true), 65536))
    {
        reader.MoveToContent();
        if (reader.LocalName != "Root" || reader.NamespaceURI != layout.RootNamespace || reader.IsEmptyElement)
            throw new InvalidOperationException("XML transformado sin Root esperado o vacio.");
        while (reader.Read())
        {
            if (reader.NodeType != XmlNodeType.Element) continue;
            if (reader.Depth != 1 || reader.LocalName != "Member")
                throw new InvalidOperationException("Elemento inesperado bajo Root.");
            var member = new XmlDocument { XmlResolver = null };
            // Solo se carga un Member; el XML completo no se convierte en string/DOM.
            using (var subtree = reader.ReadSubtree()) member.Load(subtree);
            counts.Members++;
            int lastOrder = -1;
            foreach (XmlNode node in member.DocumentElement.ChildNodes)
            {
                var record = node as XmlElement;
                if (record == null) continue;
                RecordSpec spec = null;
                foreach (var candidate in layout.Records)
                    if (candidate.Name == record.LocalName) { spec = candidate; break; }
                if (spec == null || spec.Order < lastOrder)
                    throw new InvalidOperationException("Registro desconocido o fuera de orden. Member=" + counts.Members);
                lastOrder = spec.Order;
                var values = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (XmlNode fieldNode in record.ChildNodes)
                {
                    var field = fieldNode as XmlElement;
                    if (field == null) continue;
                    bool known = false;
                    foreach (var expected in spec.Fields) if (expected.Name == field.LocalName) { known = true; break; }
                    if (!known || values.ContainsKey(field.LocalName))
                        throw new InvalidOperationException("Campo desconocido o duplicado en " + spec.Name);
                    values.Add(field.LocalName, field.InnerText);
                }
                foreach (var field in spec.Fields)
                {
                    string value;
                    if (!values.TryGetValue(field.Name, out value)) value = "";
                    if (value.IndexOf('\r') >= 0 || value.IndexOf('\n') >= 0 || value.IndexOf('\0') >= 0)
                        throw new InvalidOperationException("Caracter de control en Member=" + counts.Members + ", " + spec.Name + "/" + field.Name);
                    if (value.Length > field.Length)
                    {
                        log.LogWarning(
                                        "834: {TraceId} campo truncado. Member={Member}; " +
                                        "Registro={Record}; Campo={Field}; " +
                                        "LongitudOriginal={OriginalLength}; LongitudPermitida={AllowedLength}.",
                                        traceId,
                                        counts.Members,
                                        spec.Name,
                                        field.Name,
                                        value.Length,
                                        field.Length);
                                        
                        value = value.Substring(0, field.Length);
                
                }
                    writer.Write(value);
                    writer.Write(new string(' ', field.Length - value.Length));
                }
                writer.Write("\r\n");
                counts.Lines++;
            }
            if (counts.Members % 5000 == 0)
                log.LogInformation("834: {TraceId} plano: Members={Members}, Lines={Lines}.", traceId, counts.Members, counts.Lines);
        }
    }
    if (counts.Members == 0 || counts.Lines == 0) throw new InvalidOperationException("No se generaron registros.");
    return counts;
}

public static string Hash(string path)
{
    using (var sha = SHA256.Create())
    using (var file = File.OpenRead(path))
        return BitConverter.ToString(sha.ComputeHash(file)).Replace("-", "").ToLowerInvariant();
}
public static void TryDelete(string path) { try { if (File.Exists(path)) File.Delete(path); } catch { } }
public class FieldSpec { public string Name; public int Length; }
public class RecordSpec { public string Name; public int Order; public int Length; public List<FieldSpec> Fields = new List<FieldSpec>(); }
public class FlatLayout { public string RootNamespace; public List<RecordSpec> Records = new List<RecordSpec>(); }
public class FlatCounts { public long Members; public long Lines; }
public class Results
{
    public string Status { get; set; }
    public string Mode { get; set; }
    public string TraceId { get; set; }
    public string OutputPath { get; set; }
    public long OutputBytes { get; set; }
    public string Sha256 { get; set; }
    public long MembersProcessed { get; set; }
    public long RecordsWritten { get; set; }
    public bool EdiTransactionFailed { get; set; }
    public double TransformSeconds { get; set; }
    public double FlatFileSeconds { get; set; }
    public double TotalSeconds { get; set; }
}
 