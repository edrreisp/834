<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:s0="http://schemas.microsoft.com/BizTalk/EDI/X12/2006" version="1.0" exclude-result-prefixes="s0">
  <xsl:output method="xml" version="1.0" encoding="UTF-8" omit-xml-declaration="yes" indent="no"/>
  <xsl:template match="/">
    <xsl:apply-templates select="/s0:X12_00501_834"/>
  </xsl:template>
  <xsl:template match="/s0:X12_00501_834">
    <ns0:Root xmlns:ns0="http://IntegrationAccount.x005F_x0038_34.Inbound.EnrollmentRequestInbound">
      <xsl:variable name="processDateRaw" select="s0:BGN/BGN03"/>
      <xsl:variable name="processDate" select="concat(substring($processDateRaw,5,2), substring($processDateRaw,7,2), substring($processDateRaw,1,4))"/>
      <xsl:variable name="masterPolicy" select="s0:REF[REF01='38'][1]/REF02"/>
      <xsl:for-each select="s0:INSLoop1">
        <xsl:variable name="memberNM1Loop" select="s0:NM1Loop1[s0:NM1/NM101='IL' or s0:NM1/NM101='74'][1]"/>
        <xsl:variable name="memberNM1" select="$memberNM1Loop/s0:NM1"/>
        <xsl:variable name="contactNM1Loop" select="s0:NM1Loop1[s0:NM1/NM101='QD'][1]"/>
        <xsl:variable name="mailingNM1Loop" select="s0:NM1Loop1[s0:NM1/NM101='31'][1]"/>
        <xsl:variable name="personId" select="s0:REF_3[REF01='0F'][1]/REF02"/>
        <xsl:variable name="mbi" select="s0:REF_3[REF01='F6'][1]/REF02"/>
        <xsl:variable name="ssn" select="$memberNM1[NM108='34']/NM109"/>
        <xsl:variable name="memberLastRaw" select="$memberNM1/NM103"/>
        <xsl:variable name="contactLastRaw" select="$contactNM1Loop/s0:NM1/NM103"/>
        <xsl:variable name="eligBeginRaw" select="s0:DTP_3[DTP01='473'][1]/DTP03"/>
        <xsl:variable name="eligEndRaw" select="s0:DTP_3[DTP01='474'][1]/DTP03"/>
        <xsl:variable name="dobRaw" select="$memberNM1Loop/s0:DMG/DMG02"/>
        <xsl:variable name="deathRaw" select="s0:INS/INS12"/>
        <xsl:variable name="eligBegin" select="concat(substring($eligBeginRaw,5,2),substring($eligBeginRaw,7,2),substring($eligBeginRaw,1,4))"/>
        <xsl:variable name="eligEnd" select="concat(substring($eligEndRaw,5,2),substring($eligEndRaw,7,2),substring($eligEndRaw,1,4))"/>
        <xsl:variable name="dob" select="concat(substring($dobRaw,5,2),substring($dobRaw,7,2),substring($dobRaw,1,4))"/>
        <xsl:variable name="deathDate" select="concat(substring($deathRaw,5,2),substring($deathRaw,7,2),substring($deathRaw,1,4))"/>
        <xsl:variable name="hd01a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'01|')][1]"/>
        <xsl:variable name="hd01b" select="s0:HDLoop1[starts-with(s0:HD/HD04,'01|')][2]"/>
        <xsl:variable name="hd03a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'03|')][1]"/>
        <xsl:variable name="hd03b" select="s0:HDLoop1[starts-with(s0:HD/HD04,'03|')][2]"/>
        <xsl:variable name="hd05a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'05|')][1]"/>
        <xsl:variable name="hd05b" select="s0:HDLoop1[starts-with(s0:HD/HD04,'05|')][2]"/>
        <xsl:variable name="hd06a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'06|')][1]"/>
        <xsl:variable name="hd30a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'30|')][1]"/>
        <xsl:variable name="hd31a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'31|')][1]"/>
        <xsl:variable name="hd37a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'37|')][1]"/>
        <xsl:variable name="hd50a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'50|')][1]"/>
        <xsl:variable name="hd60a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'60|')][1]"/>
        <xsl:variable name="hd61a" select="s0:HDLoop1[starts-with(s0:HD/HD04,'61|')][1]"/>
        <xsl:variable name="carrierBeginRaw" select="$hd01a/s0:DTP_5[DTP01='348'][1]/DTP03"/>
        <xsl:variable name="carrierEndRaw" select="$hd01a/s0:DTP_5[DTP01='349'][1]/DTP03"/>
        <xsl:variable name="newCarrierBeginRaw" select="$hd01b/s0:DTP_5[DTP01='348'][1]/DTP03"/>
        <xsl:variable name="carrierBegin" select="concat(substring($carrierBeginRaw,5,2),substring($carrierBeginRaw,7,2),substring($carrierBeginRaw,1,4))"/>
        <xsl:variable name="carrierEnd" select="concat(substring($carrierEndRaw,5,2),substring($carrierEndRaw,7,2),substring($carrierEndRaw,1,4))"/>
        <xsl:variable name="newCarrierBegin" select="concat(substring($newCarrierBeginRaw,5,2),substring($newCarrierBeginRaw,7,2),substring($newCarrierBeginRaw,1,4))"/>
        <xsl:variable name="planType" select="substring-after($hd03a/s0:HD/HD04,'|')"/>
        <xsl:variable name="newPlanType" select="substring-after($hd03b/s0:HD/HD04,'|')"/>
        <xsl:variable name="planVersion" select="substring-after($hd05a/s0:HD/HD04,'|')"/>
        <xsl:variable name="newPlanVersion" select="substring-after($hd05b/s0:HD/HD04,'|')"/>
        <xsl:variable name="region" select="substring-after($hd06a/s0:HD/HD04,'|')"/>
        <xsl:variable name="coverageCode" select="substring-after($hd30a/s0:HD/HD04,'|')"/>
        <xsl:variable name="governmentGroup" select="substring-after($hd31a/s0:HD/HD04,'|')"/>
        <xsl:variable name="confinedCoverage" select="substring-after($hd37a/s0:HD/HD04,'|')"/>
        <xsl:variable name="rateCode" select="substring-after($hd50a/s0:HD/HD04,'|')"/>
        <xsl:variable name="rawRiskRaw" select="substring-after($hd60a/s0:HD/HD04,'|')"/>
        <xsl:variable name="riskRaw" select="substring-after($hd61a/s0:HD/HD04,'|')"/>
        <xsl:variable name="pcp1a" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PCP1'])[1]"/>
        <xsl:variable name="pcp1b" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PCP1'])[2]"/>
        <xsl:variable name="pcp2a" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PCP2'])[1]"/>
        <xsl:variable name="pcp2b" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PCP2'])[2]"/>
        <xsl:variable name="pmg1a" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PMG1'])[1]"/>
        <xsl:variable name="pmg1b" select="(s0:HDLoop1/s0:LXLoop1[s0:NM1_2/NM106='PMG1'])[2]"/>
        <xsl:variable name="pcp1EffRaw" select="$pcp1a/s0:PLA/PLA03"/>
        <xsl:variable name="pcp1NewEffRaw" select="$pcp1b/s0:PLA/PLA03"/>
        <xsl:variable name="pcp2EffRaw" select="$pcp2a/s0:PLA/PLA03"/>
        <xsl:variable name="pcp2NewEffRaw" select="$pcp2b/s0:PLA/PLA03"/>
        <xsl:variable name="pmgEffRaw" select="$pmg1a/s0:PLA/PLA03"/>
        <xsl:variable name="newPmgEffRaw" select="$pmg1b/s0:PLA/PLA03"/>
        <xsl:variable name="pcp1Eff" select="concat(substring($pcp1EffRaw,5,2),substring($pcp1EffRaw,7,2),substring($pcp1EffRaw,1,4))"/>
        <xsl:variable name="pcp1NewEff" select="concat(substring($pcp1NewEffRaw,5,2),substring($pcp1NewEffRaw,7,2),substring($pcp1NewEffRaw,1,4))"/>
        <xsl:variable name="pcp2Eff" select="concat(substring($pcp2EffRaw,5,2),substring($pcp2EffRaw,7,2),substring($pcp2EffRaw,1,4))"/>
        <xsl:variable name="pcp2NewEff" select="concat(substring($pcp2NewEffRaw,5,2),substring($pcp2NewEffRaw,7,2),substring($pcp2NewEffRaw,1,4))"/>
        <xsl:variable name="pmgEff" select="concat(substring($pmgEffRaw,5,2),substring($pmgEffRaw,7,2),substring($pmgEffRaw,1,4))"/>
        <xsl:variable name="newPmgEff" select="concat(substring($newPmgEffRaw,5,2),substring($newPmgEffRaw,7,2),substring($newPmgEffRaw,1,4))"/>
        <xsl:variable name="additionalRef" select="string(s0:LSLoop1/s0:LXLoop2/s0:N1Loop2[s0:N1_4/N101='75'][1]/s0:REF_11[REF01='ZZ'][1]/REF02)"/>
        <xsl:variable name="afterAdditional1" select="substring-after($additionalRef,'|')"/>
        <xsl:variable name="previousTP" select="substring-before($afterAdditional1,'|')"/>
        <xsl:variable name="afterAdditional2" select="substring-after($afterAdditional1,'|')"/>
        <xsl:variable name="futureTP" select="substring-before($afterAdditional2,'|')"/>
        <xsl:variable name="currentTP">
          <xsl:choose>
            <xsl:when test="normalize-space($previousTP) != ''">
              <xsl:value-of select="normalize-space($previousTP)"/>
            </xsl:when>
            <xsl:otherwise>
              <xsl:value-of select="$masterPolicy"/>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:variable>
        <xsl:variable name="carrierCode">
          <xsl:choose>
            <xsl:when test="string($currentTP)='690150'">09</xsl:when>
            <xsl:when test="string($currentTP)='690350'">10</xsl:when>
            <xsl:when test="string($currentTP)='690900'">12</xsl:when>
            <xsl:when test="string($currentTP)='690450'">13</xsl:when>
            <xsl:when test="string($currentTP)='690320'">29</xsl:when>
            <xsl:when test="string($currentTP)='690330'">33</xsl:when>
            <xsl:when test="string($currentTP)='690800'">34</xsl:when>
            <xsl:when test="string($currentTP)='690700'">42</xsl:when>
            <xsl:when test="string($currentTP)='690410'">46</xsl:when>
            <xsl:otherwise/>
          </xsl:choose>
        </xsl:variable>
        <xsl:variable name="newCarrierCode">
          <xsl:choose>
            <xsl:when test="normalize-space($futureTP)='690150'">09</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690350'">10</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690900'">12</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690450'">13</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690320'">29</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690330'">33</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690800'">34</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690700'">42</xsl:when>
            <xsl:when test="normalize-space($futureTP)='690410'">46</xsl:when>
            <xsl:otherwise/>
          </xsl:choose>
        </xsl:variable>
        <xsl:variable name="cancelCode">
          <xsl:choose>
            <xsl:when test="s0:INS/INS03 != '024'"/>
            <xsl:when test="s0:INS/INS04='03' or s0:INS/INS04='3'">08</xsl:when>
            <xsl:when test="s0:INS/INS04='14'">31</xsl:when>
            <xsl:otherwise>30</xsl:otherwise>
          </xsl:choose>
        </xsl:variable>
        <Member>
          <MemberFirstSegment>
            <RecordType>F</RecordType>
            <TransactionId>E</TransactionId>
            <ProcessDate>
              <xsl:value-of select="$processDate"/>
            </ProcessDate>
            <SSN>
              <xsl:value-of select="$ssn"/>
            </SSN>
            <FILLER>00</FILLER>
            <FILLER1/>
            <PersonId>
              <xsl:value-of select="$personId"/>
            </PersonId>
            <ContactLastName>
              <xsl:choose>
                <xsl:when test="contains($contactLastRaw,'|')">
                  <xsl:value-of select="normalize-space(substring-before($contactLastRaw,'|'))"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="normalize-space($contactLastRaw)"/>
                </xsl:otherwise>
              </xsl:choose>
            </ContactLastName>
            <ContactSecondLastName>
              <xsl:choose>
                <xsl:when test="contains($contactLastRaw,'|')">
                  <xsl:value-of select="normalize-space(substring-after($contactLastRaw,'|'))"/>
                </xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </ContactSecondLastName>
            <ContactFirstName>
              <xsl:value-of select="$contactNM1Loop/s0:NM1/NM104"/>
            </ContactFirstName>
            <Region>
              <xsl:value-of select="$region"/>
            </Region>
            <Municipality>0000</Municipality>
            <Facility>0000</Facility>
            <FILLER2/>
            <FILLER3/>
            <EligibilityEffectiveDate>
              <xsl:value-of select="$eligBegin"/>
            </EligibilityEffectiveDate>
            <FILLER4/>
            <FILLER5/>
            <ExpirationDate>
              <xsl:value-of select="$eligEnd"/>
            </ExpirationDate>
            <FILLER6/>
            <MailingAddress1>
              <xsl:choose>
                <xsl:when test="count($mailingNM1Loop) &gt; 0">
                  <xsl:value-of select="$mailingNM1Loop/s0:N3_3/N301"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$memberNM1Loop/s0:N3_3/N301"/>
                </xsl:otherwise>
              </xsl:choose>
            </MailingAddress1>
            <MailingAddress2>
              <xsl:choose>
                <xsl:when test="count($mailingNM1Loop) &gt; 0">
                  <xsl:value-of select="$mailingNM1Loop/s0:N3_3/N302"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$memberNM1Loop/s0:N3_3/N302"/>
                </xsl:otherwise>
              </xsl:choose>
            </MailingAddress2>
            <MailingCity>
              <xsl:choose>
                <xsl:when test="count($mailingNM1Loop) &gt; 0">
                  <xsl:value-of select="$mailingNM1Loop/s0:N4_3/N401"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$memberNM1Loop/s0:N4_3/N401"/>
                </xsl:otherwise>
              </xsl:choose>
            </MailingCity>
            <MailingZIP>
              <xsl:choose>
                <xsl:when test="count($mailingNM1Loop) &gt; 0">
                  <xsl:value-of select="substring($mailingNM1Loop/s0:N4_3/N403,1,5)"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="substring($memberNM1Loop/s0:N4_3/N403,1,5)"/>
                </xsl:otherwise>
              </xsl:choose>
            </MailingZIP>
            <MailingZIP4>
              <xsl:variable name="mz">
                <xsl:choose>
                  <xsl:when test="count($mailingNM1Loop) &gt; 0">
                    <xsl:value-of select="$mailingNM1Loop/s0:N4_3/N403"/>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:value-of select="$memberNM1Loop/s0:N4_3/N403"/>
                  </xsl:otherwise>
                </xsl:choose>
              </xsl:variable>
              <xsl:choose>
                <xsl:when test="string-length(string($mz)) &gt; 5">
                  <xsl:value-of select="substring(string($mz),6,4)"/>
                </xsl:when>
                <xsl:when test="string-length(string($mz)) &gt; 0">9998</xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </MailingZIP4>
            <ResidenceAddress1>
              <xsl:value-of select="$memberNM1Loop/s0:N3_3/N301"/>
            </ResidenceAddress1>
            <ResidenceAddress2>
              <xsl:value-of select="$memberNM1Loop/s0:N3_3/N302"/>
            </ResidenceAddress2>
            <ResidenceCity>
              <xsl:value-of select="$memberNM1Loop/s0:N4_3/N401"/>
            </ResidenceCity>
            <ResidenceZip>
              <xsl:value-of select="substring($memberNM1Loop/s0:N4_3/N403,1,5)"/>
            </ResidenceZip>
            <ResidenceZip4>
              <xsl:choose>
                <xsl:when test="string-length($memberNM1Loop/s0:N4_3/N403) &gt; 5">
                  <xsl:value-of select="substring($memberNM1Loop/s0:N4_3/N403,6,4)"/>
                </xsl:when>
                <xsl:when test="string-length($memberNM1Loop/s0:N4_3/N403) &gt; 0">9998</xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </ResidenceZip4>
            <CommunicationNumber>
              <xsl:choose>
                <xsl:when test="$memberNM1Loop/s0:PER_3/PER03='TE'">
                  <xsl:value-of select="$memberNM1Loop/s0:PER_3/PER04"/>
                </xsl:when>
                <xsl:when test="$memberNM1Loop/s0:PER_3/PER05='TE'">
                  <xsl:value-of select="$memberNM1Loop/s0:PER_3/PER06"/>
                </xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </CommunicationNumber>
            <FILLER7/>
            <FILLER8/>
            <FILLER9/>
            <FILLER10/>
            <FILLER11/>
            <FILLER12/>
            <FILLER13/>
            <FILLER14/>
            <FILLER15/>
            <FILLER16/>
            <FILLER17/>
            <FILLER18/>
            <EligibleMembers>0</EligibleMembers>
            <CancellationorTerminationCode>
              <xsl:value-of select="string($cancelCode)"/>
            </CancellationorTerminationCode>
            <CarrierCode>
              <xsl:value-of select="string($carrierCode)"/>
            </CarrierCode>
            <CarrierEffectiveDate>
              <xsl:value-of select="$carrierBegin"/>
            </CarrierEffectiveDate>
            <CarrierEndDate>
              <xsl:value-of select="$carrierEnd"/>
            </CarrierEndDate>
            <FILLER19/>
            <FILLER20/>
            <PMGFederalTaxId/>
            <NewCarrier>
              <xsl:value-of select="string($newCarrierCode)"/>
            </NewCarrier>
            <NewPMGFederalTaxId/>
            <NewPMGEffectiveDate>
              <xsl:value-of select="$newPmgEff"/>
            </NewPMGEffectiveDate>
            <PolicyNumber>
              <xsl:value-of select="$masterPolicy"/>
            </PolicyNumber>
            <FILLER21/>
            <NewCarrierEffectiveDate>
              <xsl:value-of select="$newCarrierBegin"/>
            </NewCarrierEffectiveDate>
            <PMGEffectiveDate>
              <xsl:value-of select="$pmgEff"/>
            </PMGEffectiveDate>
            <CertificationDate/>
            <PCPChangeReason>
              <xsl:choose>
                <xsl:when test="normalize-space($pcp1a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pcp1a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:when test="normalize-space($pmg1a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pmg1a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:when test="normalize-space($pcp2a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pcp2a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </PCPChangeReason>
            <FILLER22/>
            <FILLER23/>
            <FILLER24/>
            <CaseNumber/>
            <ExtensionorCancellationDate/>
            <FILLER25/>
            <FILLER26/>
            <Gender>
              <xsl:choose>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG03='M'">1</xsl:when>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG03='F'">2</xsl:when>
                <xsl:otherwise>3</xsl:otherwise>
              </xsl:choose>
            </Gender>
            <NewIdCardIssueDate/>
            <MemberStartDate>
              <xsl:value-of select="$carrierBegin"/>
            </MemberStartDate>
            <FILLER27/>
          </MemberFirstSegment>
          <MemberSecondSegment>
            <RecordType>M</RecordType>
            <TransactionId>E</TransactionId>
            <ProcessDate>
              <xsl:value-of select="$processDate"/>
            </ProcessDate>
            <SSN>
              <xsl:value-of select="$ssn"/>
            </SSN>
            <FILLER>00</FILLER>
            <FILLER1/>
            <FILLER2>
              <xsl:value-of select="$ssn"/>
            </FILLER2>
            <FILLER3>01</FILLER3>
            <ContactPersonId>
              <xsl:value-of select="$contactNM1Loop/s0:NM1/NM109"/>
            </ContactPersonId>
            <FILLER4/>
            <LastName>
              <xsl:choose>
                <xsl:when test="contains($memberLastRaw,'|')">
                  <xsl:value-of select="normalize-space(substring-before($memberLastRaw,'|'))"/>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="normalize-space($memberLastRaw)"/>
                </xsl:otherwise>
              </xsl:choose>
            </LastName>
            <SecondLastName>
              <xsl:choose>
                <xsl:when test="contains($memberLastRaw,'|')">
                  <xsl:value-of select="normalize-space(substring-after($memberLastRaw,'|'))"/>
                </xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </SecondLastName>
            <FirstName>
              <xsl:value-of select="$memberNM1/NM104"/>
            </FirstName>
            <MiddleInitial>
              <xsl:value-of select="substring($memberNM1/NM105,1,1)"/>
            </MiddleInitial>
            <FILLER5>0</FILLER5>
            <DateOfBirth>
              <xsl:value-of select="$dob"/>
            </DateOfBirth>
            <FILLER6>0</FILLER6>
            <Sex>
              <xsl:choose>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG03='M'">1</xsl:when>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG03='F'">2</xsl:when>
                <xsl:otherwise>3</xsl:otherwise>
              </xsl:choose>
            </Sex>
            <FILLER7>0</FILLER7>
            <FILLER8>0</FILLER8>
            <FILLER9>0</FILLER9>
            <FILLER10/>
            <SocialSecurityBenefits/>
            <FILLER11/>
            <FILLER12>00</FILLER12>
            <FILLER13>0</FILLER13>
            <FILLER14>0</FILLER14>
            <FILLER15>0</FILLER15>
            <FILLER16>0</FILLER16>
            <MaritalStatusCode>
              <xsl:choose>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG04='I'">1</xsl:when>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG04='M'">2</xsl:when>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG04='D'">3</xsl:when>
                <xsl:when test="$memberNM1Loop/s0:DMG/DMG04='W'">4</xsl:when>
                <xsl:otherwise>5</xsl:otherwise>
              </xsl:choose>
            </MaritalStatusCode>
            <FILLER17/>
            <PregnancyIndicator/>
            <FILLER18/>
            <MBI>
              <xsl:value-of select="$mbi"/>
            </MBI>
            <FILLER19>0</FILLER19>
            <FILLER20>0</FILLER20>
            <FILLER21>0</FILLER21>
            <EligibilityIndicator>Y</EligibilityIndicator>
            <CancellationCode>
              <xsl:value-of select="string($cancelCode)"/>
            </CancellationCode>
            <FILLER22/>
            <PMGNPI>
              <xsl:value-of select="$pmg1a/s0:NM1_2/NM109"/>
            </PMGNPI>
            <NewPMGNPI>
              <xsl:value-of select="$pmg1b/s0:NM1_2/NM109"/>
            </NewPMGNPI>
            <PMGMedicaidId>
              <xsl:value-of select="$pmg1a/s0:NM1_2/NM105"/>
            </PMGMedicaidId>
            <NewPMGMedicaidId>
              <xsl:value-of select="$pmg1b/s0:NM1_2/NM105"/>
            </NewPMGMedicaidId>
            <FILLER23/>
            <GovernmentGroup/>
            <PersonId>
              <xsl:value-of select="$personId"/>
            </PersonId>
            <FILLER24/>
            <FILLER25/>
            <MPI>
              <xsl:value-of select="concat('00',$personId)"/>
            </MPI>
            <CertificationDate/>
            <PolicyNumber>
              <xsl:value-of select="$masterPolicy"/>
            </PolicyNumber>
            <PMGCode/>
            <PMGEffectiveDate>
              <xsl:value-of select="$pmgEff"/>
            </PMGEffectiveDate>
            <NewPMGCode/>
            <NewPMGEffectiveDate>
              <xsl:value-of select="$newPmgEff"/>
            </NewPMGEffectiveDate>
            <PCP>
              <xsl:value-of select="$pcp1a/s0:NM1_2/NM109"/>
            </PCP>
            <PCPEffectiveDate>
              <xsl:value-of select="$pcp1Eff"/>
            </PCPEffectiveDate>
            <SecondPCP>
              <xsl:value-of select="$pcp2a/s0:NM1_2/NM109"/>
            </SecondPCP>
            <SecondPCPEffectiveDate>
              <xsl:value-of select="$pcp2Eff"/>
            </SecondPCPEffectiveDate>
            <NewPCP>
              <xsl:value-of select="$pcp1b/s0:NM1_2/NM109"/>
            </NewPCP>
            <NewPCPEffectiveDate>
              <xsl:value-of select="$pcp1NewEff"/>
            </NewPCPEffectiveDate>
            <NewSecondPCP>
              <xsl:value-of select="$pcp2b/s0:NM1_2/NM109"/>
            </NewSecondPCP>
            <NewSecondPCPEffectiveDate>
              <xsl:value-of select="$pcp2NewEff"/>
            </NewSecondPCPEffectiveDate>
            <FILLER26/>
            <IdCardIssueDate/>
            <FILLER27/>
            <PrimaryCareChangeReason>
              <xsl:choose>
                <xsl:when test="normalize-space($pcp1a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pcp1a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:when test="normalize-space($pmg1a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pmg1a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:when test="normalize-space($pcp2a/s0:PLA/PLA05)!=''">
                  <xsl:value-of select="$pcp2a/s0:PLA/PLA05"/>
                </xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </PrimaryCareChangeReason>
            <Program>
              <xsl:choose>
                <xsl:when test="starts-with($coverageCode,'1')">1</xsl:when>
                <xsl:when test="starts-with($coverageCode,'2')">2</xsl:when>
                <xsl:when test="starts-with($coverageCode,'3')">3</xsl:when>
                <xsl:otherwise/>
              </xsl:choose>
            </Program>
            <FILLER28/>
            <Carrier>
              <xsl:value-of select="string($carrierCode)"/>
            </Carrier>
            <CarrierEffectiveDate>
              <xsl:value-of select="$carrierBegin"/>
            </CarrierEffectiveDate>
            <NewCarrier>
              <xsl:value-of select="string($newCarrierCode)"/>
            </NewCarrier>
            <NewCarrierEffectiveDate>
              <xsl:value-of select="$newCarrierBegin"/>
            </NewCarrierEffectiveDate>
            <PlanType>
              <xsl:value-of select="$planType"/>
            </PlanType>
            <PlanTypeEffectiveDate>
              <xsl:value-of select="$carrierBegin"/>
            </PlanTypeEffectiveDate>
            <PlanVersion>
              <xsl:value-of select="$planVersion"/>
            </PlanVersion>
            <PlanVersionEffectiveDate>
              <xsl:value-of select="$carrierBegin"/>
            </PlanVersionEffectiveDate>
            <NewPlanType>
              <xsl:value-of select="$newPlanType"/>
            </NewPlanType>
            <NewPlanTypeEffectiveDate>
              <xsl:value-of select="$newCarrierBegin"/>
            </NewPlanTypeEffectiveDate>
            <NewPlanVersion>
              <xsl:value-of select="$newPlanVersion"/>
            </NewPlanVersion>
            <NewPlanVersionEffectiveDate>
              <xsl:value-of select="$newCarrierBegin"/>
            </NewPlanVersionEffectiveDate>
            <FILLER29/>
            <FILLER30/>
            <FILLER31/>
            <FILLER32/>
            <ConfinedCoverageCode>
              <xsl:value-of select="$confinedCoverage"/>
            </ConfinedCoverageCode>
            <CoverageCode>
              <xsl:value-of select="$coverageCode"/>
            </CoverageCode>
            <NewPolicyNumber/>
            <SpecialEnroll/>
            <CostSharingExceptionCode/>
            <Co-PaymentMaximum/>
            <ExtensionFlag/>
            <SpendDownIndicator/>
            <EligibilityGroup>
              <xsl:value-of select="s0:HDLoop1/s0:COBLoop1/s0:REF_5[REF01='6P'][1]/REF02"/>
            </EligibilityGroup>
            <DateofDeath>
              <xsl:value-of select="$deathDate"/>
            </DateofDeath>
            <CustomProperty1>
              <xsl:value-of select="$carrierEnd"/>
            </CustomProperty1>
            <CustomProperty2/>
            <CustomProperty3/>
            <CustomProperty4/>
            <LanguageSpoken>
              <xsl:value-of select="$memberNM1Loop/s0:LUI[LUI01='LE' and LUI04='7'][1]/LUI02"/>
            </LanguageSpoken>
            <LanguageWritten>
              <xsl:value-of select="$memberNM1Loop/s0:LUI[LUI01='LE' and LUI04='6'][1]/LUI02"/>
            </LanguageWritten>
            <Race>
              <xsl:value-of select="$memberNM1Loop/s0:DMG/s0:C056/C05601"/>
            </Race>
            <Ethnicity>
              <xsl:value-of select="$memberNM1Loop/s0:DMG/s0:C056/C05603"/>
            </Ethnicity>
            <FILLER33/>
          </MemberSecondSegment>
          <Household>
            <RecordType>O</RecordType>
            <TransactionId>E</TransactionId>
            <ProcessDate>
              <xsl:value-of select="$processDate"/>
            </ProcessDate>
            <PersonId>
              <xsl:value-of select="$personId"/>
            </PersonId>
            <Household_x0020_Person_x0020_1/>
            <Household_x0020_Person_x0020_2/>
            <Household_x0020_Person_x0020_3/>
            <Household_x0020_Person_x0020_4/>
            <Household_x0020_Person_x0020_5/>
            <Household_x0020_Person_x0020_6/>
            <Household_x0020_Person_x0020_7/>
            <Household_x0020_Person_x0020_8/>
            <Household_x0020_Person_x0020_9/>
            <Household_x0020_Person_x0020_10/>
            <Household_x0020_Person_x0020_11/>
            <Household_x0020_Person_x0020_12/>
            <Household_x0020_Person_x0020_13/>
            <Household_x0020_Person_x0020_14/>
            <Household_x0020_Person_x0020_15/>
            <Household_x0020_Person_x0020_16/>
            <Household_x0020_Person_x0020_17/>
            <Household_x0020_Person_x0020_18/>
            <FILLER/>
          </Household>
          <xsl:for-each select="s0:HDLoop1/s0:COBLoop1">
            <xsl:variable name="insurer" select="s0:NM1Loop2[s0:NM1_3/NM101='IN'][1]/s0:NM1_3"/>
            <xsl:variable name="policyBeginRaw" select="s0:DTP_7[DTP01='344'][1]/DTP03"/>
            <xsl:variable name="policyEndRaw" select="s0:DTP_7[DTP01='345'][1]/DTP03"/>
            <InsuranceCOB>
              <RecordType>I</RecordType>
              <TransactionId>E</TransactionId>
              <ProcesDate>
                <xsl:value-of select="$processDate"/>
              </ProcesDate>
              <PersonId>
                <xsl:value-of select="$personId"/>
              </PersonId>
              <FILLER>01</FILLER>
              <HealthInsurerCode>
                <xsl:choose>
                  <xsl:when test="normalize-space($insurer/NM109) != ''">
                    <xsl:value-of select="substring(normalize-space($insurer/NM109),1,3)"/>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:value-of select="substring(normalize-space($insurer/NM103),1,3)"/>
                  </xsl:otherwise>
                </xsl:choose>
              </HealthInsurerCode>
              <PolicyNumber>
                <xsl:value-of select="s0:COB/COB02"/>
              </PolicyNumber>
              <PolicyEndDate>
                <xsl:value-of select="concat(substring($policyEndRaw,5,2),substring($policyEndRaw,7,2),substring($policyEndRaw,1,4))"/>
              </PolicyEndDate>
              <CoveredServices>
                <xsl:value-of select="s0:COB/COB04"/>
              </CoveredServices>
              <PolicyEffectiveDate>
                <xsl:value-of select="concat(substring($policyBeginRaw,5,2),substring($policyBeginRaw,7,2),substring($policyBeginRaw,1,4))"/>
              </PolicyEffectiveDate>
              <FILLER1/>
            </InsuranceCOB>
          </xsl:for-each>
          <RateCellRiskScore>
            <RecordType>R</RecordType>
            <TransactionId>E</TransactionId>
            <ProcessDate>
              <xsl:value-of select="$processDate"/>
            </ProcessDate>
            <PersonId>
              <xsl:value-of select="$personId"/>
            </PersonId>
            <FILLER/>
            <RateCode>
              <xsl:value-of select="$rateCode"/>
            </RateCode>
            <RiskScore>
              <xsl:if test="normalize-space($riskRaw) != ''">
                <xsl:value-of select="format-number(number($riskRaw),'000.0000')"/>
              </xsl:if>
            </RiskScore>
            <RiskScoreIndicator>1</RiskScoreIndicator>
            <RawRiskScore>
              <xsl:if test="normalize-space($rawRiskRaw) != ''">
                <xsl:value-of select="format-number(number($rawRiskRaw),'000.0000')"/>
              </xsl:if>
            </RawRiskScore>
            <EffectiveDate>00000000</EffectiveDate>
            <EndDate/>
            <FILLER1/>
          </RateCellRiskScore>
        </Member>
      </xsl:for-each>
    </ns0:Root>
  </xsl:template>
</xsl:stylesheet>
