"""Prueba local XSLT 1.0 con datos sinteticos. No llama a Azure.

Requiere Python 3 y lxml. Uso desde cualquier directorio:
    python validar.py
    python validar.py --resultados /ruta/Resultados18nov.zip

La opcion --resultados solo compara los EXP de PMC con las plantillas
defectuosas del mapa original. No imprime ni copia datos de afiliados.
No reemplaza una prueba con Decode_X12 y los conectores de Azure.
"""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

from lxml import etree


HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent
NS = {
    "xs": "http://www.w3.org/2001/XMLSchema",
    "b": "http://schemas.microsoft.com/BizTalk/2003",
}
EXPECTED = {
    "MemberFirstSegment/ProcessDate": "10292026",
    "MemberFirstSegment/PersonId": "TEST1234567",
    "MemberFirstSegment/CarrierCode": "33",
    "MemberFirstSegment/PolicyNumber": "690330",
    "MemberFirstSegment/CancellationorTerminationCode": "",
    "MemberSecondSegment/FirstName": "TESTFIRST",
    "MemberSecondSegment/LastName": "TESTLAST",
    "MemberSecondSegment/DateOfBirth": "01021990",
    "MemberSecondSegment/Sex": "1",
    "MemberSecondSegment/Ethnicity": "E1^E2",
    "InsuranceCOB/HealthInsurerCode": "123",
    "InsuranceCOB/PolicyNumber": "TESTPOLICY",
    "RateCellRiskScore/RateCode": "TEST",
    "RateCellRiskScore/RiskScore": "001.7500",
    "RateCellRiskScore/RawRiskScore": "001.2500",
}


def load_xml(path):
    return etree.parse(str(path), etree.XMLParser(resolve_entities=False, no_network=True))


def make_layout(schema):
    result = {}
    records = schema.xpath(
        "//xs:element[@name='Member']/xs:complexType/xs:sequence/xs:element",
        namespaces=NS,
    )
    for record in records:
        fields = []
        for field in record.xpath("xs:complexType/xs:sequence/xs:element", namespaces=NS):
            info = field.find("xs:annotation/xs:appinfo/b:fieldInfo", NS)
            fields.append((field.get("name"), int(info.get("pos_length"))))
        assert sum(length for _, length in fields) == 739
        result[record.get("name")] = fields
    assert len(result) == 5
    return result


def original_templates(result, layout):
    templates = {}
    for record in result.getroot().find("Member"):
        text = "".join(
            (record.findtext(name) or "")[:length].ljust(length)
            for name, length in layout[record.tag]
        ) + "\r\n"
        templates[text[:2]] = text.encode("utf-8")
    return templates


def run(resultados=None):
    source = load_xml(HERE / "entrada_sintetica.xml")
    schema_doc = load_xml(HERE / "EnrollmentRequestInbound.xsd")
    schema = etree.XMLSchema(schema_doc)
    old = etree.XSLT(load_xml(HERE / "PMC_original_solo_para_prueba.xslt"))(source)
    new = etree.XSLT(load_xml(PACKAGE / "X12_834_Inbound_Mapping_PMC.xslt"))(source)

    for result in (old, new):
        assert schema.validate(result), str(schema.error_log)
        assert len(result.getroot().findall("Member")) == 1
        assert [r.findtext("RecordType") for r in result.getroot().find("Member")] == [
            "F", "M", "O", "I", "R"
        ]

    actual = {key: new.getroot().findtext("Member/" + key) or "" for key in EXPECTED}
    assert actual == EXPECTED, "El mapa corregido no recupero todos los valores sinteticos."
    for key in (
        "MemberFirstSegment/ProcessDate", "MemberFirstSegment/PersonId",
        "MemberSecondSegment/FirstName", "InsuranceCOB/PolicyNumber",
    ):
        assert not old.getroot().findtext("Member/" + key)
    assert old.getroot().findtext("Member/MemberSecondSegment/CancellationCode") == "30"

    templates = original_templates(old, make_layout(schema_doc))
    report = {
        "engine": "lxml/libxslt, XSLT 1.0; no Azure or .NET execution",
        "input": "Synthetic XML; containers qualified and data elements unqualified",
        "original_and_corrected_xml_both_pass_xsd": True,
        "corrected_synthetic_expected_fields_pass": True,
        "synthetic_values_after_correction": actual,
        "original_template_sha256": {k: sha256(v).hexdigest() for k, v in templates.items()},
        "real_pmc_exp_files": [],
    }
    if resultados is not None:
        with ZipFile(resultados) as archive:
            for name in archive.namelist():
                if "/pmc/" not in name.lower() or not name.lower().endswith(".exp"):
                    continue
                counts = Counter()
                unequal = 0
                with archive.open(name) as stream:
                    for line in stream:
                        kind = line[:2].decode("ascii", errors="replace")
                        counts[kind] += 1
                        unequal += line != templates.get(kind)
                report["real_pmc_exp_files"].append({
                    "file": name,
                    "rows": sum(counts.values()),
                    "rows_by_type": dict(counts),
                    "rows_different_from_original_map_template": unequal,
                })
        assert report["real_pmc_exp_files"], "No se encontraron archivos PMC EXP."
        assert all(
            row["rows_different_from_original_map_template"] == 0
            for row in report["real_pmc_exp_files"]
        ), "La salida aportada no coincide totalmente con esta firma de fallo."
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resultados", type=Path)
    parser.add_argument("--report", type=Path, help="Archivo JSON opcional para el resultado")
    arguments = parser.parse_args()
    report = run(arguments.resultados)
    output = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if arguments.report:
        arguments.report.write_text(output, encoding="utf-8")
    print(output)
