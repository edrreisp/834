#r "Newtonsoft.Json"
#r "Microsoft.Azure.Workflows.Scripting"

using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Workflows.Scripting;
using Newtonsoft.Json.Linq;

// 834 -> EXP. Version optimizada a partir de reunion (2).txt.
// Unico requisito de salida: X12_OUTPUT_ROOT/<company> ya existente y escribible.
// Mantiene los XSLT/XSD desplegados y la regla ORIGINAL del nombre de salida.
// No genera transformed.xml, result.exp local, carpetas x12-* ni .all.
// Crea UN temporal en destino solo cuando hay bytes para escribir, y lo publica
// al cerrar correctamente. Flush/Dispose antes de la primera escritura no crean nada.
// Si existe EXACTAMENTE el mismo nombre .exp, lo reemplaza sin comparar contenido.
// No cambia nombres a (2) ni agrega GUID al nombre FINAL.
// Cache: como maximo 2 mapas/layouts por proceso; nunca guarda datos de afiliados.
// XSLT sigue necesitando memoria para su arbol de entrada; no es memoria constante.
// Recomendado para archivos grandes: concurrencia del trigger = 1.
// Execute C# Code: Run admite SOLO WorkflowContext e ILogger en el host del usuario.
// El token interno None no recibe cancelacion del host. La limpieza en finally
// cubre excepciones manejables; no puede garantizarse al terminar el proceso.
// Revision 2026-11-23.2: apertura diferida, limpieza propia con reintentos y trazas.

public static async Task<Results> Run(WorkflowContext context, ILogger log)
{
    // No agregar CancellationToken como parametro de Run: CustomCodeNetFxWorker
    // lo rechaza en GetParameters antes de invocar el script.
    var cancellationToken = CancellationToken.None;
    var total = Stopwatch.StartNew();
    string traceId = Guid.NewGuid().ToString("N");
    string phase = "initialization";
    bool entered = false;
    EncodedTransaction transaction = null;

    try
    {
        cancellationToken.ThrowIfCancellationRequested();
        LogResources(traceId, "start", log);
        var metadata = await ReadMetadata(context).ConfigureAwait(false);
        var outputRoot = Environment.GetEnvironmentVariable("X12_OUTPUT_ROOT");
        if (string.IsNullOrWhiteSpace(outputRoot))
            throw new InvalidOperationException(
                "Configure X12_OUTPUT_ROOT. No se guardan pruebas locales ni archivos .all.");

        var folder = Path.Combine(outputRoot, metadata.Company);
        if (!Directory.Exists(folder))
            throw new DirectoryNotFoundException("La carpeta destino configurada no existe o no es accesible.");
        var outputPath = Path.Combine(folder, metadata.OutputFileName);

        phase = "waiting-for-process-slot";
        var step = Stopwatch.StartNew();
        // Limita los arboles XSLT de ESTE script/proceso. No limita Decode_X12,
        // otros workflows ni otros workers; configure tambien el trigger.
        await RuntimeState.ProcessingGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        entered = true;
        double waitSeconds = step.Elapsed.TotalSeconds;

        phase = "loading-artifacts";
        step.Restart();
        string root = Environment.GetEnvironmentVariable("AzureWebJobsScriptRoot");
        if (string.IsNullOrWhiteSpace(root))
            root = Path.Combine(Environment.GetEnvironmentVariable("HOME") ?? @"C:\home", "site", "wwwroot");
        string mapPath = Path.Combine(root, "Artifacts", "Maps",
            "X12_834_Inbound_Mapping_" + metadata.Company + ".xslt");
        string schemaPath = Path.Combine(root, "Artifacts", "Schemas", "EnrollmentRequestInbound.xsd");
        bool cacheHit;
        var artifacts = GetArtifacts(mapPath, schemaPath, out cacheHit);
        double loadSeconds = step.Elapsed.TotalSeconds;
        log.LogInformation(
            "834: {TraceId} artifacts ready. Company={Company}; CacheHit={CacheHit}; LoadSeconds={Seconds:F3}; WaitSeconds={Wait:F3}; MapSha256={Hash}.",
            traceId, metadata.Company, cacheHit, loadSeconds, waitSeconds, artifacts.MapHash);

        phase = "reading-decode-result";
        step.Restart();
        cancellationToken.ThrowIfCancellationRequested();
        transaction = await ReadTransaction(context).ConfigureAwait(false);
        double decodeSeconds = step.Elapsed.TotalSeconds;
        cancellationToken.ThrowIfCancellationRequested();
        if (transaction.EdiFailed)
            log.LogWarning("834: {TraceId} Decode reporta isFailedTransactionSet=true; se conserva el comportamiento original.", traceId);
        LogResources(traceId, "after-decode", log);

        phase = "transform-write-publish";
        var result = ConvertAndPublish(transaction, artifacts, outputPath, traceId, log, cancellationToken);
        result.WaitSeconds = waitSeconds;
        result.ArtifactLoadSeconds = loadSeconds;
        result.GetDecodeSeconds = decodeSeconds;
        result.ArtifactsCacheHit = cacheHit;
        result.TotalSeconds = total.Elapsed.TotalSeconds;
        log.LogInformation(
            "834: {TraceId} completado. Members={Members}; Lines={Lines}; Bytes={Bytes}; TransformWriteSeconds={Transform:F3}; DestinationWriteSeconds={Write:F3}; PublishSeconds={Publish:F3}; TotalSeconds={Total:F3}; TruncatedFields={Truncated}.",
            traceId, result.MembersProcessed, result.RecordsWritten, result.OutputBytes,
            result.TransformAndWriteSeconds, result.DestinationWriteSeconds,
            result.PublishSeconds, result.TotalSeconds, result.TruncatedFields);
        return result;
    }
    catch (Exception ex)
    {
        // No XML, valores, SSN, rutas de entradas ni mensajes de excepcion con datos.
        log.LogError("834: {TraceId} fallo. Phase={Phase}; Type={Type}; HResult={HResult}.",
            traceId, phase, ex.GetType().Name, ex.HResult);
        throw;
    }
    finally
    {
        if (transaction != null) transaction.Base64 = null;
        if (entered) RuntimeState.ProcessingGate.Release();
        LogResources(traceId, "end", log);
    }
}

public static async Task<InputMetadata> ReadMetadata(WorkflowContext context)
{
    // Se conservan unicamente strings pequenos; no retener el JObject del trigger.
    var trigger = (await context.GetTriggerResults().ConfigureAwait(false)).Outputs;
    var payload = trigger["body"];
    string company = Required(payload, "company").Trim().ToUpperInvariant();
    string fileType = Required(payload, "fileType").Trim().ToLowerInvariant();
    EnsureSinglePathComponent(company);
    var parts = Required(payload, "fileName").Split('_');
    if (parts.Length < 5 || parts[3].Length < 8)
        throw new InvalidOperationException("fileName no cumple el patron usado por Compose_File_Name.");
    // EXACTAMENTE la regla del original. Conserva - Copy, - Copy (2), etc.
    string fileName = Required(payload, "companyCode") + parts[3].Substring(2, 6)
        + "_" + parts[4].Split('.')[0] + "." + fileType;
    EnsureSinglePathComponent(fileName);
    return new InputMetadata { Company = company, OutputFileName = fileName };
}

public static async Task<EncodedTransaction> ReadTransaction(WorkflowContext context)
{
    var decode = (await context.GetActionResults("Decode_X12").ConfigureAwait(false)).Outputs;
    var groups = decode["body"]?["interchange"]?["functionalGroups"] as JArray;
    if (groups == null || groups.Count != 1)
        throw new InvalidOperationException("Este script requiere exactamente un grupo funcional.");
    var sets = groups[0]["transactionSets"] as JArray;
    if (sets == null || sets.Count != 1)
        throw new InvalidOperationException("Este script requiere exactamente un transaction set.");
    string content = sets[0]["transactionSetContent"]?["$content"]?.Value<string>();
    if (string.IsNullOrEmpty(content))
        throw new InvalidOperationException("Decode sin XML de transaccion.");
    return new EncodedTransaction {
        Base64 = content,
        EdiFailed = sets[0]["isFailedTransactionSet"]?.Value<bool>() ?? false
    };
}

public static Results ConvertAndPublish(EncodedTransaction transaction, ArtifactBundle artifacts,
    string outputPath, string traceId, ILogger log, CancellationToken token)
{
    // El temporal esta en la MISMA carpeta/volumen, y NO acaba en .exp.
    string pending = outputPath + "." + traceId + ".processing";
    bool published = false;
    LazyFileWriteStream destination = null;
    var phaseTimer = Stopwatch.StartNew();
    var result = new Results {
        Status = "Completed", Mode = "PublishedSMB", TraceId = traceId,
        OutputPath = outputPath, EdiTransactionFailed = transaction.EdiFailed,
        TimingMode = "StreamingCombined", ScriptVersion = RuntimeState.ScriptVersion,
        PendingFileName = Path.GetFileName(pending)
    };
    try
    {
        token.ThrowIfCancellationRequested();
        using (var input = new ChunkedBase64Stream(transaction.Base64, token))
        {
            transaction.Base64 = null; // el stream ya posee la unica referencia de este helper
            using (var reader = XmlReader.Create(input, ReaderSettings()))
            {
                reader.MoveToContent();
                log.LogInformation("834: {TraceId} iniciando transformacion y escritura directa. Root={Root}; Namespace={Namespace}.",
                    traceId, reader.LocalName, reader.NamespaceURI);
                // Transform puede cargar el arbol XML antes de emitir datos.
                // No abrir el .processing durante esa espera: el stream lo crea
                // en el primer Write con contenido, no en su constructor/Flush.
                destination = new LazyFileWriteStream(pending, token, () =>
                    log.LogInformation("834: {TraceId} temporal creado al recibir bytes de salida. Version={Version}.",
                        traceId, RuntimeState.ScriptVersion));
                using (destination)
                {
                    using (var hashing = new HashingWriteStream(destination, token))
                    using (var text = new StreamWriter(hashing, new UTF8Encoding(false, true), 16 * 1024, true))
                    using (var flat = new FlatFileXmlWriter(text, artifacts.Layout, traceId, log, token))
                    {
                        artifacts.Transform.Transform(reader, null, flat);
                        flat.Complete();
                        // Valida tambien el final de Base64 si el lector no lo agoto.
                        input.DrainAndValidate();
                        token.ThrowIfCancellationRequested();
                        text.Flush();
                        hashing.Flush();
                        result.Sha256 = hashing.FinishHash();
                        result.OutputBytes = hashing.BytesWritten;
                        result.InputXmlBytes = input.DecodedBytes;
                        result.MembersProcessed = flat.Members;
                        result.RecordsWritten = flat.Lines;
                        result.TruncatedFields = flat.TruncatedFields;
                        result.DestinationWriteSeconds = hashing.WriteSeconds;
                    }
                } // cierre del archivo antes de hacerlo visible como .exp
            }
        }

        result.TransformAndWriteSeconds = phaseTimer.Elapsed.TotalSeconds;
        // Compatibilidad de propiedades con el workflow original: ya no son etapas
        // separadas. TransformSeconds contiene todo el flujo; FlatFileSeconds=0.
        result.TransformSeconds = result.TransformAndWriteSeconds;
        result.FlatFileSeconds = 0;
        LogResources(traceId, "after-write", log);
        token.ThrowIfCancellationRequested();
        phaseTimer.Restart();
        PublishCompletedFile(pending, outputPath, token);
        published = true;
        result.PublishSeconds = phaseTimer.Elapsed.TotalSeconds;
        log.LogInformation("834: {TraceId} archivo publicado; verificando limpieza del temporal propio.", traceId);
        return result;
    }
    finally
    {
        // Tambien comprobar el nombre propio despues de publicar. File.Delete
        // no hace nada si Move/Replace ya consumio esa ruta; no usar File.Exists
        // como prueba de ausencia, porque puede ocultar errores de acceso.
        // No barrer *.processing: otro intento puede seguir activo, incluso a 0 KB.
        if (destination != null && destination.Created)
        {
            Exception cleanup = RemoveOwnPending(pending, traceId, log);
            result.PendingFileRemoved = cleanup == null;
            if (cleanup != null && published)
            {
                // El EXP completo se conserva, pero no informar Completed si no
                // se pudo terminar la limpieza propia. Ante un error anterior,
                // conservar su excepcion original y registrar el fallo de limpieza.
                throw new IOException("El EXP se publico, pero no se pudo completar la limpieza del temporal propio. Consulte el TraceId en los logs.", cleanup);
            }
        }
    }
}

public static Exception RemoveOwnPending(string pending, string traceId, ILogger log)
{
    // Reintentar solo esta ruta de la invocacion, tras cerrar todos sus handles.
    // El limite es 3 intentos: 100 + 200 ms de espera total en fallos transitorios.
    for (int attempt = 1; attempt <= 3; attempt++)
    {
        try
        {
            File.Delete(pending);
            log.LogInformation("834: {TraceId} temporal propio ausente. CleanupAttempts={Attempts}.", traceId, attempt);
            return null;
        }
        catch (Exception error)
        {
            bool transient = error is IOException;
            if (!transient || attempt == 3)
            {
                log.LogError("834: {TraceId} limpieza del temporal propio fallo. Attempts={Attempts}; Type={Type}; HResult={HResult}.",
                    traceId, attempt, error.GetType().Name, error.HResult);
                return error;
            }
            log.LogWarning("834: {TraceId} reintentando limpieza del temporal propio. Attempt={Attempt}; Type={Type}; HResult={HResult}.",
                traceId, attempt, error.GetType().Name, error.HResult);
            Thread.Sleep(100 * attempt);
        }
    }
    return new IOException("No se completo la limpieza del temporal propio.");
}

public static void PublishCompletedFile(string pending, string outputPath, CancellationToken token)
{
    // Un archivo completo reemplaza al anterior sin borrarlo primero. Se requiere
    // soporte rename/replace del servidor SMB. No hay fallback a copia destructiva.
    for (int attempt = 0; attempt < 3; attempt++)
    {
        token.ThrowIfCancellationRequested();
        try
        {
            File.Move(pending, outputPath);
            return;
        }
        catch (IOException) when (File.Exists(pending) && File.Exists(outputPath))
        {
            // Coincidencia de nombre, no deduplicacion: publicar la nueva salida.
            try
            {
                File.Replace(pending, outputPath, null);
                return;
            }
            catch (FileNotFoundException) when (
                attempt < 2 && File.Exists(pending) && !File.Exists(outputPath))
            {
                // Un consumidor retiro el destino; volver a intentar Move.
                // Los demas fallos (permisos, bloqueo, SMB) se propagan de inmediato.
            }
        }
    }
    throw new IOException("No se pudo publicar el archivo completo.");
}

public static ArtifactBundle GetArtifacts(string mapPath, string schemaPath, out bool cacheHit)
{
    // Son archivos de configuracion pequenos, NO los XML de afiliados.
    // Hash del contenido real: detecta cambios aunque el despliegue conserve
    // timestamp y longitud. Compilar exactamente estos snapshots evita carreras
    // entre la lectura usada para el hash y la utilizada por el compilador.
    byte[] mapBytes = File.ReadAllBytes(mapPath);
    byte[] schemaBytes = File.ReadAllBytes(schemaPath);
    string mapHash = HashBytes(mapBytes);
    string schemaHash = HashBytes(schemaBytes);
    lock (RuntimeState.CacheLock)
    {
        int target = -1;
        for (int i = 0; i < RuntimeState.Artifacts.Length; i++)
        {
            var value = RuntimeState.Artifacts[i];
            if (value != null && value.MapPath == mapPath && value.SchemaPath == schemaPath)
            {
                target = i;
                if (value.MapHash == mapHash && value.SchemaHash == schemaHash)
                {
                    value.LastUse = ++RuntimeState.CacheUse;
                    cacheHit = true;
                    return value;
                }
                break;
            }
        }
        if (target < 0)
        {
            target = 0;
            for (int i = 0; i < RuntimeState.Artifacts.Length; i++)
            {
                if (RuntimeState.Artifacts[i] == null) { target = i; break; }
                if (RuntimeState.Artifacts[i].LastUse < RuntimeState.Artifacts[target].LastUse) target = i;
            }
        }
        // Nunca se recarga una instancia que otro caller pudiera estar usando.
        var transform = new XslCompiledTransform();
        // StreamReader equivale a File.ReadAllText (UTF-8 por defecto, detecta BOM).
        // StringReader preserva el workaround original de declaracion UTF-16.
        using (var bytes = new MemoryStream(mapBytes, false))
        using (var source = new StreamReader(bytes, Encoding.UTF8, true))
        using (var text = new StringReader(source.ReadToEnd()))
        using (var reader = XmlReader.Create(text, ReaderSettings()))
            transform.Load(reader, XsltSettings.Default, null);
        if (transform.OutputSettings.OutputMethod != XmlOutputMethod.Xml)
            throw new InvalidOperationException("El mapa debe producir XML Root/Member segun EnrollmentRequestInbound.");
        FlatLayout layout;
        using (var bytes = new MemoryStream(schemaBytes, false))
        using (var reader = XmlReader.Create(bytes, ReaderSettings()))
            layout = ReadLayoutFromReader(reader);
        var bundle = new ArtifactBundle {
            MapPath = mapPath, SchemaPath = schemaPath,
            MapHash = mapHash, SchemaHash = schemaHash,
            Transform = transform, Layout = layout, LastUse = ++RuntimeState.CacheUse
        };
        // No se guardan mapBytes/schemaBytes ni strings XML en el cache.
        RuntimeState.Artifacts[target] = bundle;
        cacheHit = false;
        return bundle;
    }
}

public static XmlReaderSettings ReaderSettings()
{
    return new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
}

public static string Required(JToken body, string name)
{
    var value = body?[name]?.Value<string>();
    if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException("Falta " + name + " en el trigger.");
    return value;
}

public static void EnsureSinglePathComponent(string value)
{
    if (value == "." || value == ".." || value.IndexOf('/') >= 0 || value.IndexOf('\\') >= 0 || value.IndexOf(':') >= 0)
        throw new InvalidOperationException("El nombre debe ser un componente de archivo, no una ruta.");
}

public static string HashBytes(byte[] bytes)
{
    using (var sha = SHA256.Create())
        return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
}

public static void LogResources(string traceId, string phase, ILogger log)
{
    // Diagnostico de bajo volumen, sin forzar recolecciones de basura.
    try
    {
        using (var process = Process.GetCurrentProcess())
            log.LogInformation("834 PERF: {TraceId} Phase={Phase}; PID={PID}; ManagedMiB={Managed:F1}; PrivateMiB={Private:F1}; WorkingSetMiB={Working:F1}; Gen2={Gen2}.",
                traceId, phase, process.Id, GC.GetTotalMemory(false) / 1048576.0,
                process.PrivateMemorySize64 / 1048576.0, process.WorkingSet64 / 1048576.0,
                GC.CollectionCount(2));
    }
    catch (Exception) { /* Las metricas no deben impedir publicar el archivo. */ }
}

public static class RuntimeState
{
    public const string ScriptVersion = "2026-11-23.2";
    public static readonly SemaphoreSlim ProcessingGate = new SemaphoreSlim(1, 1);
    public static readonly object CacheLock = new object();
    public static readonly ArtifactBundle[] Artifacts = new ArtifactBundle[2];
    public static long CacheUse;
}

public sealed class ArtifactBundle
{
    public string MapPath, SchemaPath, MapHash, SchemaHash;
    public long LastUse;
    public XslCompiledTransform Transform;
    public FlatLayout Layout;
}

public sealed class InputMetadata { public string Company; public string OutputFileName; }
public sealed class EncodedTransaction { public string Base64; public bool EdiFailed; }

public sealed class Results
{
    public string Status { get; set; }
    public string Mode { get; set; }
    public string TraceId { get; set; }
    public string ScriptVersion { get; set; }
    public string PendingFileName { get; set; }
    public bool PendingFileRemoved { get; set; }
    public string OutputPath { get; set; }
    public long OutputBytes { get; set; }
    // SHA256 de bytes escritos en una pasada; no relee SMB para validarlo.
    public string Sha256 { get; set; }
    public long MembersProcessed { get; set; }
    public long RecordsWritten { get; set; }
    public bool EdiTransactionFailed { get; set; }
    public double TransformSeconds { get; set; }
    public double FlatFileSeconds { get; set; }
    public double TotalSeconds { get; set; }
    public string TimingMode { get; set; }
    public double TransformAndWriteSeconds { get; set; }
    public double DestinationWriteSeconds { get; set; }
    public double PublishSeconds { get; set; }
    public double WaitSeconds { get; set; }
    public double ArtifactLoadSeconds { get; set; }
    public double GetDecodeSeconds { get; set; }
    public long InputXmlBytes { get; set; }
    public long TruncatedFields { get; set; }
    public bool ArtifactsCacheHit { get; set; }
}


// Decodifica Base64 por bloques pequenos. No crea el byte[] del XML completo.
// El string Base64 ya existe en Decode_X12; este stream no puede liberar la
// copia/referencia que eventualmente conserve el host de Logic Apps.
public sealed class ChunkedBase64Stream : Stream
{
    private string source;
    private int sourceOffset;
    private readonly char[] chars = new char[16 * 1024];
    private byte[] decoded;
    private int decodedOffset;
    private bool eof;
    private bool disposed;
    private readonly CancellationToken token;
    public long DecodedBytes { get; private set; }

    public ChunkedBase64Stream(string base64, CancellationToken cancellationToken)
    {
        if (base64 == null) throw new ArgumentNullException("base64");
        source = base64;
        token = cancellationToken;
    }

    private static bool IsBase64WhiteSpace(char c)
    {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n';
    }

    private bool Fill()
    {
        token.ThrowIfCancellationRequested();
        if (eof) return false;
        int count = 0;
        while (sourceOffset < source.Length && count < chars.Length)
        {
            char c = source[sourceOffset++];
            if (!IsBase64WhiteSpace(c)) chars[count++] = c;
        }
        if (count == 0)
        {
            eof = true;
            source = null;
            decoded = null;
            return false;
        }
        if ((count & 3) != 0)
            throw new FormatException("Longitud Base64 invalida en Decode_X12.");

        // Arreglos <=12 KiB por bloque, recuperables; sin arreglo grande LOH.
        // Convert conserva la validacion .NET de caracteres y padding.
        decoded = Convert.FromBase64CharArray(chars, 0, count);
        decodedOffset = 0;
        DecodedBytes += decoded.Length;

        if (chars[count - 1] == '=')
        {
            // No aceptar datos despues del padding aunque caigan en otro bloque.
            while (sourceOffset < source.Length)
            {
                if ((sourceOffset & 16383) == 0) token.ThrowIfCancellationRequested();
                if (!IsBase64WhiteSpace(source[sourceOffset++]))
                    throw new FormatException("Datos despues del padding Base64.");
            }
            eof = true;
            source = null;
        }
        else if (sourceOffset == source.Length)
        {
            eof = true;
            source = null;
        }
        return decoded.Length > 0;
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        if (disposed) throw new ObjectDisposedException("ChunkedBase64Stream");
        if (buffer == null) throw new ArgumentNullException("buffer");
        if (offset < 0 || count < 0 || offset > buffer.Length - count)
            throw new ArgumentOutOfRangeException();
        token.ThrowIfCancellationRequested();
        int written = 0;
        while (count > 0)
        {
            if (decoded == null || decodedOffset == decoded.Length)
            {
                if (!Fill()) break;
            }
            int take = Math.Min(count, decoded.Length - decodedOffset);
            Buffer.BlockCopy(decoded, decodedOffset, buffer, offset, take);
            decodedOffset += take;
            offset += take;
            count -= take;
            written += take;
        }
        return written;
    }

    public override int ReadByte()
    {
        if (disposed) throw new ObjectDisposedException("ChunkedBase64Stream");
        token.ThrowIfCancellationRequested();
        if ((decoded == null || decodedOffset == decoded.Length) && !Fill()) return -1;
        return decoded[decodedOffset++];
    }

    public void DrainAndValidate()
    {
        token.ThrowIfCancellationRequested();
        if (eof && (decoded == null || decodedOffset == decoded.Length)) return;
        var buffer = new byte[4096];
        while (Read(buffer, 0, buffer.Length) > 0) { }
    }

    protected override void Dispose(bool disposing)
    {
        if (!disposed)
        {
            source = null;
            if (decoded != null) Array.Clear(decoded, 0, decoded.Length);
            decoded = null;
            Array.Clear(chars, 0, chars.Length);
            disposed = true;
        }
        base.Dispose(disposing);
    }

    public override bool CanRead { get { return !disposed; } }
    public override bool CanSeek { get { return false; } }
    public override bool CanWrite { get { return false; } }
    public override long Length { get { throw new NotSupportedException(); } }
    public override long Position { get { throw new NotSupportedException(); } set { throw new NotSupportedException(); } }
    public override void Flush() { }
    public override long Seek(long offset, SeekOrigin origin) { throw new NotSupportedException(); }
    public override void SetLength(long value) { throw new NotSupportedException(); }
    public override void Write(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }
}

// No crea el archivo remoto mientras XSLT prepara su arbol de entrada.
// FileMode.CreateNew preserva una ruta preexistente; se limpia solo si Created=true.
// La propiedad Created conserva su valor despues de Dispose para el finally externo.
public sealed class LazyFileWriteStream : Stream
{
    private readonly string path;
    private readonly CancellationToken token;
    private Action onCreated;
    private FileStream file;
    private bool disposed;
    public bool Created { get; private set; }

    public LazyFileWriteStream(string outputPath, CancellationToken cancellationToken)
        : this(outputPath, cancellationToken, null) { }

    public LazyFileWriteStream(string outputPath, CancellationToken cancellationToken, Action createdCallback)
    {
        if (string.IsNullOrWhiteSpace(outputPath)) throw new ArgumentException("Ruta temporal requerida.", "outputPath");
        path = outputPath;
        token = cancellationToken;
        onCreated = createdCallback;
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        if (disposed) throw new ObjectDisposedException("LazyFileWriteStream");
        if (buffer == null) throw new ArgumentNullException("buffer");
        if (offset < 0 || count < 0 || offset > buffer.Length - count) throw new ArgumentOutOfRangeException();
        token.ThrowIfCancellationRequested();
        if (count == 0) return;
        if (file == null)
        {
            file = new FileStream(path, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 256 * 1024, FileOptions.SequentialScan);
            Created = true;
            var callback = onCreated;
            onCreated = null;
            if (callback != null) callback();
        }
        file.Write(buffer, offset, count);
    }

    public override void Flush()
    {
        if (disposed) throw new ObjectDisposedException("LazyFileWriteStream");
        token.ThrowIfCancellationRequested();
        if (file != null) file.Flush();
    }

    protected override void Dispose(bool disposing)
    {
        if (!disposed)
        {
            disposed = true;
            onCreated = null;
            var opened = file;
            file = null;
            if (disposing && opened != null) opened.Dispose();
        }
        base.Dispose(disposing);
    }

    public override bool CanRead { get { return false; } }
    public override bool CanSeek { get { return false; } }
    public override bool CanWrite { get { return !disposed; } }
    public override long Length { get { throw new NotSupportedException(); } }
    public override long Position { get { throw new NotSupportedException(); } set { throw new NotSupportedException(); } }
    public override int Read(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }
    public override long Seek(long offset, SeekOrigin origin) { throw new NotSupportedException(); }
    public override void SetLength(long value) { throw new NotSupportedException(); }
}

// Calcula SHA256 sobre los mismos bytes enviados al destino. No relee el archivo.
// No es dueno de target: el caller cierra el FileStream antes de publicar.
public sealed class HashingWriteStream : Stream
{
    private readonly Stream target;
    private readonly SHA256 sha = SHA256.Create();
    private readonly CancellationToken token;
    private bool finished;
    private bool disposed;
    private long writeTicks;
    private string finalHash;
    public long BytesWritten { get; private set; }
    public double WriteSeconds { get { return (double)writeTicks / Stopwatch.Frequency; } }

    public HashingWriteStream(Stream output, CancellationToken cancellationToken)
    {
        if (output == null) throw new ArgumentNullException("output");
        target = output;
        token = cancellationToken;
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        if (disposed) throw new ObjectDisposedException("HashingWriteStream");
        if (finished) throw new InvalidOperationException("El hash ya esta finalizado.");
        token.ThrowIfCancellationRequested();
        long start = Stopwatch.GetTimestamp();
        try { target.Write(buffer, offset, count); }
        finally { writeTicks += Stopwatch.GetTimestamp() - start; }
        sha.TransformBlock(buffer, offset, count, null, 0);
        BytesWritten += count;
    }

    public override void Flush()
    {
        if (disposed) throw new ObjectDisposedException("HashingWriteStream");
        token.ThrowIfCancellationRequested();
        long start = Stopwatch.GetTimestamp();
        try { target.Flush(); }
        finally { writeTicks += Stopwatch.GetTimestamp() - start; }
    }

    public string FinishHash()
    {
        if (disposed) throw new ObjectDisposedException("HashingWriteStream");
        if (!finished)
        {
            sha.TransformFinalBlock(new byte[0], 0, 0);
            finalHash = BitConverter.ToString(sha.Hash).Replace("-", "").ToLowerInvariant();
            finished = true;
        }
        return finalHash;
    }

    protected override void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing) sha.Dispose();
            disposed = true;
        }
        base.Dispose(disposing);
    }

    public override bool CanRead { get { return false; } }
    public override bool CanSeek { get { return false; } }
    public override bool CanWrite { get { return !disposed && !finished; } }
    public override long Length { get { return BytesWritten; } }
    public override long Position { get { return BytesWritten; } set { throw new NotSupportedException(); } }
    public override int Read(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }
    public override long Seek(long offset, SeekOrigin origin) { throw new NotSupportedException(); }
    public override void SetLength(long value) { throw new NotSupportedException(); }
}


// El XSD es pequeno; solo se carga al renovar la entrada de cache.
public static FlatLayout ReadLayout(string path)
{
    var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
    using (var reader = XmlReader.Create(path, settings)) return ReadLayoutFromReader(reader);
}

public static FlatLayout ReadLayoutFromReader(XmlReader reader)
{
    var doc = new XmlDocument { XmlResolver = null };
    doc.Load(reader);
    var ns = new XmlNamespaceManager(doc.NameTable);
    ns.AddNamespace("x", "http://www.w3.org/2001/XMLSchema");
    ns.AddNamespace("b", "http://schemas.microsoft.com/BizTalk/2003");
    var info = doc.SelectSingleNode("/x:schema/x:annotation/x:appinfo/b:schemaInfo", ns) as XmlElement;
    if (info == null || info.GetAttribute("codepage") != "65001" ||
        info.GetAttribute("count_positions_by_byte") != "false" || info.GetAttribute("default_pad_char") != " ")
        throw new InvalidOperationException("Configuracion de esquema no soportada: requiere UTF-8, posiciones por caracter y relleno espacio.");
    var layout = new FlatLayout { RootNamespace = doc.DocumentElement.GetAttribute("targetNamespace") };
    var member = doc.SelectSingleNode("/x:schema/x:element[@name='Root']/x:complexType/x:sequence/x:element[@name='Member']", ns);
    if (member == null) throw new InvalidOperationException("No se encontro Root/Member en el XSD.");
    var delimiter = member.SelectSingleNode("x:annotation/x:appinfo/b:recordInfo", ns) as XmlElement;
    if (delimiter == null || delimiter.GetAttribute("child_order") != "postfix" ||
        delimiter.GetAttribute("child_delimiter") != "0xD 0xA")
        throw new InvalidOperationException("El esquema requiere un delimitador no soportado.");
    foreach (XmlElement record in member.SelectNodes("x:complexType/x:sequence/x:element", ns))
    {
        var spec = new RecordSpec { Name = record.GetAttribute("name"), Order = layout.Records.Count };
        var ri = record.SelectSingleNode("x:annotation/x:appinfo/b:recordInfo", ns) as XmlElement;
        if (ri == null || ri.GetAttribute("structure") != "positional")
            throw new InvalidOperationException("Registro no posicional no soportado.");
        foreach (XmlElement field in record.SelectNodes("x:complexType/x:sequence/x:element", ns))
        {
            var fi = field.SelectSingleNode("x:annotation/x:appinfo/b:fieldInfo", ns) as XmlElement;
            if (fi == null || fi.GetAttribute("justification") != "left" || fi.GetAttribute("pos_offset") != "0")
                throw new InvalidOperationException("Anotacion de campo no soportada.");
            int length;
            if (!int.TryParse(fi.GetAttribute("pos_length"), out length) || length <= 0)
                throw new InvalidOperationException("Longitud de campo invalida.");
            var fieldSpec = new FieldSpec {
                Name = field.GetAttribute("name"), Length = length,
                Offset = spec.Length, Index = spec.Fields.Count
            };
            spec.Fields.Add(fieldSpec);
            spec.ByName.Add(fieldSpec.Name, fieldSpec);
            spec.Length = checked(spec.Length + length);
        }
        if (spec.Fields.Count == 0 || spec.Length != 739)
            throw new InvalidOperationException("Se esperaba el esquema proporcionado: registros de 739 caracteres.");
        layout.Records.Add(spec);
        layout.ByName.Add(spec.Name, spec);
        layout.MaxFields = Math.Max(layout.MaxFields, spec.Fields.Count);
    }
    if (layout.Records.Count != 5) throw new InvalidOperationException("Se esperaban cinco tipos de registro.");
    return layout;
}

public sealed class FieldSpec
{
    public string Name;
    public int Length;
    public int Offset;
    public int Index;
}

public sealed class RecordSpec
{
    public string Name;
    public int Order;
    public int Length;
    public readonly List<FieldSpec> Fields = new List<FieldSpec>();
    public readonly Dictionary<string, FieldSpec> ByName = new Dictionary<string, FieldSpec>(StringComparer.Ordinal);
}

public sealed class FlatLayout
{
    public string RootNamespace;
    public int MaxFields;
    public readonly List<RecordSpec> Records = new List<RecordSpec>();
    public readonly Dictionary<string, RecordSpec> ByName = new Dictionary<string, RecordSpec>(StringComparer.Ordinal);
}

// Consume los eventos XML del XSLT y escribe un registro plano al cerrar cada
// elemento de registro. No construye el XML completo ni un DOM por Member.
// La unidad de posicion sigue siendo char UTF-16, exactamente como el original.
public sealed class FlatFileXmlWriter : XmlWriter
{
    private readonly TextWriter output;
    private readonly FlatLayout layout;
    private readonly string traceId;
    private readonly ILogger log;
    private readonly CancellationToken cancellationToken;
    private readonly char[] recordBuffer = new char[741];
    private readonly bool[] seen;
    private readonly List<bool> preserveSpace = new List<bool>(8);
    private readonly char[] attributeValue = new char[8];
    private readonly XmlWriterSettings settings = new XmlWriterSettings {
        Encoding = new UTF8Encoding(false, true), ConformanceLevel = ConformanceLevel.Document,
        OmitXmlDeclaration = true, CloseOutput = false, CheckCharacters = true
    };
    private WriteState state = WriteState.Start;
    private int depth;
    private int lastOrder;
    private bool rootSeen;
    private bool rootClosed;
    private bool closed;
    private bool inAttribute;
    private bool spaceAttribute;
    private int attributeLength;
    private string rootPrefix = "";
    private RecordSpec record;
    private FieldSpec field;
    private long fieldLength;
    private int fieldCopied;
    // XmlDocument.PreserveWhitespace=false del original elimina nodos de texto
    // compuestos SOLO de whitespace, salvo xml:space='preserve' y CDATA.
    // Se guarda un punto de restauracion para aplicar lo mismo sin acumular texto.
    private bool textNodeActive;
    private bool nodeNonWhitespace;
    private bool nodePreserve;
    private bool nodeForbiddenControl;
    private bool pendingHighSurrogate;
    private long nodeStartLength;
    private int nodeStartCopied;
    private bool truncationSummaryLogged;

    public long Members { get; private set; }
    public long Lines { get; private set; }
    public long TruncatedFields { get; private set; }
    public override XmlWriterSettings Settings { get { return settings; } }
    public override WriteState WriteState { get { return closed ? WriteState.Closed : state; } }
    public override XmlSpace XmlSpace { get { return depth == 0 ? XmlSpace.None : (preserveSpace[depth - 1] ? XmlSpace.Preserve : XmlSpace.Default); } }
    public override string XmlLang { get { return ""; } }

    public FlatFileXmlWriter(TextWriter output, FlatLayout layout, string traceId,
        ILogger log, CancellationToken cancellationToken)
    {
        if (output == null) throw new ArgumentNullException("output");
        if (layout == null) throw new ArgumentNullException("layout");
        this.output = output;
        this.layout = layout;
        this.traceId = traceId;
        this.log = log;
        this.cancellationToken = cancellationToken;
        seen = new bool[layout.MaxFields];
        recordBuffer[739] = '\r'; recordBuffer[740] = '\n';
    }

    private void CheckOpen()
    {
        if (closed) throw new ObjectDisposedException("FlatFileXmlWriter");
        cancellationToken.ThrowIfCancellationRequested();
    }

    public override void WriteStartDocument() { CheckOpen(); state = WriteState.Prolog; }
    public override void WriteStartDocument(bool standalone) { WriteStartDocument(); }
    public override void WriteEndDocument()
    {
        CheckOpen();
        while (depth > 0) WriteEndElement();
        Complete();
    }
    public override void WriteDocType(string name, string pubid, string sysid, string subset)
    {
        throw new XmlException("DTD no permitido en la salida del mapping.");
    }

    public override void WriteStartElement(string prefix, string localName, string ns)
    {
        CheckOpen();
        if (inAttribute) throw new XmlException("Elemento dentro de un atributo.");
        FinishTextNode();
        if (depth == 0)
        {
            if (rootSeen || localName != "Root" || (ns ?? "") != layout.RootNamespace)
                throw new InvalidOperationException("XML transformado sin Root esperado.");
            rootSeen = true;
            rootPrefix = prefix ?? "";
        }
        else if (depth == 1)
        {
            if (localName != "Member") throw new InvalidOperationException("Elemento inesperado bajo Root.");
            Members++;
            lastOrder = -1;
        }
        else if (depth == 2)
        {
            if (!layout.ByName.TryGetValue(localName, out record) || record.Order < lastOrder)
                throw new InvalidOperationException("Registro desconocido o fuera de orden. Member=" + Members);
            lastOrder = record.Order;
            for (int i = 0; i < 739; i++) recordBuffer[i] = ' ';
            Array.Clear(seen, 0, seen.Length);
        }
        else if (depth == 3)
        {
            if (!record.ByName.TryGetValue(localName, out field) || seen[field.Index])
                throw new InvalidOperationException("Campo desconocido o duplicado en " + record.Name);
            seen[field.Index] = true;
            fieldLength = 0;
            fieldCopied = 0;
        }
        // Para elementos anidados dentro de un campo se concatena InnerText,
        // tal como hacia XmlElement.InnerText en el original.
        preserveSpace.Add(depth == 0 ? false : preserveSpace[depth - 1]);
        depth++;
        state = WriteState.Element;
    }

    public override void WriteEndElement()
    {
        CheckOpen();
        if (depth == 0 || inAttribute) throw new XmlException("Cierre de elemento inesperado.");
        FinishTextNode();
        if (depth == 4)
        {
            if (fieldLength > field.Length)
            {
                TruncatedFields++;
                if (TruncatedFields <= 10 && log != null)
                    log.LogWarning("834: {TraceId} campo truncado. Member={Member}; Registro={Record}; Campo={Field}; LongitudOriginal={Original}; LongitudPermitida={Allowed}.",
                        traceId, Members, record.Name, field.Name, fieldLength, field.Length);
            }
            field = null;
        }
        else if (depth == 3)
        {
            output.Write(recordBuffer, 0, recordBuffer.Length);
            Lines++;
            record = null;
        }
        else if (depth == 2 && Members % 5000 == 0 && log != null)
        {
            log.LogInformation("834: {TraceId} plano: Members={Members}, Lines={Lines}.", traceId, Members, Lines);
        }
        else if (depth == 1) rootClosed = true;
        preserveSpace.RemoveAt(depth - 1);
        depth--;
        state = WriteState.Content;
    }
    public override void WriteFullEndElement() { WriteEndElement(); }

    public override void WriteStartAttribute(string prefix, string localName, string ns)
    {
        CheckOpen();
        if (inAttribute || depth == 0 || state != WriteState.Element)
            throw new XmlException("Atributo fuera de un elemento abierto.");
        inAttribute = true;
        spaceAttribute = localName == "space" && (prefix == "xml" || ns == "http://www.w3.org/XML/1998/namespace");
        attributeLength = 0;
        state = WriteState.Attribute;
    }
    public override void WriteEndAttribute()
    {
        CheckOpen();
        if (!inAttribute) throw new XmlException("Cierre de atributo inesperado.");
        if (spaceAttribute)
        {
            var value = new string(attributeValue, 0, attributeLength);
            if (value == "preserve") preserveSpace[depth - 1] = true;
            else if (value == "default") preserveSpace[depth - 1] = false;
            else throw new XmlException("Valor xml:space no soportado.");
        }
        inAttribute = false;
        spaceAttribute = false;
        state = WriteState.Element;
    }

    public override void WriteString(string text)
    {
        if (text == null) return;
        AppendText(text, null, 0, text.Length);
    }
    public override void WriteChars(char[] buffer, int index, int count)
    {
        if (buffer == null) throw new ArgumentNullException("buffer");
        if (index < 0 || count < 0 || index > buffer.Length - count) throw new ArgumentOutOfRangeException();
        AppendText(null, buffer, index, count);
    }
    public override void WriteWhitespace(string ws)
    {
        if (ws == null) return;
        for (int i = 0; i < ws.Length; i++)
            if (!IsXmlWhitespace(ws[i])) throw new XmlException("WriteWhitespace requiere whitespace XML.");
        WriteString(ws);
    }
    public override void WriteCData(string text)
    {
        CheckOpen();
        if (inAttribute) throw new XmlException("CDATA dentro de un atributo.");
        FinishTextNode();
        BeginTextNode(true);
        if (text != null) AppendText(text, null, 0, text.Length);
        FinishTextNode();
    }
    public override void WriteComment(string text)
    {
        CheckOpen(); FinishTextNode();
        if (text != null && (text.IndexOf("--", StringComparison.Ordinal) >= 0 || text.EndsWith("-", StringComparison.Ordinal)))
            throw new XmlException("Comentario XML invalido.");
        state = depth == 0 ? WriteState.Prolog : WriteState.Content;
    }
    public override void WriteProcessingInstruction(string name, string text)
    {
        CheckOpen(); FinishTextNode();
        if (text != null && text.IndexOf("?>", StringComparison.Ordinal) >= 0)
            throw new XmlException("Instruccion XML invalida.");
        state = depth == 0 ? WriteState.Prolog : WriteState.Content;
    }
    public override void WriteEntityRef(string name)
    {
        switch (name)
        {
            case "amp": WriteString("&"); break;
            case "lt": WriteString("<"); break;
            case "gt": WriteString(">"); break;
            case "apos": WriteString("'"); break;
            case "quot": WriteString("\""); break;
            default: throw new XmlException("Entidad no soportada sin DTD.");
        }
    }
    public override void WriteCharEntity(char ch)
    {
        CheckOpen();
        AppendSingleCharacter(ch);
    }
    public override void WriteSurrogateCharEntity(char lowChar, char highChar)
    {
        CheckOpen();
        if (!char.IsHighSurrogate(highChar) || !char.IsLowSurrogate(lowChar))
            throw new XmlException("Par sustituto UTF-16 invalido.");
        AppendSingleCharacter(highChar);
        AppendSingleCharacter(lowChar);
    }
    public override void WriteRaw(string data)
    {
        if (data == null) return;
        // disable-output-escaping con markup requiere volver a parsear XML;
        // se rechaza antes de publicar para no producir campos incorrectos.
        if (data.IndexOf('<') >= 0 || data.IndexOf('&') >= 0)
            throw new XmlException("El mapping usa markup con disable-output-escaping; no es compatible con la salida plana directa.");
        WriteString(data);
    }
    public override void WriteRaw(char[] buffer, int index, int count)
    {
        if (buffer == null) throw new ArgumentNullException("buffer");
        if (index < 0 || count < 0 || index > buffer.Length - count) throw new ArgumentOutOfRangeException();
        for (int i = index; i < index + count; i++)
            if (buffer[i] == '<' || buffer[i] == '&')
                throw new XmlException("Markup raw no compatible con la salida plana directa.");
        WriteChars(buffer, index, count);
    }
    public override void WriteBase64(byte[] buffer, int index, int count)
    {
        throw new NotSupportedException("Salida XML Base64 no soportada por el layout plano.");
    }
    public override string LookupPrefix(string ns)
    {
        if (ns == "http://www.w3.org/XML/1998/namespace") return "xml";
        if (ns == "http://www.w3.org/2000/xmlns/") return "xmlns";
        if (ns == layout.RootNamespace && rootSeen) return rootPrefix;
        return ns == "" ? "" : null;
    }
    public override void Flush() { CheckOpen(); output.Flush(); }
    public override void Close()
    {
        // El caller es dueno de TextWriter/Stream y los cierra en orden.
        // No completar ni publicar aqui: Dispose tambien corre tras excepciones.
        if (closed) return;
        Array.Clear(recordBuffer, 0, recordBuffer.Length);
        Array.Clear(attributeValue, 0, attributeValue.Length);
        field = null; record = null;
        closed = true;
    }

    public void Complete()
    {
        CheckOpen(); FinishTextNode();
        if (!rootSeen || !rootClosed || depth != 0 || inAttribute || Members == 0 || Lines == 0)
            throw new InvalidOperationException("XML transformado incompleto, vacio o sin registros.");
        if (TruncatedFields > 10 && !truncationSummaryLogged && log != null)
        {
            log.LogWarning("834: {TraceId} campos truncados totales={Count}; se detallaron solo los primeros 10.", traceId, TruncatedFields);
            truncationSummaryLogged = true;
        }
    }

    private static bool IsXmlWhitespace(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; }

    private void BeginTextNode(bool forcePreserve)
    {
        if (textNodeActive || field == null) return;
        textNodeActive = true;
        nodeNonWhitespace = false;
        nodePreserve = forcePreserve || (depth > 0 && preserveSpace[depth - 1]);
        nodeForbiddenControl = false;
        pendingHighSurrogate = false;
        nodeStartLength = fieldLength;
        nodeStartCopied = fieldCopied;
    }
    private void FinishTextNode()
    {
        if (!textNodeActive) return;
        if (pendingHighSurrogate) throw new XmlException("Par sustituto UTF-16 incompleto.");
        if (nodeNonWhitespace || nodePreserve)
        {
            if (nodeForbiddenControl)
                throw new InvalidOperationException("Caracter de control en Member=" + Members + ", " + record.Name + "/" + field.Name);
        }
        else
        {
            for (int i = nodeStartCopied; i < fieldCopied; i++) recordBuffer[field.Offset + i] = ' ';
            fieldLength = nodeStartLength;
            fieldCopied = nodeStartCopied;
        }
        textNodeActive = false;
    }
    private void AppendSingleCharacter(char ch)
    {
        if (inAttribute)
        {
            if (!spaceAttribute) return;
            if (attributeLength == attributeValue.Length) throw new XmlException("Valor xml:space invalido.");
            attributeValue[attributeLength++] = ch;
            return;
        }
        if (field == null)
        {
            if (depth == 0 && !IsXmlWhitespace(ch)) throw new XmlException("Texto fuera de Root.");
            return;
        }
        BeginTextNode(false);
        AppendFieldCharacter(ch);
        state = WriteState.Content;
    }
    private void AppendText(string text, char[] chars, int index, int count)
    {
        CheckOpen();
        if (inAttribute)
        {
            if (!spaceAttribute) return;
            if (count > attributeValue.Length - attributeLength) throw new XmlException("Valor xml:space invalido.");
            for (int i = 0; i < count; i++) attributeValue[attributeLength++] = text != null ? text[index + i] : chars[index + i];
            return;
        }
        if (field == null)
        {
            if (depth == 0)
                for (int i = 0; i < count; i++)
                    if (!IsXmlWhitespace(text != null ? text[index + i] : chars[index + i])) throw new XmlException("Texto fuera de Root.");
            state = depth == 0 ? WriteState.Prolog : WriteState.Content;
            return;
        }
        BeginTextNode(false);
        for (int i = 0; i < count; i++)
        {
            if ((i & 16383) == 0) cancellationToken.ThrowIfCancellationRequested();
            AppendFieldCharacter(text != null ? text[index + i] : chars[index + i]);
        }
        state = WriteState.Content;
    }
    private void AppendFieldCharacter(char c)
    {
        // Validar tambien el sufijo que se truncara; no esconder datos invalidos.
        if (pendingHighSurrogate)
        {
            if (!char.IsLowSurrogate(c)) throw new XmlException("Par sustituto UTF-16 invalido.");
            pendingHighSurrogate = false;
        }
        else if (char.IsHighSurrogate(c)) pendingHighSurrogate = true;
        else if (char.IsLowSurrogate(c) || c == '\0' || c == '\ufffe' || c == '\uffff' || (c < ' ' && !IsXmlWhitespace(c)))
            throw new XmlException("Caracter XML invalido en campo.");
        if (!IsXmlWhitespace(c)) nodeNonWhitespace = true;
        if (c == '\r' || c == '\n') nodeForbiddenControl = true;
        if (fieldCopied < field.Length) recordBuffer[field.Offset + fieldCopied++] = c;
        fieldLength++;
    }
}
