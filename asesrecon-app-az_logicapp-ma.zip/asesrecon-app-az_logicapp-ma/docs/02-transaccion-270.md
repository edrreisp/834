# 02 — Transacción 270: Eligibility Inquiry (saliente)

[Volver al índice](README.md)

## 1. Resumen

El legado produce un archivo posicional `.qry` con una fila por afiliado a consultar. El
flujo lo convierte a un X12 270 (`005010X279A1`) y lo deja en la carpeta `Outbound` para que
un proceso externo lo entregue a ASES/PRMMIS.

| Aspecto | Valor |
| --- | --- |
| Logic App | `ma-x12-dev-eligibility-asesrecon-lapp` |
| Dirección | Saliente (MMM/PMC hacia ASES) |
| Entrada | Flat file posicional, extensión `.qry`, 151 caracteres por registro |
| Salida | X12 270 crudo, extensión `.x12` |
| Implementation guide | `005010X279A1` |
| Workflows | [watch-270-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-270-mmm.json), [watch-270-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-270-pmc.json), [qry-to-x12-270.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/qry-to-x12-270.json) |
| Schemas | [EligibilityRequest.xsd](../IntegrationAccount/IntegrationAccount/Mappings/270/EligibilityRequest.xsd), [X12_00501_270.xsd](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_00501_270.xsd) |
| Mappings | [X12_270_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_MMM.btm), [X12_270_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_PMC.btm) |

## 2. Diagrama macro

```mermaid
flowchart TB
    Legacy["Sistema legado MMM / PMC<br/>genera el query file"]
    InFolder["ENRASES_QUERYFILE / InProcessAZ / {COMPANY}<br/>archivo *_270.qry"]
    Watcher["watch-270-mmm / watch-270-pmc"]
    Proc["qry-to-x12-270"]
    OutFolder["ENRASES_QUERYFILE / Outbound / {COMPANY}<br/>690320_MMMP_270_yyyyMMdd.x12"]
    Transport["Proceso externo de transporte<br/>(fuera de este repositorio)"]
    ASES[("ASES / PRMMIS")]

    Legacy --> InFolder
    InFolder -->|"trigger onnewfile cada 1 min"| Watcher
    Watcher -->|"fileContent + company"| Proc
    Proc --> OutFolder
    OutFolder --> Transport --> ASES
    ASES -.->|"respuesta asincrona"| Resp["Ver 03-transaccion-271.md"]
```

La consulta y la respuesta están **completamente desacopladas**: el 270 no espera al 271.
La correlación se hace por el trace number, explicado en la sección 8.

## 3. Watcher: `watch-270-mmm` / `watch-270-pmc`

```mermaid
flowchart TB
    T["Trigger: When_a_file_is_created_(properties_only)<br/>folderId = ENRASES_QUERYFILE / InProcessAZ / MMM<br/>condicion: endsWith(lower(Name), '_270.qry')<br/>recurrencia 1 min, maxFileCount 1, splitOn triggerBody()"]
    G["Get_file_content<br/>GET /datasets/default/files/{Path}/content"]
    C["Call_workflow_in_this_logic_app<br/>workflow: qry-to-x12-270<br/>body: fileContent = base64ToString($content), company = 'MMM'"]

    T --> G
    G -->|"runAfter: SUCCEEDED"| C
```

| Propiedad | `watch-270-mmm` | `watch-270-pmc` |
| --- | --- | --- |
| Carpeta vigilada | `ENRASES_QUERYFILE\InProcessAZ\MMM` | `ENRASES_QUERYFILE\InProcessAZ\PMC` |
| Condición de nombre | `endsWith(toLower(Name), '_270.qry')` | idéntica |
| `company` enviado | `"MMM"` | `"PMC"` |
| Conexión | `filesystem-7` | `filesystem-7` |

Ambos watchers declaran en `metadata` también la carpeta `InProcess\{COMPANY}`, pero el
`folderId` efectivo es `InProcessAZ`. La entrada extra no tiene efecto funcional.

## 4. Procesador: `qry-to-x12-270`

```mermaid
flowchart TB
    T["Trigger: When_an_HTTP_request_is_received"]
    CFC["Compose_File_Content<br/>replace CRLF por LF"]
    CC["Compose_Company<br/>toUpper(trim(company))"]
    DFF["Decode_flat_file<br/>FlatFileDecoding con EligibilityRequest.xsd"]
    VX["Validate_XML<br/>XmlValidation contra EligibilityRequest.xsd"]
    IF{"Validating_XML<br/>company = MMM o PMC ?"}
    TX["Transform_XML<br/>Xslt: X12_270_Mapping_{COMPANY}.xslt"]
    EX["Encode_X12<br/>agreement {COMPANY}_ASES_Eleg_Request"]
    IF2{"Generation_x12<br/>equals('', '') -- siempre verdadero"}
    CF["Create_file<br/>ENRASES_QUERYFILE / Outbound / {COMPANY}"]
    ERX["Error_Response_in_x12<br/>200 body 99 -- inalcanzable"]
    ER["Error_Response<br/>200 body 99"]
    SR["Success_Response<br/>200 body 0"]

    T --> CFC
    T --> CC
    CFC --> DFF --> VX
    VX --> IF
    CC --> IF
    IF -->|"true"| TX --> EX --> IF2
    IF2 -->|"true"| CF
    IF2 -->|"false"| ERX
    IF -->|"false"| ER
    IF -->|"SUCCEEDED"| SR
```

Detalle de dependencias reales (`runAfter`):

| Acción | Depende de |
| --- | --- |
| `Compose_File_Content` | nada (arranca con el trigger) |
| `Compose_Company` | nada (arranca con el trigger) |
| `Decode_flat_file` | `Compose_File_Content` |
| `Validate_XML` | `Decode_flat_file` |
| `Validating_XML` | `Validate_XML` **y** `Compose_Company` |
| `Success_Response` | `Validating_XML` |

`Compose_File_Content` y `Compose_Company` corren en paralelo y vuelven a converger en el
`If`.

### 4.1 Escritura del archivo de salida

```json
"folderPath": "@concat('\\\\1alexandria2.dev.pr.mmmhc.com\\manifiesto\\jobs\\ASES\\ENRASES_QUERYFILE\\Outbound\\', toUpper(outputs('Compose_Company')))",
"name": "@concat(if(equals(toUpper(outputs('Compose_Company')), 'MMM'), '690320', '690330'), '_', toUpper(outputs('Compose_Company')), 'P_270_', formatDateTime(convertTimeZone(utcNow(), 'UTC', 'SA Western Standard Time'), 'yyyyMMdd'), '.x12')"
```

El cuerpo escrito es `@body('Encode_X12')['encodedMessageContent']`, es decir el X12 crudo
con envelope ISA/IEA generado por el agreement.

| Compañía | Nombre generado el 8 de septiembre de 2026 |
| --- | --- |
| MMM | `690320_MMMP_270_20260908.x12` |
| PMC | `690330_PMCP_270_20260908.x12` |

## 5. Layout del flat file de entrada

[EligibilityRequest.xsd](../IntegrationAccount/IntegrationAccount/Mappings/270/EligibilityRequest.xsd)

| Propiedad | Valor |
| --- | --- |
| Root | `Root` |
| Namespace | `http://IntegrationAccount.x005F_x0032_70.EligibilityRequest` |
| Estándar | Flat File, codepage 65001, carácter de relleno espacio |
| Estructura del root | `delimited`, delimitador `0x0A` (LF), `child_order = postfix` |
| Estructura del registro | `positional`, justificación izquierda |
| Cardinalidad | `Record` de 1 a ilimitado |
| Longitud del registro | **151 caracteres** |

| # | Campo | Posición | Largo | ¿Se usa en el 270? |
| --- | --- | --- | --- | --- |
| 1 | `RecordType` | 1 | 1 | No |
| 2 | `ProcessDate` | 2–9 | 8 | No |
| 3 | `SocialSecurityNumber` | 10–18 | 9 | Sí, `REF02` |
| 4 | `LastName` | 19–33 | 15 | Sí, `NM103` |
| 5 | `SecondLastName` | 34–48 | 15 | Sí, `NM103` tras el pipe |
| 6 | `FirstName` | 49–68 | 20 | Sí, `NM104` |
| 7 | `Sex` | 69 | 1 | Sí, `DMG03` |
| 8 | `DateOfBirth` | 70–77 | 8 | Sí, `DMG02` |
| 9 | `Region` | 78 | 1 | No |
| 10 | `Carrier` | 79–80 | 2 | No |
| 11 | `EffectiveDate` | 81–88 | 8 | Sí, `DTP03` |
| 12 | `MPI` | 89–101 | 13 | Sí, `NM109` (sin los 2 primeros caracteres) |
| 13 | `Filler1` | 102–151 | 50 | Sí, `TRN02` |

**Hallazgo:** `Filler1`, que por su nombre parece relleno, en realidad transporta el trace
number de correlación. Es un contrato implícito con el legado: el sistema origen tiene que
poblar ese campo.

**Hallazgo:** cuatro campos que el legado envía no alimentan ningún segmento EDI:
`RecordType`, `ProcessDate`, `Region` y `Carrier`.

## 6. Estructura del X12 270 generado

```mermaid
flowchart TB
    ST["ST<br/>ST01=270, ST02=0001, ST03=005010X279A1"]
    BHT["BHT<br/>BHT01=0022, BHT02=13, BHT04=fecha, BHT05=hora"]
    HL1["HL nivel 1 -- HL03=20<br/>Information Source (payer)<br/>NM1: PR, PRMMIS, PI, PRMP"]
    HL2["HL nivel 2 -- HL03=21<br/>Information Receiver<br/>NM1: P5, MMM, SV, 000002700"]
    HL3["HL niveles 3..N -- HL03=22<br/>Subscriber, uno por Record del flat file<br/>TRN, NM1, REF, DMG, DTP, EQ"]

    ST --> BHT --> HL1 --> HL2 --> HL3
```

## 7. Mapping `X12_270_Mapping_MMM.btm`

| Árbol | Root | Referencia |
| --- | --- | --- |
| Origen (`SrcTree`) | `Root` | `.\EligibilityRequest.xsd` |
| Destino (`TrgTree`) | `X12_00501_270` | `.\X12_00501_270.xsd` |

### 7.1 Valores constantes (`ConstantValues`)

| Valor | Elemento destino | Significado X12 |
| --- | --- | --- |
| `270` | `ST/ST01` | Código de transacción |
| `0001` | `ST/ST02` | Control number del transaction set |
| `005010X279A1` | `ST/ST03` | Implementation convention reference |
| `0022` | `BHT/BHT01` | Estructura jerárquica: información, subscriber, dependent |
| `13` | `BHT/BHT02` | Propósito: request |
| `SY` | `HLLoop1/NM1Loop1/REF/REF01` | Social Security Number |
| `D8` | `HLLoop1/NM1Loop1/DMG/DMG01` | Formato de fecha CCYYMMDD |
| `291` | `HLLoop1/NM1Loop1/DTP/DTP01` | Plan |
| `D8` | `HLLoop1/NM1Loop1/DTP/DTP02` | Formato de fecha |
| `30` | `HLLoop1/NM1Loop1/EQLoop1/EQ/EQ01` | Service type: Health Benefit Plan Coverage |

**Hallazgo:** `BHT03` (reference identification) no se asigna en el mapping.

**Hallazgo:** los `ConstantValues` apuntan al primer `HLLoop1/NM1Loop1` del schema destino,
pero los loops HL reales los emite el functoid XSLT con valores inline. En la práctica los
constantes que importan son los de `ST` y `BHT`; los de `REF01`, `DMG01`, `DTP01`, `DTP02` y
`EQ01` están duplicados dentro del XSLT.

### 7.2 Functoids

| ID | Tipo | Destino | Contenido |
| --- | --- | --- | --- |
| 5 | C# | `BHT/BHT04` | `System.DateTime.Now.ToString("yyyyMMdd")` |
| 6 | C# | `BHT/BHT05` | `System.DateTime.Now.ToString("HHmmssff")` |
| 19 | XSLT | `HLLoop1` | Genera la jerarquía HL completa |

Los functoids 5 y 6 usan `DateTime.Now`, o sea la hora local del host de ejecución. Los
workflows, en cambio, usan explícitamente `convertTimeZone(..., 'SA Western Standard Time')`
para el nombre del archivo. Son dos fuentes de hora distintas.

### 7.3 Loop HL 1 — Information Source (fijo)

| Segmento | Elemento | Valor | Significado |
| --- | --- | --- | --- |
| `HL` | `HL01` | `1` | ID jerárquico |
| | `HL03` | `20` | Information Source |
| | `HL04` | `1` | Tiene hijos |
| `NM1` | `NM101` | `PR` | Payer |
| | `NM102` | `2` | Persona jurídica |
| | `NM103` | `PRMMIS` | Nombre del payer |
| | `NM108` | `PI` | Payor Identification |
| | `NM109` | `PRMP` | ID del payer |

### 7.4 Loop HL 2 — Information Receiver (fijo)

| Segmento | Elemento | Valor |
| --- | --- | --- |
| `HL` | `HL01` | `2` |
| | `HL02` | `1` (padre = HL 1) |
| | `HL03` | `21` (Information Receiver) |
| | `HL04` | `1` |
| `NM1` | `NM101` | `P5` (Plan Sponsor) |
| | `NM102` | `2` |
| | `NM103` | `MMM` |
| | `NM108` | `SV` (Service Provider Number) |
| | `NM109` | `000002700` |

### 7.5 Loops HL 3..N — Subscriber (uno por registro)

Itera con `xsl:for-each select="/s0:Root/Record"`. Declara una variable `$spaces` con 50
espacios que se usa para el relleno a la derecha.

| Segmento | Elemento | Regla |
| --- | --- | --- |
| `HL` | `HL01` | `position() + 2` (empieza en 3) |
| | `HL02` | `2` (padre = HL 2) |
| | `HL03` | `22` (Subscriber) |
| | `HL04` | `0` (sin hijos, no se envían dependientes) |
| `TRN` | `TRN01` | `1` (Current Transaction Trace Numbers) |
| | `TRN02` | `normalize-space(Filler1)` |
| | `TRN03` | `0000690320` (submitter MMM, hardcodeado) |
| `NM1` | `NM101` | `IL` (Insured or Subscriber) |
| | `NM102` | `1` (persona natural) |
| | `NM103` | Apellido compuesto, ver abajo |
| | `NM104` | `FirstName` rellenado a la derecha y truncado a 20 |
| | `NM108` | `MI` (Member Identification Number) |
| | `NM109` | `substring(normalize-space(MPI), 3)` |
| `REF` | `REF01` | `SY` |
| | `REF02` | `normalize-space(SocialSecurityNumber)` |
| `DMG` | `DMG01` | `D8` |
| | `DMG02` | `normalize-space(DateOfBirth)` |
| | `DMG03` | `Sex`: `1` a `M`, `2` a `F`, cualquier otro a `U` |
| `DTP` | `DTP01` | `291` |
| | `DTP02` | `D8` |
| | `DTP03` | `normalize-space(EffectiveDate)` |
| `EQ` | `EQ01` | `30` |

#### Regla del apellido compuesto (`NM103`)

```xml
<NM103>
    <xsl:value-of select="normalize-space(LastName)" />
    <xsl:choose>
        <xsl:when test="string-length(normalize-space(SecondLastName)) > 0">
            <xsl:text>|</xsl:text>
            <xsl:value-of select="substring(concat(normalize-space(SecondLastName), $spaces), 1, 15)" />
        </xsl:when>
        <xsl:otherwise>
            <xsl:text> </xsl:text>
        </xsl:otherwise>
    </xsl:choose>
</NM103>
```

`NM103` queda como `PRIMERAPELLIDO|SEGUNDOAPELLIDO` donde el segundo apellido va rellenado a
exactamente 15 caracteres. Esto es un **acuerdo bilateral con ASES**: el pipe dentro de un
elemento X12 no es estándar del guide 005010X279A1, y el mapping del 271 hace la operación
inversa (`substring-before` / `substring-after` por `|`).

**Hallazgo:** cuando no hay segundo apellido se emite un espacio literal en lugar de omitir
el separador, por lo que `NM103` termina con un espacio final.

#### Regla del MPI (`NM109`)

`substring(normalize-space(MPI), 3)` descarta los dos primeros caracteres del MPI de 13
posiciones. El mapping del 271 hace la inversa rellenando con ceros a la izquierda hasta 13.
El prefijo de dos caracteres nunca viaja en el X12.

## 8. Cadena de correlación 270 a 271

```mermaid
flowchart LR
    A["Flat file .qry<br/>campo Filler1"]
    B["X12 270<br/>TRN02 con TRN01=1"]
    C["ASES / PRMMIS"]
    D["X12 271<br/>TRN02 con TRN01=2"]
    E["Flat file .res<br/>campo Filler3"]

    A --> B --> C --> D --> E
```

El legado debe poblar `Filler1` con su identificador de correlación y luego leerlo de vuelta
en `Filler3` del archivo `.res`.

**Hallazgo:** el 271 escribe en `Filler3` el `TRN02` del segmento con `TRN01=2`, que es el
trace **asignado por el payer en la respuesta**, no necesariamente el mismo valor que se
envió en el `TRN01=1` de la consulta. Si ASES no repite el trace original, la correlación se
rompe.

## 9. Diferencias MMM vs PMC

En los workflows, solo cambian la carpeta vigilada y el literal `company` (ver sección 3).

En los mappings, `X12_270_Mapping_PMC.btm` es una copia de la versión MMM con **un solo
cambio funcional**:

| Elemento | MMM | PMC | ¿Correcto? |
| --- | --- | --- | --- |
| `TRN03` (subscriber) | `0000690320` | `0000690330` | Sí |
| `NM103` del HL 2 | `MMM` | `MMM` | **No** |
| `NM109` del HL 2 | `000002700` | `000002700` | **No** |
| Todo lo demás | idéntico | idéntico | — |

**Hallazgo crítico:** el loop HL 2 (Information Receiver) del mapping de PMC sigue
identificándose como `MMM` con el service provider number `000002700`. Las consultas de PMC
salen hacia PRMMIS declarando a MMM como Information Receiver. Es un típico error de
copiar y pegar: alguien duplicó el mapa, cambió el `TRN03` y no revisó el resto.

El único diff no funcional entre los dos archivos son líneas en blanco extra en los bloques
de C#.

## 10. Puntos de falla conocidos

| Escenario | Comportamiento actual |
| --- | --- |
| El `.qry` viene con CRLF | Cubierto: `Compose_File_Content` normaliza a LF |
| Un registro no tiene 151 caracteres | `Decode_flat_file` falla y la ejecución queda en `Failed`. No hay carpeta de errores. |
| `company` distinto de MMM o PMC | Rama `else`, respuesta `99`, que el watcher ignora |
| El mapa `X12_270_Mapping_XXX.xslt` no existe | `Transform_XML` falla en tiempo de ejecución |
| El agreement `XXX_ASES_Eleg_Request` no existe | `Encode_X12` falla |
| Ya existe un archivo con el mismo nombre del día | Depende del conector File System, no del workflow |
| Ráfaga de archivos | Se procesan de a uno por minuto (`maxFileCount: 1`) |
| `Filler1` vacío | `TRN02` queda vacío y se pierde la correlación, sin error |
