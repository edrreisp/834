# 06 — Artefactos, ciclo de build y hallazgos

[Volver al índice](README.md)

## 1. Estructura del repositorio

```
IntegrationAccount/
    IntegrationAccount.sln
    IntegrationAccount/
        IntegrationAccount.btproj
        LogicApps/
            ma-x12-dev-eligibility-asesrecon-lapp/workflows/    6 workflows
            ma-x12-dev-enrollment-asesrecon-lapp/workflows/     6 workflows
        Mappings/
            270/      2 mapas, 2 schemas
            271/      2 mapas, 2 schemas
            820/      1 schema, sin flujo
            834/
                X12_00501_834.xsd
                Inbound/     2 mapas, 1 schema destino
                Outbound/    2 mapas
                Schemas/Source/    34 XSD del XML canonico
docs/                          esta documentacion
README.md                      plantilla sin llenar
```

## 2. Inventario de workflows

| Workflow | Logic App | Tipo | Trigger |
| --- | --- | --- | --- |
| [watch-270-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-270-mmm.json) | eligibility | Watcher | Archivo nuevo |
| [watch-270-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-270-pmc.json) | eligibility | Watcher | Archivo nuevo |
| [qry-to-x12-270.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/qry-to-x12-270.json) | eligibility | Procesador | HTTP |
| [watch-271-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-271-mmm.json) | eligibility | Watcher | Archivo nuevo |
| [watch-271-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-271-pmc.json) | eligibility | Watcher | Archivo nuevo |
| [x12-to-res-271.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/x12-to-res-271.json) | eligibility | Procesador | HTTP |
| [watch-834-inbound-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-inbound-mmm.json) | enrollment | Watcher | Archivo nuevo |
| [watch-834-inbound-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-inbound-pmc.json) | enrollment | Watcher | Archivo nuevo |
| [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) | enrollment | Procesador | HTTP |
| [watch-834-outbound-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-outbound-mmm.json) | enrollment | Watcher | Archivo nuevo |
| [watch-834-outbound-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-outbound-pmc.json) | enrollment | Watcher | Archivo nuevo |
| [xml-to-x12-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/xml-to-x12-834.json) | enrollment | Procesador | HTTP |

## 3. Inventario de mappings

| Mapa | Origen | Destino | ¿MMM y PMC difieren? |
| --- | --- | --- | --- |
| [X12_270_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_MMM.btm) | `EligibilityRequest.xsd` | `X12_00501_270.xsd` | Sí, solo `TRN03` |
| [X12_270_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_PMC.btm) | idem | idem | |
| [X12_271_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_MMM.btm) | `X12_00501_271.xsd` | `EligibilityResponse.xsd` | No, idénticos |
| [X12_271_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_PMC.btm) | idem | idem | |
| [X12_834_Inbound_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | `X12_00501_834.xsd` | `EnrollmentRequestInbound.xsd` | No, idénticos |
| [X12_834_Inbound_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_PMC.btm) | idem | idem | |
| [X12_834_Outbound_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Outbound/X12_834_Outbound_Mapping_MMM.btm) | `X220A1.xsd` | `X12_00501_834.xsd` | No, idénticos |
| [X12_834_Outbound_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Outbound/X12_834_Outbound_Mapping_PMC.btm) | idem | idem | |

De los cuatro pares, **tres son copias exactas** y el cuarto difiere en un solo valor. Ver el
hallazgo H-06.

## 4. Inventario de schemas

### Schemas EDI X12 (generados desde los guides)

Los cuatro usan el `targetNamespace` estándar de BizTalk EDI,
`http://schemas.microsoft.com/BizTalk/EDI/X12/2006`, y declaran `standard="EDI"`.

| Schema | Transacción | Usado por |
| --- | --- | --- |
| [X12_00501_270.xsd](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_00501_270.xsd) | 270 | Destino del mapping 270 |
| [X12_00501_271.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_00501_271.xsd) | 271 | Origen del mapping 271 |
| [X12_00501_834.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/X12_00501_834.xsd) | 834 | Origen del inbound, destino del outbound |
| [X12_00501_820.xsd](../IntegrationAccount/IntegrationAccount/Mappings/820/X12_00501_820.xsd) | 820 | **Ninguno** |

### Schemas de flat file (contratos con el legado)

| Schema | Registro | Longitud | Delimitador |
| --- | --- | --- | --- |
| [EligibilityRequest.xsd](../IntegrationAccount/IntegrationAccount/Mappings/270/EligibilityRequest.xsd) | 13 campos | 151 caracteres | `0x0A`, postfix |
| [EligibilityResponse.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/EligibilityResponse.xsd) | 31 campos | 269 caracteres | `0x0A 0x0A`, prefix |
| [EnrollmentRequestInbound.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/EnrollmentRequestInbound.xsd) | 5 tipos de registro | 739 caracteres cada uno | `0xD 0xA`, postfix |

### Schemas del XML canónico de salida

Los 34 archivos de
[Mappings/834/Schemas/Source](../IntegrationAccount/IntegrationAccount/Mappings/834/Schemas/Source),
todos en el namespace `http://MMM_Membership_QNXT_EHub_LIB/X12/X220A1`. Detalle del árbol en
[05-transaccion-834-outbound.md](05-transaccion-834-outbound.md#51-inventario-de-los-34-schemas).

## 5. Ciclo de build y despliegue

```mermaid
flowchart LR
    BTM[".btm en Mappings/<br/>(lo que hay en el repo)"]
    Build["Build del proyecto<br/>IntegrationAccount.btproj"]
    XSLT[".xslt compilado"]
    Deploy["Despliegue a la Logic App"]
    Artifacts["Artifacts/Maps y Artifacts/Schemas<br/>de la Logic App Standard"]
    Runtime["Accion Xslt / FlatFile*<br/>source: LogicApp"]

    BTM --> Build --> XSLT --> Deploy --> Artifacts --> Runtime
```

El eslabón crítico: los workflows referencian los mapas por nombre **con extensión `.xslt`**:

```
"name": "@concat('X12_270_Mapping_', outputs('Compose_Company'), '.xslt')"
```

pero el repositorio versiona `.btm`. Los `.btm` son archivos del BizTalk Mapper (XML con XSLT
embebido en nodos `<Functoid>`), no consumibles directamente por el runtime.

El proyecto [IntegrationAccount.btproj](../IntegrationAccount/IntegrationAccount/IntegrationAccount.btproj)
importa `Microsoft\Azure Integration SDK\IntegrationTasks.targets`, que es el target que hace
esa compilación. Es decir, el mecanismo existe, pero:

**Hallazgo H-01 (alto):** el `.btproj` está desactualizado y no compila los artefactos que
los flujos realmente usan. Ver la sección 6.

**Hallazgo H-02 (alto):** no hay pipeline, script ni documento en el repositorio que describa
cómo pasar de `.btm` a `.xslt` ni cómo subir el resultado a la Logic App. Tampoco hay
`connections.json`, `parameters.json`, `host.json` ni IaC (Bicep/ARM/Terraform). Los
workflows del repositorio no se pueden desplegar desde cero con lo que está versionado.

## 6. Estado del proyecto de Visual Studio

[IntegrationAccount.btproj](../IntegrationAccount/IntegrationAccount/IntegrationAccount.btproj)
quedó atrás cuando los archivos se reorganizaron bajo `Mappings/`. Comparación de lo que el
proyecto declara contra lo que existe en disco:

| Referencia en el `.btproj` | ¿Existe? | Ubicación real |
| --- | --- | --- |
| `270\EligibilityRequest.xsd` | No | `Mappings\270\EligibilityRequest.xsd` |
| `270\X12_00501_270.xsd` | No | `Mappings\270\X12_00501_270.xsd` |
| `270\X12_270_Mapping_MMM.btm` | No | `Mappings\270\X12_270_Mapping_MMM.btm` |
| `270\X12_270_Mapping_PMC.btm` | No | `Mappings\270\X12_270_Mapping_PMC.btm` |
| `271\EligibilityResponse.xsd` | No | `Mappings\271\EligibilityResponse.xsd` |
| `271\X12_00501_271.xsd` | No | `Mappings\271\X12_00501_271.xsd` |
| `271\X12_271_Mapping.btm` | **No existe con ese nombre** | Se dividió en `_MMM` y `_PMC` |
| `820\X12_820.xsd` | **No existe con ese nombre** | Ahora es `Mappings\820\X12_00501_820.xsd` |
| `834\X12_834.xsd` | **No existe con ese nombre** | Ahora es `Mappings\834\X12_00501_834.xsd` |
| `<Folder Include="834\Inbound\" />` | No | `Mappings\834\Inbound\` |

Y lo que falta declarar por completo:

- Los dos mapas de 271 (`X12_271_Mapping_MMM.btm`, `X12_271_Mapping_PMC.btm`)
- Los cuatro mapas de 834 (inbound y outbound, MMM y PMC)
- `EnrollmentRequestInbound.xsd`
- Los 34 XSD de `Mappings\834\Schemas\Source\`

**Hallazgo H-03 (medio):** `X12_270_Mapping_PMC.btm` está declarado con
`<TypeName>X12_270_Mapping_MMM_Copy</TypeName>`. El nombre delata el origen del archivo y
además no coincide con el nombre del mapa.

```xml
<Map Include="270\X12_270_Mapping_PMC.btm">
    <SubType>Task</SubType>
    <TypeName>X12_270_Mapping_MMM_Copy</TypeName>
    <Namespace>IntegrationAccount._270</Namespace>
</Map>
```

**Hallazgo H-04 (bajo):** el [README.md](../README.md) de la raíz sigue siendo la plantilla de
Azure DevOps con todos los `TODO:` sin llenar.

## 7. Catálogo de hallazgos

Severidad: **Alto** = puede provocar datos incorrectos en producción o impedir el despliegue.
**Medio** = riesgo operativo o de mantenimiento. **Bajo** = higiene del código.

### 7.1 Bugs funcionales

| ID | Severidad | Dónde | Descripción |
| --- | --- | --- | --- |
| H-05 | **Alto** | [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) | El `Create_file` está copiado de `x12-to-res-271`: escribe en `QUERYRESPONSE\InProcess\{COMPANY}` con nombre `..._271_yyyyMMdd.res`, y el `folderPath` empieza con **un solo backslash** (`\1alexandria2...` en vez de `\\1alexandria2...`). Colisiona con el archivo del flujo 271. Ver [04, sección 4.2](04-transaccion-834-inbound.md#42-escritura-del-archivo-de-salida) |
| H-06 | **Alto** | [X12_270_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_PMC.btm) | El loop HL 2 (Information Receiver) conserva la identidad de MMM: `NM103=MMM`, `NM109=000002700`. Las consultas de PMC se identifican como MMM ante PRMMIS. El único valor que se ajustó al duplicar el mapa fue `TRN03`. Ver [02, sección 9](02-transaccion-270.md#9-diferencias-mmm-vs-pmc) |
| H-07 | **Alto** | [X12_834_Inbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | El registro `InsuranceCOB` se emite dentro de un `for-each` sobre los loops COB, pero el schema lo declara `minOccurs=1 maxOccurs=1`. Un afiliado sin otro seguro produce cero registros y uno con dos seguros produce dos; en ambos casos el XML no valida. Ver [04, sección 6.12](04-transaccion-834-inbound.md#612-registro-insurancecob-cardinalidad-inconsistente) |
| H-08 | Medio | [xml-to-x12-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/xml-to-x12-834.json) | El nombre del archivo de salida lleva el código de transacción `270` en lugar de `834` |
| H-09 | Medio | Los cuatro procesadores | Todos usan el agreement `{COMPANY}_ASES_Eleg_Request`, incluidos los dos flujos de 834. Un agreement X12 define delimitadores, envelope y validaciones, así que el 834 hereda la configuración de elegibilidad |
| H-10 | Medio | [x12-to-res-271.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/x12-to-res-271.json) y [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) | El `Create_file` está dentro del `foreach` interno con un nombre que solo depende de compañía y fecha. Con más de un transaction set por interchange, todas las iteraciones escriben el mismo nombre |
| H-11 | Medio | Los cuatro procesadores | El nombre del archivo de salida tiene granularidad de día (`yyyyMMdd`). Dos corridas del mismo flujo y compañía en la misma fecha generan el mismo nombre |
| H-12 | Medio | [watch-834-outbound-*.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-outbound-mmm.json) | El filtro por compañía es `contains(upper(Name), 'MMM')` / `'PMC'`. Cualquier archivo cuyo nombre contenga esas letras por casualidad se procesa como si fuera de esa compañía |
| H-13 | Medio | [watch-834-inbound-*.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-inbound-mmm.json) | Los dos watchers vigilan la misma carpeta filtrando por `690320` / `690330`. Un archivo con ambos números se procesa dos veces; uno sin ninguno no se procesa y no genera alerta |

### 7.2 Manejo de errores y observabilidad

| ID | Severidad | Dónde | Descripción |
| --- | --- | --- | --- |
| H-14 | **Alto** | Los ocho watchers | La acción `Call_workflow_in_this_logic_app` no inspecciona la respuesta del procesador. Un código de error `99` no marca la ejecución del watcher como fallida y queda invisible en el historial |
| H-15 | Medio | [qry-to-x12-270.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/qry-to-x12-270.json) y [xml-to-x12-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/xml-to-x12-834.json) | El `If` llamado `Generation_x12` evalúa `equals("", "")`, siempre verdadero. La rama `else` con `Error_Response_in_x12` es código inalcanzable y el `If` es un envoltorio sin efecto |
| H-16 | Medio | [qry-to-x12-270.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/qry-to-x12-270.json) y [xml-to-x12-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/xml-to-x12-834.json) | `Validate_XML` corre pero su resultado no se evalúa: el `If` posterior solo compara la compañía. La validación de schema solo sirve como barrera de fallo, no produce una respuesta de error controlada |
| H-17 | Medio | Todos los flujos | Sin `runAfter` con `FAILED`, sin `Scope` con manejo de excepciones, sin reintentos explícitos y sin carpeta de errores. Un fallo deja el archivo de origen en su carpeta y la ejecución en `Failed` |
| H-18 | Medio | Los ocho watchers | Ninguno mueve, archiva ni borra el archivo de origen. La no reprocesación depende enteramente del estado interno del trigger `onnewfile` |
| H-19 | Bajo | [x12-to-res-271.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/x12-to-res-271.json) y [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) | Solo se lee `interchange.functionalGroups` de la salida de `Decode_X12`. Los interchanges y transaction sets rechazados por el agreement se descartan en silencio |
| H-20 | Bajo | Los cuatro procesadores | Todas las respuestas devuelven HTTP 200; el resultado viaja en el cuerpo (`0` u `99`). Además `qry-to-x12-270` devuelve `0` en éxito mientras los otros tres no devuelven cuerpo |

### 7.3 Reglas de negocio implícitas y frágiles

| ID | Severidad | Dónde | Descripción |
| --- | --- | --- | --- |
| H-21 | Medio | Mappings 270, 271, 834 in/out | El carácter `|` se usa como separador dentro de elementos X12: `NM103` (apellido compuesto), `EB05` (programa y cobertura), `HD04` (código y valor del atributo del plan), `REF02` del loop 2700 (trading partners), `NM103` del contacto. Es un acuerdo bilateral con ASES que no está documentado en ninguna parte del repositorio fuera de este documento |
| H-22 | Medio | [X12_834_Inbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | El patrón "primera ocurrencia = actual, segunda = nuevo" (`[1]` / `[2]`) para los loops `HD04`, `PCP1`, `PCP2` y `PMG1` depende del orden en que ASES emita los loops. Una tercera ocurrencia se descarta sin aviso |
| H-23 | Medio | [X12_834_Inbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | El catálogo de nueve trading partners (`690150` a `690900`) está incrustado en el XSLT y **duplicado cuatro veces**: dos veces por archivo (carrier actual y nuevo) y en los dos archivos de compañía. Un trading partner desconocido produce carrier vacío sin error |
| H-24 | Bajo | Mappings 270, 271, 834 inbound | Tres convenciones distintas para el mismo concepto de género: el 270 usa `M`/`F`/`U`, el 271 usa `1`/`2` sin default (deja vacío) y el 834 inbound usa `1`/`2`/`3` |
| H-25 | Bajo | [X12_834_Inbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | El valor centinela `9998` para ZIP+4 cuando el ZIP tiene 5 dígitos no está documentado en el schema |
| H-26 | Bajo | [X12_270_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_MMM.btm) | Los functoids de C# usan `System.DateTime.Now` (hora local del host) para `BHT04` y `BHT05`, mientras los workflows usan `convertTimeZone(..., 'SA Western Standard Time')` para el nombre del archivo. Dos fuentes de hora distintas |
| H-27 | Bajo | [X12_270_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_MMM.btm) | Cuando no hay segundo apellido, `NM103` emite un espacio literal en lugar de omitir el separador, dejando un espacio final |
| H-28 | Bajo | [X12_271_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_MMM.btm) | `DTP03` se parsea con guion como separador de rango sin verificar que `DTP01` sea de tipo rango. Con una fecha simple, la fecha de expiración queda vacía |

### 7.4 Datos que se pierden en cada dirección

| ID | Severidad | Dónde | Descripción |
| --- | --- | --- | --- |
| H-29 | Medio | [X12_834_Outbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Outbound/X12_834_Outbound_Mapping_MMM.btm) | Asimetría sistemática con el inbound: el flujo saliente **no genera** el loop 2320 (coordinación de beneficios) ni el 2700 (trading partners), y no mapea `INS12` (defunción), `DMG04` (estado civil), `LUI` (idiomas), `DMG/C056` (raza y etnia), `PER05`/`PER06`, `HD02` ni los `REF` de `HealthRef`. Todos esos datos el inbound sí los recibe. Ver [05, secciones 6.3 y 6.4](05-transaccion-834-outbound.md#64-loops-del-834-que-este-mapping-no-genera) |
| H-30 | Bajo | [X12_270_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/270/X12_270_Mapping_MMM.btm) | Cuatro campos del `.qry` no alimentan ningún segmento EDI: `RecordType`, `ProcessDate`, `Region`, `Carrier` |
| H-31 | Bajo | [X12_271_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_MMM.btm) | Siete campos del `.res` nunca se llenan: `InquiryRegion`, `Region`, `MessageCode`, `DeductibleLevel`, `InquiryEffectiveDate`, `Filler1`, `Filler2`. Cinco más (`Program`, las dos fechas de elegibilidad, `Municipality`, `HealthCoverage`) solo se llenan si `EB01='1'` |
| H-32 | Bajo | [X12_271_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_MMM.btm) | Los bloques "inquiry" (campos 2 a 10) y "response" (11 a 16) del `.res` reciben los mismos valores del mismo `NM1Loop1`, así que la distinción del schema no aporta nada hoy |
| H-33 | Bajo | [X12_834_Inbound_Mapping_*.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm) | El registro `Household` se emite con los 18 campos de personas vacíos: la estructura existe pero la funcionalidad no. `Municipality` y `Facility` salen fijos en `0000`, `EligibilityIndicator` siempre `Y` (incluso en bajas) y `EffectiveDate` del risk score siempre `00000000` |

### 7.5 Higiene de schemas y nombres

| ID | Severidad | Dónde | Descripción |
| --- | --- | --- | --- |
| H-34 | Bajo | [EnrollmentRequestInbound.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/EnrollmentRequestInbound.xsd) | `Household Person 18` declara `pos_length="312"` mientras las personas 1 a 17 declaran 11. Es lo que hace que el registro llegue a 739 caracteres, así que parece un ajuste manual de longitud |
| H-35 | Bajo | [EnrollmentRequestInbound.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/EnrollmentRequestInbound.xsd) | El registro `InsuranceCOB` tiene un campo llamado `ProcesDate` (falta una `s`). El mapping usa el mismo nombre, así que funciona |
| H-36 | Bajo | [EligibilityResponse.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/EligibilityResponse.xsd) | El delimitador de registros es doble LF (`0x0A 0x0A`) en modo `prefix`, mientras el request usa LF simple en modo `postfix`. Conviene confirmar con el equipo del legado que es lo que su parser espera |
| H-37 | Bajo | [FunctionalGroupOfF5010X022A1.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Schemas/Source/FunctionalGroupOfF5010X022A1.xsd) | El nombre del archivo dice `X022A1` pero el tipo que define es `FGOfF5010X220A1`. Errata en el nombre; no se puede renombrar sin actualizar el `xsd:include` de `FG.xsd` |
| H-38 | Bajo | [X12_00501_820.xsd](../IntegrationAccount/IntegrationAccount/Mappings/820/X12_00501_820.xsd) | El schema del 820 está en el repositorio sin ningún flujo, mapping ni workflow que lo use |
| H-39 | Bajo | [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) | Declara `"type": "Foreach"` mientras `x12-to-res-271` declara `"type": "foreach"`. Cosmético, pero delata la copia |
| H-40 | Bajo | Los pares de mappings | Tres de los cuatro pares MMM/PMC son copias exactas y el cuarto difiere en un valor. La duplicación no aporta y ya causó H-06 |

## 8. Recomendaciones priorizadas

Esta sección es una propuesta, no una descripción de lo implementado.

### Corregir primero

1. **H-05** — Arreglar la ruta, el nombre y el doble backslash del `Create_file` de
   `x12-to-exp-834`. Es el único hallazgo que hoy puede estar corrompiendo el archivo de otro
   flujo.
2. **H-06** — Corregir `NM103` y `NM109` del HL 2 en el mapping de PMC con la identidad real
   de PMC.
3. **H-07** — Ajustar la cardinalidad de `InsuranceCOB` en `EnrollmentRequestInbound.xsd` a
   `minOccurs="0" maxOccurs="unbounded"`, o cambiar el mapping para emitir siempre
   exactamente uno.
4. **H-14** — Hacer que los watchers evalúen el cuerpo de la respuesta y fallen la ejecución
   cuando reciban `99`.

### Reducir el riesgo operativo

5. **H-11** — Agregar hora al nombre del archivo de salida (`HHmmss`) para eliminar las
   colisiones del mismo día.
6. **H-17 / H-18** — Agregar manejo de excepciones y mover el archivo procesado a una carpeta
   de `Processed` o `Error`, de forma que el estado no dependa solo del trigger.
7. **H-09** — Crear agreements X12 separados para el 834 en lugar de reutilizar los de
   elegibilidad.
8. **H-12 / H-13** — Reemplazar los filtros por `contains` con una convención de nombres
   estricta o carpetas separadas por compañía, como ya hacen el 270 y el 271.

### Mantenimiento

9. **H-40** — Consolidar cada par de mappings idénticos en un solo archivo y parametrizar lo
   que de verdad varía por compañía.
10. **H-01 / H-03** — Reconstruir el `.btproj` con las rutas reales bajo `Mappings\` y todos
    los artefactos que hoy faltan.
11. **H-02** — Versionar `connections.json`, `parameters.json` y `host.json`, y agregar un
    pipeline que compile los `.btm` y despliegue los artefactos.
12. **H-15 / H-16** — Eliminar el `If` muerto `Generation_x12` y hacer que el resultado de
    `Validate_XML` sí condicione una respuesta de error.
13. **H-21** — Documentar formalmente el acuerdo bilateral del separador `|` con ASES.
14. **H-23** — Externalizar el catálogo de trading partners a un artefacto único en lugar de
    tenerlo cuatro veces en XSLT.
15. **H-04** — Llenar el `README.md` de la raíz apuntando a esta carpeta `docs/`.
