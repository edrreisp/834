# 01 — Arquitectura

[Volver al índice](README.md)

## 1. Componentes

```mermaid
flowchart TB
    subgraph share ["Recurso compartido SMB: 1alexandria2.dev.pr.mmmhc.com, carpeta manifiesto / jobs / ASES"]
        direction LR
        F1["ENRASES_QUERYFILE"]
        F2["QUERYRESPONSE"]
        F3["ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2"]
        F4["ENRASES_ENROLLMENTFILE"]
    end

    subgraph la1 ["Logic App Standard: ma-x12-dev-eligibility-asesrecon-lapp"]
        direction TB
        LA1W["3 watchers x 2 companias<br/>(270 MMM, 270 PMC, 271 MMM, 271 PMC)"]
        LA1P["2 procesadores<br/>qry-to-x12-270, x12-to-res-271"]
    end

    subgraph la2 ["Logic App Standard: ma-x12-dev-enrollment-asesrecon-lapp"]
        direction TB
        LA2W["4 watchers<br/>(834 in MMM/PMC, 834 out MMM/PMC)"]
        LA2P["2 procesadores<br/>x12-to-exp-834, xml-to-x12-834"]
    end

    subgraph ia ["Artefactos de integracion"]
        Schemas["Schemas XSD<br/>flat file y X12"]
        Maps["Mapas XSLT<br/>compilados desde .btm"]
        Agreements["Agreements X12<br/>MMM_ASES_Eleg_Request<br/>PMC_ASES_Eleg_Request"]
    end

    share <-->|"conector File System"| la1
    share <-->|"conector File System"| la2
    la1 --> ia
    la2 --> ia
```

Los 12 workflows del repositorio son todos `"kind": "Stateful"`.

## 2. El patrón watcher + procesador

Todos los flujos están partidos en dos workflows. Esto se repite exactamente igual en las
cuatro transacciones.

```mermaid
flowchart LR
    subgraph watcher ["Watcher (1 por transaccion y por compania)"]
        T["Trigger: When a file is created<br/>(properties only)"]
        G["Get_file_content"]
        C["Call_workflow_in_this_logic_app"]
        T --> G --> C
    end

    subgraph processor ["Procesador (1 por transaccion, compartido por MMM y PMC)"]
        H["Trigger: When an HTTP request is received"]
        L["Logica EDI:<br/>decode, validate, transform, encode"]
        W["Create_file"]
        R["Response"]
        H --> L --> W
        L --> R
    end

    C -->|"HTTP: fileContent + company"| H
```

### 2.1 Responsabilidades

| Rol | Qué hace | Qué NO hace |
| --- | --- | --- |
| **Watcher** | Detecta el archivo nuevo, lo lee completo, convierte el contenido a texto y llama al procesador pasando el nombre de la compañía. | No mueve, archiva ni borra el archivo de origen. No inspecciona la respuesta del procesador. |
| **Procesador** | Decodifica/valida/transforma/codifica y escribe el archivo de salida. Devuelve un código de resultado por HTTP. | No conoce la ruta del archivo de origen ni su nombre. Solo recibe el contenido y la compañía. |

### 2.2 Contrato entre watcher y procesador

El watcher invoca al procesador con una acción de tipo `Workflow`:

```json
{
    "type": "Workflow",
    "inputs": {
        "host": { "workflow": { "id": "qry-to-x12-270" } },
        "body": {
            "fileContent": "@base64ToString(body('Get_file_content')?['$content'])",
            "company": "MMM"
        }
    }
}
```

Es decir, el contrato es un objeto de dos propiedades:

| Propiedad | Contenido |
| --- | --- |
| `fileContent` | Contenido completo del archivo, decodificado de base64 a texto |
| `company` | Literal `"MMM"` o `"PMC"`, fijo en cada watcher |

Del lado del procesador, las dos primeras acciones normalizan esa entrada:

```json
"Compose_Company": { "type": "Compose", "inputs": "@toUpper(trim(triggerBody()?['company']))" },
"Compose_File_Content": { "type": "Compose", "inputs": "@triggerBody()?['fileContent']" }
```

`Compose_Company` es la pieza central del diseño multi-compañía: su salida se usa después
para construir el nombre del mapa XSLT, el nombre del agreement X12, la carpeta de salida
y el prefijo del nombre de archivo.

Única excepción: en `qry-to-x12-270` la acción `Compose_File_Content` además normaliza los
saltos de línea, porque el schema flat file usa `0x0A` como delimitador de registro y el
archivo del legado puede venir con CRLF:

```json
"inputs": "@replace(triggerBody()?['fileContent'], decodeUriComponent('%0D%0A'), decodeUriComponent('%0A'))"
```

**Hallazgo:** esa normalización solo existe en el flujo 270. `xml-to-x12-834` pasa el
contenido tal cual, lo cual está bien porque es XML, pero conviene tenerlo presente si
alguna vez se agrega otro flujo de flat file.

## 3. Conectores y conexiones

Los watchers y las acciones `Create_file` usan el conector administrado **File System**,
que requiere un gateway de datos local para alcanzar el recurso compartido SMB.

| Logic App | `referenceName` de la conexión |
| --- | --- |
| `ma-x12-dev-eligibility-asesrecon-lapp` | `filesystem-7` |
| `ma-x12-dev-enrollment-asesrecon-lapp` | `filesystem` |

**Hallazgo:** las conexiones no están versionadas. El repositorio no contiene
`connections.json`, `parameters.json` ni `host.json`, así que estos nombres de referencia
solo resuelven contra el recurso ya desplegado en Azure. Detalle en
[06-artefactos-y-hallazgos.md](06-artefactos-y-hallazgos.md).

### 3.1 Operaciones del conector usadas

| Operación | Ruta | Uso |
| --- | --- | --- |
| Trigger de archivo nuevo | `GET /datasets/default/triggers/batch/onnewfile` | Todos los watchers |
| Leer contenido | `GET /datasets/default/files/{path}/content` con `inferContentType: true` | Todos los watchers |
| Crear archivo | `POST /datasets/default/files` con `folderPath` y `name`, header `ReadFileMetadataFromServer: true` | Todos los procesadores |

### 3.2 Configuración común del trigger

Los ocho watchers comparten exactamente la misma configuración de trigger:

| Propiedad | Valor | Efecto |
| --- | --- | --- |
| `recurrence` | `1 Minute` | Sondeo cada minuto |
| `maxFileCount` | `1` | Un archivo por ejecución del trigger |
| `splitOn` | `@triggerBody()` | Una ejecución de workflow por archivo detectado |
| `folderId` | Ruta UNC codificada en base64 | Carpeta vigilada |
| `conditions` | Expresiones sobre `triggerBody()?['Name']` | Filtro por extensión y por compañía |

La combinación `maxFileCount: 1` con sondeo de 1 minuto significa que el throughput máximo
teórico es de **60 archivos por hora por watcher**. Si el legado deja una ráfaga de
archivos, se procesan de a uno por minuto.

## 4. Mapa de rutas UNC

Todas las rutas cuelgan de `\\1alexandria2.dev.pr.mmmhc.com\manifiesto\jobs\ASES\`.
Los `folderId` de los triggers están en base64; esta tabla ya viene decodificada.

| Transacción | Compañía | Carpeta de entrada (vigilada) | Filtro de nombre |
| --- | --- | --- | --- |
| 270 | MMM | `ENRASES_QUERYFILE\InProcessAZ\MMM` | `endsWith(lower(name), '_270.qry')` |
| 270 | PMC | `ENRASES_QUERYFILE\InProcessAZ\PMC` | `endsWith(lower(name), '_270.qry')` |
| 271 | MMM | `QUERYRESPONSE\Inbound\MMM` | `endsWith(lower(name), '.x12')` |
| 271 | PMC | `QUERYRESPONSE\Inbound\PMC` | `endsWith(lower(name), '.x12')` |
| 834 in | MMM | `ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2\Inbound` | `endsWith('.x12')` **y** `contains(upper(name), '690320')` |
| 834 in | PMC | `ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2\Inbound` | `endsWith('.x12')` **y** `contains(upper(name), '690330')` |
| 834 out | MMM | `ENRASES_ENROLLMENTFILE\InProcess\XML` | `endsWith('.xml')` **y** `contains(upper(name), 'MMM')` |
| 834 out | PMC | `ENRASES_ENROLLMENTFILE\InProcess\XML` | `endsWith('.xml')` **y** `contains(upper(name), 'PMC')` |

Nótese la diferencia de estrategia: en 270 y 271 la separación MMM/PMC es **por carpeta**,
mientras que en los dos flujos de 834 ambos watchers vigilan **la misma carpeta** y se
distinguen por el nombre del archivo (submitter ID en inbound, nombre de compañía en
outbound).

| Transacción | Compañía | Carpeta de salida (escrita) |
| --- | --- | --- |
| 270 | MMM / PMC | `ENRASES_QUERYFILE\Outbound\{COMPANY}` |
| 271 | MMM / PMC | `QUERYRESPONSE\InProcess\{COMPANY}` |
| 834 in | MMM / PMC | `QUERYRESPONSE\InProcess\{COMPANY}` — **Hallazgo: es la carpeta del 271** |
| 834 out | MMM / PMC | `ENRASES_ENROLLMENTFILE\InProcess\X12` (sin subcarpeta por compañía) |

Los watchers del 270 declaran en `metadata` tanto `InProcess\{COMPANY}` como
`InProcessAZ\{COMPANY}`, pero el `folderId` efectivo del trigger es **`InProcessAZ`**. La
entrada `InProcess` es residuo de una configuración anterior y no tiene efecto.

## 5. Convención de nombres de los archivos de salida

Los cuatro procesadores construyen el nombre con la misma expresión:

```
{submitterId}_{COMPANY}P_{transactionCode}_{yyyyMMdd}.{ext}
```

| Parte | Cómo se calcula |
| --- | --- |
| `submitterId` | `if(equals(company,'MMM'), '690320', '690330')` |
| `COMPANY` | `toUpper(company)` |
| `P` | Literal, inmediatamente después de la compañía (`MMMP`, `PMCP`) |
| `transactionCode` | Literal por flujo |
| `yyyyMMdd` | `formatDateTime(convertTimeZone(utcNow(), 'UTC', 'SA Western Standard Time'), 'yyyyMMdd')` |

`SA Western Standard Time` es UTC-4 sin horario de verano, equivalente a la hora de Puerto
Rico.

Nombres reales generados hoy:

| Flujo | Nombre resultante | Observación |
| --- | --- | --- |
| 270 | `690320_MMMP_270_20260908.x12` | Correcto |
| 271 | `690320_MMMP_271_20260908.res` | Correcto |
| 834 inbound | `690320_MMMP_271_20260908.res` | **Hallazgo:** dice `271` y extensión `.res` |
| 834 outbound | `690320_MMMP_270_20260908.x12` | **Hallazgo:** dice `270` |

**Hallazgo transversal:** el nombre solo tiene granularidad de día. Dos ejecuciones del
mismo flujo y compañía en la misma fecha generan el mismo nombre de archivo. El
comportamiento resultante (sobrescritura o error del conector) depende de la configuración
del conector File System, no del workflow.

## 6. Artefactos de transformación

Las acciones de transformación referencian los artefactos por nombre con
`"source": "LogicApp"`, lo que significa que se resuelven desde las carpetas
`Artifacts\Schemas` y `Artifacts\Maps` de la propia Logic App Standard.

| Acción | Artefacto | Cómo se referencia |
| --- | --- | --- |
| `FlatFileDecoding` / `FlatFileEncoding` | Schema XSD | Nombre literal, p. ej. `EligibilityRequest.xsd` |
| `XmlValidation` | Schema XSD | Nombre literal, p. ej. `X220A1.xsd` |
| `Xslt` | Mapa XSLT | **Nombre dinámico**: `@concat('X12_270_Mapping_', outputs('Compose_Company'), '.xslt')` |

El nombre dinámico del mapa es lo que permite que un solo procesador atienda a MMM y a PMC.
La contrapartida es que un valor de `company` inesperado produce un error de artefacto no
encontrado en tiempo de ejecución, no un error de validación. Por eso los procesadores 270
y 834 outbound envuelven la transformación en un `If` que valida que la compañía sea `MMM`
o `PMC`.

**Hallazgo:** el repositorio versiona los mapas como `.btm` (formato del BizTalk Mapper) en
`IntegrationAccount\IntegrationAccount\Mappings\`, pero el runtime consume `.xslt`. El paso
de compilación y despliegue no está en el repositorio.

### 6.1 Agreements X12

Las acciones `X12Encode` y `X12Decode` resuelven el agreement desde el Integration Account
vinculado a la Logic App:

| Acción | Propiedad | Valor |
| --- | --- | --- |
| `X12Encode` | `agreementName` | `@concat(toUpper(outputs('Compose_Company')),'_ASES_Eleg_Request')` |
| `X12Decode` | `fallbackAgreementName` | `@concat(toUpper(outputs('Compose_Company')),'_ASES_Eleg_Request')` |

Es decir, solo existen dos agreements: `MMM_ASES_Eleg_Request` y `PMC_ASES_Eleg_Request`.

**Hallazgo:** los dos flujos de 834 también usan el agreement `..._Eleg_Request`, que por su
nombre y por su rol en el 270/271 corresponde a elegibilidad. Un agreement X12 define los
delimitadores, el envelope ISA/GS y las reglas de validación por tipo de transacción, así que
compartirlo entre 270/271 y 834 significa que el 834 hereda la configuración de envelope de
elegibilidad. En `X12Decode` se usa además como `fallbackAgreementName`, o sea que solo aplica
cuando el ISA/GS entrante no matchea ningún agreement; en `X12Encode` sí es el agreement
efectivo.

## 7. Manejo de errores y respuestas HTTP

Los procesadores con trigger HTTP devuelven un código numérico en el cuerpo:

| Respuesta | `statusCode` | `body` | Cuándo |
| --- | --- | --- | --- |
| `Success_Response` (270) | 200 | `0` | Después de `Validating_XML` exitoso |
| `Error_Response` (270, 834 out) | 200 | `99` | Rama `else`: la compañía no es MMM ni PMC |
| `Error_Response_in_x12` (270, 834 out) | 200 | `99` | Rama `else` de `Generation_x12` |
| `Success_Response` (271, 834 in, 834 out) | 200 | sin cuerpo | Al final del flujo |

Todo devuelve **HTTP 200**, incluso los errores. El código de error viaja en el cuerpo.

**Hallazgos de manejo de errores:**

1. Los watchers **ignoran la respuesta**. La acción `Call_workflow_in_this_logic_app` no
   inspecciona el cuerpo, así que un `99` no marca la ejecución del watcher como fallida.
   El error queda invisible desde el historial del watcher.
2. La condición `If` llamada `Generation_x12` en `qry-to-x12-270` y en `xml-to-x12-834`
   evalúa `equals("", "")`, que es siempre verdadero. La rama `else` con
   `Error_Response_in_x12` es código inalcanzable, y el `If` es un envoltorio sin efecto:

   ```json
   "Generation_x12": {
       "type": "If",
       "expression": { "and": [ { "equals": [ "", "" ] } ] },
       "actions": { "Create_file": { } },
       "else": { "actions": { "Error_Response_in_x12": { } } }
   }
   ```

3. En `qry-to-x12-270` la acción `Validate_XML` se ejecuta y el `If` posterior depende de
   ella por `runAfter`, pero **no evalúa su resultado**: la expresión del `If` solo compara
   la compañía. La validación de schema sirve entonces solo como barrera de fallo: si el XML
   no valida, la acción falla y el flujo se detiene, pero no hay una respuesta de error
   controlada.
4. Ningún flujo tiene `runAfter` con `FAILED`, ni `Scope` con manejo de excepciones, ni
   política de reintentos explícita, ni escritura a una carpeta de errores. Un fallo de
   transformación o de escritura deja el archivo de origen en su carpeta y la ejecución
   marcada como `Failed` en el historial de la Logic App.
5. Ningún watcher archiva ni mueve el archivo de origen. La no reprocesación depende
   enteramente del estado interno del trigger `onnewfile`.

## 8. Diferencias MMM vs PMC a nivel de workflow

Comparando los pares de watchers, la diferencia es mínima y siempre la misma:

| Par de watchers | Qué cambia |
| --- | --- |
| `watch-270-mmm` / `watch-270-pmc` | `folderId` (`InProcessAZ\MMM` vs `\PMC`), `metadata`, y `company` |
| `watch-271-mmm` / `watch-271-pmc` | `folderId` (`Inbound\MMM` vs `\PMC`), `metadata`, y `company` |
| `watch-834-inbound-mmm` / `-pmc` | Condición `contains('690320')` vs `contains('690330')`, y `company` |
| `watch-834-outbound-mmm` / `-pmc` | Condición `contains('MMM')` vs `contains('PMC')`, y `company` |

Los cuatro **procesadores son únicos** y sirven a ambas compañías; toda la variación por
compañía se resuelve con `outputs('Compose_Company')`.

En cambio, los **mappings sí están duplicados** por compañía (`_MMM.btm` y `_PMC.btm`), lo
que abre la puerta a que las dos versiones se desincronicen. Eso ya ocurrió: ver los
hallazgos de [02-transaccion-270.md](02-transaccion-270.md) y
[03-transaccion-271.md](03-transaccion-271.md).
