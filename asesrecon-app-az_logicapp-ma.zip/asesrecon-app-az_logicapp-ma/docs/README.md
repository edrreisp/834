﻿# Integraciones EDI con ASES â€” DocumentaciÃ³n

Este repositorio contiene los artefactos de las integraciones EDI X12 entre los sistemas
legados de MMM Healthcare / PMC Medicare Choice y **ASES** (el programa Medicaid de Puerto
Rico, operado sobre la plataforma **PRMMIS**).

La implementaciÃ³n vive en dos **Logic Apps Standard** de Azure y en un conjunto de
**mappings BizTalk** (`.btm`) y **schemas** (`.xsd`) que se compilan y despliegan como
artefactos de esas Logic Apps.

## Ãndice

| Documento | Contenido |
| --- | --- |
| [01-arquitectura.md](01-arquitectura.md) | Arquitectura macro, patrÃ³n watcher/procesador, conectores, rutas UNC, convenciones de nombres, agreements X12 |
| [02-transaccion-270.md](02-transaccion-270.md) | Eligibility Inquiry â€” flat file `.qry` del legado hacia X12 270 |
| [03-transaccion-271.md](03-transaccion-271.md) | Eligibility Response â€” X12 271 de ASES hacia flat file `.res` |
| [04-transaccion-834-inbound.md](04-transaccion-834-inbound.md) | Enrollment inbound â€” X12 834 de ASES hacia flat file de enrollment |
| [05-transaccion-834-outbound.md](05-transaccion-834-outbound.md) | Enrollment outbound â€” XML canÃ³nico hacia X12 834 para ASES |
| [06-artefactos-y-hallazgos.md](06-artefactos-y-hallazgos.md) | Inventario de artefactos, ciclo `.btm` a `.xslt`, hallazgos y deuda tÃ©cnica |

## Alcance implementado

Cuatro flujos, cada uno duplicado por compaÃ±Ã­a (MMM y PMC):

| TransacciÃ³n | DirecciÃ³n | Logic App | Estado |
| --- | --- | --- | --- |
| 270 Eligibility Inquiry | Saliente (hacia ASES) | `ma-x12-dev-eligibility-asesrecon-lapp` | Implementado |
| 271 Eligibility Response | Entrante (desde ASES) | `ma-x12-dev-eligibility-asesrecon-lapp` | Implementado |
| 834 Benefit Enrollment | Entrante (desde ASES) | `ma-x12-dev-enrollment-asesrecon-lapp` | Implementado |
| 834 Benefit Enrollment | Saliente (hacia ASES) | `ma-x12-dev-enrollment-asesrecon-lapp` | Implementado |
| 820 Premium Payment | â€” | â€” | Solo existe el schema, sin flujo |

## Vista macro de las cuatro transacciones

```mermaid
flowchart LR
    subgraph legacy ["Sistemas legados MMM / PMC"]
        QryFile["Archivo .qry<br/>flat file posicional"]
        ResFile["Archivo .res<br/>flat file posicional"]
        EnrXml["Archivo .xml<br/>X220A1 canonico"]
        EnrFlat["Flat file enrollment"]
    end

    subgraph eligibility ["Logic App: eligibility"]
        W270["watch-270-mmm / pmc"]
        P270["qry-to-x12-270"]
        W271["watch-271-mmm / pmc"]
        P271["x12-to-res-271"]
    end

    subgraph enrollment ["Logic App: enrollment"]
        W834I["watch-834-inbound-mmm / pmc"]
        P834I["x12-to-exp-834"]
        W834O["watch-834-outbound-mmm / pmc"]
        P834O["xml-to-x12-834"]
    end

    ASES[("ASES / PRMMIS")]

    QryFile --> W270 --> P270 -->|"X12 270 .x12"| ASES
    ASES -->|"X12 271 .x12"| W271 --> P271 --> ResFile
    ASES -->|"X12 834 .x12"| W834I --> P834I --> EnrFlat
    EnrXml --> W834O --> P834O -->|"X12 834 .x12"| ASES
```

Nota importante: las Logic Apps **no hablan directamente con ASES**. Todas escriben y leen
archivos en un recurso compartido de red (`\\1alexandria2.dev.pr.mmmhc.com\manifiesto\...`).
El transporte real hacia y desde ASES lo hace un proceso externo (jobs del legado / SFTP)
que no forma parte de este repositorio.

## Glosario

| TÃ©rmino | Significado |
| --- | --- |
| **ASES** | AdministraciÃ³n de Seguros de Salud de Puerto Rico. Autoridad del programa Medicaid de PR y contraparte EDI de estos flujos. |
| **PRMMIS** | Puerto Rico Medicaid Management Information System. Es el sistema que responde las consultas; aparece hardcodeado como `NM103=PRMMIS` / `NM109=PRMP` en el loop del payer del 270. |
| **MMM** | MMM Healthcare. Submitter ID `690320`. |
| **PMC** | PMC Medicare Choice. Submitter ID `690330`. |
| **MPI** | Master Person Index. Identificador interno de 13 posiciones del afiliado en los sistemas legados. |
| **270 / 271** | Par de transacciones X12 de consulta y respuesta de elegibilidad. Implementation guide `005010X279A1`. |
| **834** | Benefit Enrollment and Maintenance. Implementation guide `005010X220A1`. |
| **820** | Payroll Deducted and Other Group Premium Payment. Schema presente en el repo pero sin flujo. |
| **Agreement** | Acuerdo X12 del Integration Account que define delimitadores, envelope (ISA/GS) y validaciones. AquÃ­: `MMM_ASES_Eleg_Request` y `PMC_ASES_Eleg_Request`. |
| **`.qry`** | ExtensiÃ³n del flat file de consulta de elegibilidad que produce el legado. |
| **`.res`** | ExtensiÃ³n del flat file de respuesta de elegibilidad que consume el legado. |
| **`.x12`** | Archivo EDI X12 crudo (con envelope ISA/IEA). |
| **`InProcess` vs `InProcessAZ`** | ConvenciÃ³n de carpetas usada para separar lo que procesa la plataforma legada (`InProcess`) de lo que procesa Azure (`InProcessAZ`). Los watchers del 270 vigilan `InProcessAZ`. |
| **watcher** | Workflow con trigger de archivo cuya Ãºnica funciÃ³n es detectar el archivo, leerlo e invocar al procesador. |
| **procesador** | Workflow con trigger HTTP que hace la transformaciÃ³n EDI real. |

## ConvenciÃ³n de nombres de los recursos

`ma-x12-dev-eligibility-asesrecon-lapp`

| Segmento | Significado |
| --- | --- |
| `ma` | LÃ­nea de negocio Medicare Advantage |
| `x12` | Dominio EDI X12 |
| `dev` | Ambiente. Los artefactos versionados apuntan al servidor `1alexandria2.dev.pr.mmmhc.com`, es decir, **todo lo que hay en el repo es de desarrollo**. |
| `eligibility` / `enrollment` | Familia de transacciones |
| `asesrecon` | AplicaciÃ³n / proyecto (ASES Reconciliation) |
| `lapp` | Logic App |

## CÃ³mo leer los documentos por transacciÃ³n

Cada documento de transacciÃ³n (02 a 05) sigue la misma estructura:

1. Resumen y contrato del flujo
2. Diagrama macro punta a punta
3. Diagrama de acciones del watcher, con sus `runAfter` reales
4. Diagrama de acciones del procesador
5. Detalle de trigger, rutas y nombres de archivo
6. Layout del flat file o del XML de origen/destino
7. Reglas de negocio del mapping
8. Diferencias MMM vs PMC
9. Puntos de falla conocidos

## Advertencia sobre el estado del repositorio

Los documentos describen **lo que el cÃ³digo hace hoy**, no lo que deberÃ­a hacer. Varios
flujos contienen valores copiados de otra transacciÃ³n y condiciones que nunca evalÃºan a
falso. Todos esos casos estÃ¡n marcados en lÃ­nea con el prefijo **Hallazgo** y consolidados
en [06-artefactos-y-hallazgos.md](06-artefactos-y-hallazgos.md).
