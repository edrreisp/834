# 05 — Transacción 834 Outbound: Benefit Enrollment (saliente)

[Volver al índice](README.md)

## 1. Resumen

El sistema de membresía (QNXT, a través de una librería llamada `MMM_Membership_QNXT_EHub_LIB`)
produce un XML canónico que ya tiene la forma de un 834. El flujo lo valida, lo traduce a la
estructura de segmentos X12 y lo codifica como un 834 para enviar a ASES.

| Aspecto | Valor |
| --- | --- |
| Logic App | `ma-x12-dev-enrollment-asesrecon-lapp` |
| Dirección | Saliente (MMM/PMC hacia ASES) |
| Entrada | XML canónico `X220A1`, extensión `.xml` |
| Salida | X12 834 crudo, extensión `.x12` |
| Implementation guide | `005010X220A1` |
| Workflows | [watch-834-outbound-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-outbound-mmm.json), [watch-834-outbound-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-outbound-pmc.json), [xml-to-x12-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/xml-to-x12-834.json) |
| Schemas | [X220A1.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Schemas/Source/X220A1.xsd) y sus 33 includes, [X12_00501_834.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/X12_00501_834.xsd) |
| Mappings | [X12_834_Outbound_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Outbound/X12_834_Outbound_Mapping_MMM.btm), [X12_834_Outbound_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Outbound/X12_834_Outbound_Mapping_PMC.btm) |

Es el único flujo cuya entrada **no es un flat file**: el legado ya entrega XML. Eso hace que
el mapping sea mucho más directo que el del inbound, porque el XML canónico está diseñado
elemento a elemento contra la estructura del 834.

## 2. Diagrama macro

```mermaid
flowchart TB
    QNXT["Sistema de membresia QNXT<br/>via MMM_Membership_QNXT_EHub_LIB"]
    InFolder["ENRASES_ENROLLMENTFILE / InProcess / XML<br/>archivo *.xml con MMM o PMC en el nombre"]
    WM["watch-834-outbound-mmm<br/>filtro 'MMM'"]
    WP["watch-834-outbound-pmc<br/>filtro 'PMC'"]
    Proc["xml-to-x12-834"]
    OutFolder["ENRASES_ENROLLMENTFILE / InProcess / X12<br/>690320_MMMP_270_yyyyMMdd.x12<br/>-- ver hallazgo de la seccion 4.2"]
    Transport["Proceso externo de transporte<br/>(fuera de este repositorio)"]
    ASES[("ASES / PRMMIS")]

    QNXT --> InFolder
    InFolder --> WM
    InFolder --> WP
    WM -->|"company = MMM"| Proc
    WP -->|"company = PMC"| Proc
    Proc --> OutFolder --> Transport --> ASES
```

Las carpetas de entrada y salida son hermanas dentro de `ENRASES_ENROLLMENTFILE\InProcess`:
`\XML` para lo que produce QNXT y `\X12` para lo que produce este flujo.

## 3. Watcher: `watch-834-outbound-mmm` / `watch-834-outbound-pmc`

```mermaid
flowchart TB
    T["Trigger: When_a_file_is_created_(properties_only)<br/>folderId = ENRASES_ENROLLMENTFILE / InProcess / XML<br/>condicion 1: endsWith(lower(Name), '.xml')<br/>condicion 2: contains(upper(Name), 'MMM')<br/>recurrencia 1 min, maxFileCount 1, splitOn triggerBody()"]
    G["Get_file_content"]
    C["Call_workflow_in_this_logic_app<br/>workflow: xml-to-x12-834<br/>body: fileContent, company = 'MMM'"]

    T --> G
    G -->|"runAfter: SUCCEEDED"| C
```

| Propiedad | `watch-834-outbound-mmm` | `watch-834-outbound-pmc` |
| --- | --- | --- |
| Carpeta vigilada | `ENRASES_ENROLLMENTFILE\InProcess\XML` | **la misma carpeta** |
| Condición 1 | `endsWith(toLower(Name), '.xml')` | idéntica |
| Condición 2 | `contains(toUpper(Name), 'MMM')` | `contains(toUpper(Name), 'PMC')` |
| `company` enviado | `"MMM"` | `"PMC"` |
| Conexión | `filesystem` | `filesystem` |

**Hallazgo:** el filtro por compañía usa el **nombre de la compañía** como subcadena, no un
identificador. Es el filtro más frágil de los ocho watchers: cualquier archivo cuyo nombre
contenga las letras `MMM` en cualquier posición (incluido el nombre del servidor
`mmmhc`, un prefijo corporativo o un nombre compuesto) dispara el watcher de MMM. El flujo
inbound al menos usa los submitter IDs numéricos `690320` / `690330`.

## 4. Procesador: `xml-to-x12-834`

Estructuralmente es **idéntico** a `qry-to-x12-270`, con una sola diferencia: no hay
`Decode_flat_file`, porque la entrada ya es XML.

```mermaid
flowchart TB
    T["Trigger: When_an_HTTP_request_is_received"]
    CC["Compose_Company<br/>toUpper(trim(company))"]
    CFC["Compose_File_Content<br/>triggerBody()?['fileContent'] sin cambios"]
    VX["Validate_XML<br/>XmlValidation contra X220A1.xsd"]
    IF{"Validating_XML<br/>company = MMM o PMC ?"}
    TX["Transform_XML<br/>Xslt: X12_834_Outbound_Mapping_{COMPANY}.xslt"]
    EX["Encode_X12<br/>agreement {COMPANY}_ASES_Eleg_Request"]
    IF2{"Generation_x12<br/>equals('', '') -- siempre verdadero"}
    CF["Create_file<br/>ENRASES_ENROLLMENTFILE / InProcess / X12"]
    ERX["Error_Response_in_x12<br/>200 body 99 -- inalcanzable"]
    ER["Error_Response<br/>200 body 99"]
    SR["Success_Response<br/>200 sin cuerpo"]

    T --> CC
    T --> CFC
    CFC --> VX
    VX --> IF
    CC --> IF
    IF -->|"true"| TX --> EX --> IF2
    IF2 -->|"true"| CF
    IF2 -->|"false"| ERX
    IF -->|"false"| ER
    IF -->|"SUCCEEDED"| SR
```

| Acción | Depende de |
| --- | --- |
| `Compose_Company`, `Compose_File_Content` | nada |
| `Validate_XML` | `Compose_File_Content` |
| `Validating_XML` | `Validate_XML` **y** `Compose_Company` |
| `Success_Response` | `Validating_XML` |

Se repiten aquí los dos hallazgos de `qry-to-x12-270`:

- `Validate_XML` corre pero su resultado no se evalúa; el `If` solo compara la compañía.
- `Generation_x12` es un `If` con la condición `equals("", "")`, siempre verdadera, y su rama
  `else` es código inalcanzable.

A diferencia del 270, aquí `Success_Response` devuelve `200` **sin cuerpo** en lugar de
`200` con cuerpo `0`. Los códigos de error sí son iguales (`99`).

### 4.1 Nota sobre la validación contra `X220A1.xsd`

`X220A1.xsd` no es autocontenido: incluye `IEA.xsd`, `ISA.xsd` y `FG.xsd`, que a su vez
encadenan otros 30 archivos. Para que `XmlValidation` funcione, **los 34 XSD tienen que estar
desplegados** en la carpeta de artefactos de la Logic App con los mismos nombres, porque los
`xsd:include` usan `schemaLocation` relativo sin subcarpetas.

### 4.2 Escritura del archivo de salida

```json
"folderPath": "\\\\1alexandria2.dev.pr.mmmhc.com\\manifiesto\\jobs\\ASES\\ENRASES_ENROLLMENTFILE\\InProcess\\X12",
"name": "@concat(if(equals(toUpper(outputs('Compose_Company')), 'MMM'), '690320', '690330'), '_', toUpper(outputs('Compose_Company')), 'P_270_', formatDateTime(convertTimeZone(utcNow(), 'UTC', 'SA Western Standard Time'), 'yyyyMMdd'), '.x12')"
```

La ruta es un literal fijo, sin subcarpeta por compañía, y está bien formada (doble
backslash inicial).

**Hallazgo:** el nombre del archivo lleva el código de transacción `270` cuando debería ser
`834`. Es el mismo patrón de copiar y pegar que en el 834 inbound, aunque menos grave: aquí
la carpeta sí es la correcta y no hay colisión con otro flujo, porque ningún otro escribe en
`ENRASES_ENROLLMENTFILE\InProcess\X12`.

| Compañía | Nombre generado el 8 de septiembre de 2026 |
| --- | --- |
| MMM | `690320_MMMP_270_20260908.x12` |
| PMC | `690330_PMCP_270_20260908.x12` |

Como el submitter ID distingue las dos compañías, MMM y PMC no colisionan entre sí. Sí
colisionan dos corridas de la misma compañía el mismo día.

## 5. Estructura del XML canónico de entrada

Namespace: `http://MMM_Membership_QNXT_EHub_LIB/X12/X220A1`

El schema está partido en 34 archivos, uno por segmento o loop EDI, todos en el mismo
`targetNamespace` y encadenados con `xsd:include`. La raíz es
[X220A1.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Schemas/Source/X220A1.xsd).

```mermaid
flowchart TB
    Root["X220A1 (elemento raiz)"]
    ISA["ISA (0..1)<br/>envelope de intercambio"]
    FG["FG (0..1)"]
    IEA["IEA (0..1)<br/>cierre del envelope"]
    FGO["FGOfF5010X220A1 (0..N)<br/>grupo funcional"]
    GS["GS"]
    ST["ST"]
    BGN["Begin -- tipo BGN"]
    REF["REF"]
    Sponsor["Sponsor -- tipo N1"]
    Carrier["Carrier -- tipo N1"]
    TS["TS"]
    SE["SE"]
    GE["GE"]
    F["F5010X220A1 (0..N)<br/>un miembro"]

    Root --> ISA
    Root --> FG
    Root --> IEA
    FG --> FGO
    FGO --> GS
    FGO --> ST
    FGO --> BGN
    FGO --> REF
    FGO --> Sponsor
    FGO --> Carrier
    FGO --> TS
    FGO --> SE
    FGO --> GE
    TS --> F
```

Y dentro de cada miembro:

```mermaid
flowchart TB
    F["F5010X220A1 -- un miembro"]
    SubHeader["SubHeader (0..1) -- tipo INS<br/>nivel 2000"]
    SubRef["SubRef (0..1) -> REF (0..N)<br/>identificadores del miembro"]
    SubDt["SubDt (0..1) -> DTP (0..N)<br/>fechas del miembro"]
    SubDtl["SubDtl (0..1) -> Subscriber (1..2)<br/>nivel 2100: nombre y demografia"]
    SubHD["SubHD (0..1) -> Enrollment (0..N)<br/>nivel 2300: cobertura"]

    Sub["Subscriber:<br/>Name (NM1), Comm (PER),<br/>PartyLocation (N3), GeoLocation (N4),<br/>Demographic (DMG)"]
    Enr["Enrollment:<br/>HealthData (HD), HealthDt -> DTP (0..N),<br/>HealthRef -> REF (0..N), Provs"]
    Prov["Provs -> Provider (0..N)<br/>nivel 2310:<br/>Info (LX), Name (NM1), ChangeReason (PLA)"]

    F --> SubHeader
    F --> SubRef
    F --> SubDt
    F --> SubDtl
    F --> SubHD
    SubDtl --> Sub
    SubHD --> Enr
    Enr --> Prov
```

La correspondencia de nombres es intencionalmente legible: `Begin` es el `BGN`, `Sponsor` y
`Carrier` son dos `N1`, `SubHeader` es el `INS`, `HealthData` es el `HD`, `ChangeReason` es
el `PLA`, y así sucesivamente.

### 5.1 Inventario de los 34 schemas

| Archivo | Rol |
| --- | --- |
| `X220A1.xsd` | Raíz: `ISA`, `FG`, `IEA` |
| `ISA.xsd`, `IEA.xsd` | Envelope de intercambio |
| `FG.xsd` | Contenedor de grupos funcionales (`FGOfF5010X220A1` 0..N) |
| `FunctionalGroupOfF5010X022A1.xsd` | Define `FGOfF5010X220A1` con `GS`, `ST`, `Begin`, `REF`, `Sponsor`, `Carrier`, `TS`, `SE`, `GE` |
| `GS.xsd`, `GE.xsd`, `ST.xsd`, `SE.xsd` | Envelopes de grupo funcional y transaction set |
| `BGN.xsd` | Beginning Segment |
| `N1.xsd` | Nombre de entidad (usado por `Sponsor` y `Carrier`) |
| `TS.xsd` | Contenedor de miembros (`F5010X220A1` 0..N) |
| `F5010X220A1.xsd` | Un miembro: `SubHeader`, `SubRef`, `SubDt`, `SubDtl`, `SubHD` |
| `INS.xsd` | Insured Benefit (nivel 2000) |
| `SubRef.xsd`, `REF.xsd` | Identificadores del miembro |
| `SubDt.xsd`, `DTP.xsd` | Fechas del miembro |
| `SubDtl.xsd`, `Subscriber.xsd` | Loop 2100 (`Subscriber` 1..2) |
| `NM1.xsd`, `PER.xsd`, `N3.xsd`, `N4.xsd`, `DMG.xsd` | Segmentos del loop 2100 |
| `SubHD.xsd`, `Enrollment.xsd`, `HD.xsd` | Loop 2300 de cobertura (`Enrollment` 0..N) |
| `HealthDt.xsd`, `HealthRef.xsd` | Fechas y referencias de la cobertura |
| `Provs.xsd`, `Provider.xsd`, `LX.xsd`, `PLA.xsd` | Loop 2310 de proveedor / PCP |

**Nota:** el nombre `FunctionalGroupOfF5010X022A1.xsd` dice `X022A1`, pero el tipo que define
adentro es `FGOfF5010X220A1` (`X220A1`). Es una errata en el nombre del archivo; el contenido
es correcto. Como el `xsd:include` referencia el nombre del archivo tal cual, no se puede
renombrar sin actualizar `FG.xsd`.

## 6. Mapping `X12_834_Outbound_Mapping_MMM.btm`

| Árbol | Root | Referencia |
| --- | --- | --- |
| Origen (`SrcTree`) | `X220A1` | `..\Schemas\Source\X220A1.xsd` |
| Destino (`TrgTree`) | `X12_00501_834` | `..\X12_00501_834.xsd` |

Sin `ConstantValues`. Todo el contenido sale del XML de entrada.

### 6.1 Enlaces directos (sin functoid)

Siete elementos se enlazan uno a uno, sin transformación:

| Origen | Destino | Segmento |
| --- | --- | --- |
| `FG/FGOfF5010X220A1/Begin/PurposeCd` | `BGN01` | Transaction Set Purpose Code |
| `FG/FGOfF5010X220A1/Begin/RefId` | `BGN02` | Reference Identification |
| `FG/FGOfF5010X220A1/Begin/Date` | `BGN03` | Date |
| `FG/FGOfF5010X220A1/Begin/Time` | `BGN04` | Time |
| `FG/FGOfF5010X220A1/Begin/ActionCd` | `BGN08` | Action Code |
| `FG/FGOfF5010X220A1/REF/IdQual` | `REF01` | Qualifier |
| `FG/FGOfF5010X220A1/REF/Id` | `REF02` | Master Policy Number |

Ese `REF02` es el `masterPolicy` que el
[mapping del 834 inbound](04-transaccion-834-inbound.md#61-variables-globales-del-transaction-set)
lee con `REF[REF01='38']`.

**Hallazgo:** `BGN05`, `BGN06` y `BGN07` no se mapean, y `ST01`/`ST02`/`ST03` tampoco. En el
[mapping del 270](02-transaccion-270.md#71-valores-constantes-constantvalues) sí se declaran
los tres elementos de `ST` como constantes. Aquí se deja que los genere el agreement al
codificar. Funciona, pero son dos criterios distintos para el mismo problema en el mismo
repositorio.

### 6.2 Functoid 1 — Loops N1 (Sponsor y Carrier)

```xml
<xsl:for-each select="/s0:X220A1/FG/FGOfF5010X220A1/Sponsor
                    | /s0:X220A1/FG/FGOfF5010X220A1/Carrier">
    <ns0:N1Loop1>
        <ns0:N1>
            <N101><xsl:value-of select="EntIdCd"/></N101>
            <N102><xsl:value-of select="Name"/></N102>
            <N103><xsl:value-of select="IdCdQual"/></N103>
            <N104><xsl:value-of select="IdCd"/></N104>
        </ns0:N1>
    </ns0:N1Loop1>
</xsl:for-each>
```

Genera un `N1Loop1` por cada uno de los dos nodos, usando el operador de unión `|` de XPath.
El orden de salida es el orden del documento: primero `Sponsor`, después `Carrier`.

**Hallazgo:** los cuatro elementos se emiten sin condicional. Si `IdCdQual` o `IdCd` vienen
vacíos en el XML, se emiten elementos `N103` y `N104` vacíos, que el agreement puede rechazar
por validación EDI.

### 6.3 Functoid 2 — Loop INS (nivel 2000 y descendientes)

```xml
<xsl:for-each select="/s0:X220A1/FG/FGOfF5010X220A1/TS/F5010X220A1">
    <ns0:INSLoop1>...</ns0:INSLoop1>
</xsl:for-each>
```

Un `INSLoop1` por miembro. Todo lo que sigue va anidado ahí adentro.

A diferencia del mapping inbound, aquí **no hay reglas de negocio**: es una traducción
estructural con guardas `xsl:if test="string(...) != ''"` para no emitir elementos vacíos.

#### Segmento INS (nivel 2000)

| Destino | Origen | Condicional |
| --- | --- | --- |
| `INS01` | `SubHeader/IsSub` | No |
| `INS02` | `SubHeader/RelCd` | No |
| `INS03` | `SubHeader/MaintCd` | Sí |
| `INS04` | `SubHeader/MaintCdReason` | Sí |
| `INS05` | `SubHeader/BnfStaCd` | Sí |
| `C052/C05201` (INS06) | `SubHeader/MedStaCd` | Sí |
| `INS08` | `SubHeader/EmpStaCd` | Sí |

`INS06` es un elemento compuesto en X12, así que se emite como `<ns0:C052><C05201>`.

**Hallazgo:** `INS01` e `INS02` se emiten siempre, sin guarda. Si el XML no los trae, salen
vacíos y el agreement debería rechazarlos (son obligatorios en el guide).

**Hallazgo:** `INS07` y de `INS09` a `INS17` no se mapean. Entre los omitidos está `INS12`
(Date of Death), que el
[mapping inbound sí lee](04-transaccion-834-inbound.md#610-otras-reglas-de-derivación) para
llenar `DateofDeath`. El flujo saliente no puede informar una defunción a ASES.

#### Segmentos REF y DTP (nivel 2000)

```xml
<xsl:for-each select="SubRef/REF">        <!-- todos los REF -->
<xsl:for-each select="SubDt/DTP[Qual='473' or Qual='474']">   <!-- solo 473 y 474 -->
```

Los `REF` se emiten todos. Los `DTP` están **filtrados a los cualificadores `473` (Medicaid
Begin) y `474` (Medicaid End)**, tal como dice el comentario del propio mapping
(`Solo 473 y 474 a nivel Member`). Son exactamente los dos que el mapping inbound lee para
`EligibilityEffectiveDate` y `ExpirationDate`.

**Hallazgo:** cualquier otro `DTP` que traiga el XML a nivel de miembro se descarta en
silencio.

#### Loop NM1 (nivel 2100)

```xml
<xsl:for-each select="SubDtl/Subscriber">
```

Uno o dos loops (el schema permite `maxOccurs="2"`). Por cada uno se emiten, todos con guarda
salvo los dos primeros:

| Segmento | Destino | Origen |
| --- | --- | --- |
| `NM1` | `NM101`, `NM102` | `Name/EntIdCd`, `Name/EntTypeQual` (sin guarda) |
| | `NM103` a `NM110` | `Name/Last`, `First`, `Middle`, `Prefix`, `Suffix`, `IdCdQual`, `IdCd`, `EntRelCd` |
| `PER_3` | `PER01`, `PER03`, `PER04` | `Comm/FuncCd`, `Comm/CommQual`, `Comm/CommId` |
| `N3_3` | `N301`, `N302` | `PartyLocation/Addr1`, `Addr2` |
| `N4_3` | `N401`, `N402`, `N403`, `N405`, `N406` | `GeoLocation/City`, `State`, `Zipcode`, `LocationQual`, `LocationId` |
| `DMG` | `DMG01`, `DMG02`, `DMG03` | `Demographic/BirthDateQual`, `BirthDate`, `GenderCd` |

**Hallazgo:** `DMG04` (estado civil) no se mapea, aunque el mapping inbound lo lee para
`MaritalStatusCode`. Tampoco se mapean `LUI` (idiomas) ni `DMG/C056` (raza y etnia), que el
inbound sí lee. La asimetría es sistemática: el flujo entrante extrae más datos de los que el
flujo saliente es capaz de enviar.

**Hallazgo:** `PER05` y `PER06` (segundo número de comunicación) no se mapean, pero el
mapping inbound sí los lee como fallback de `CommunicationNumber`.

#### Loop HD (nivel 2300)

```xml
<xsl:for-each select="SubHD/Enrollment">
```

Un `HDLoop1` por cobertura:

| Destino | Origen | Condicional |
| --- | --- | --- |
| `HD01` | `HealthData/MaintCd` | No |
| `HD03` | `HealthData/InsCd` | Sí |
| `HD04` | `HealthData/CovDescr` | Sí |
| `HD05` | `HealthData/CovLevelCd` | Sí |

`HD04` es el elemento donde ASES espera el patrón `{codigo}|{valor}` descrito en el
[834 inbound](04-transaccion-834-inbound.md#66-loops-hd-el-patrón-hd04-con-prefijo-y-pipe).
El mapping outbound lo copia tal cual desde `CovDescr`: **la responsabilidad de armar ese
formato es de QNXT**, no del mapping.

Dentro del loop se emiten todos los `DTP_5` desde `HealthDt/DTP` (sin filtro, a diferencia de
los DTP de nivel 2000).

**Hallazgo:** `HD02` no se mapea. Y `HealthRef` (los `REF` de la cobertura) existe en el
schema de origen pero **el mapping nunca los emite**: el elemento se define, QNXT puede
llenarlo, y se pierde.

#### Loop LX (nivel 2310, proveedor / PCP)

```xml
<xsl:for-each select="Provs/Provider">
```

| Segmento | Destino | Origen |
| --- | --- | --- |
| `LX` | `LX01` | `Info/AssignId` |
| `NM1_2` | `NM101` a `NM110` | Igual estructura que el `NM1` del nivel 2100, desde `Name/...` |
| `PLA` | `PLA01`, `PLA02`, `PLA03` | `ChangeReason/ActionCd`, `EntIdCd`, `Date` (sin guarda) |
| | `PLA05` | `ChangeReason/ReasonCd` (con guarda) |

El bloque `PLA` completo va dentro de `<xsl:if test="ChangeReason">`, así que solo aparece si
el XML trae ese nodo.

`NM106` es el elemento donde el mapping inbound busca `PCP1`, `PCP2` y `PMG1`; aquí se copia
directamente desde `Name/Prefix`. Otra convención que QNXT tiene que respetar.

### 6.4 Loops del 834 que este mapping no genera

| Loop | Contenido | Consecuencia |
| --- | --- | --- |
| 2320 / `COBLoop1` | Coordinación de beneficios | El flujo saliente no puede informar otros seguros, aunque el inbound sí los recibe |
| 2700 / `LSLoop1` | Member Reporting Categories | Es donde ASES codifica el trading partner que el inbound usa para derivar el carrier |
| 1000C / `N1Loop1` de TPA | Tercer administrador | No aplica en este intercambio |

La ausencia del loop 2700 significa que la información de trading partner viaja **solo en
sentido entrante**.

### 6.5 Segmentos de envelope ignorados

El schema de origen define `ISA`, `IEA`, `GS`, `GE`, `ST` y `SE`, y el mapping **no lee
ninguno**. El envelope lo genera `Encode_X12` a partir del agreement
`{COMPANY}_ASES_Eleg_Request`.

Es la decisión correcta (el agreement es el dueño de los delimitadores y los números de
control), pero deja seis complexTypes del schema sin uso, lo que puede confundir a quien
tenga que modificar el XML de origen.

## 7. Diferencias MMM vs PMC

**No hay ninguna.** `X12_834_Outbound_Mapping_MMM.btm` y `X12_834_Outbound_Mapping_PMC.btm`
son idénticos byte a byte (verificado con `fc`).

Y en este caso es la conclusión correcta por diseño: el mapping **no contiene ningún valor
específico de compañía**. Todo (sponsor, carrier, policy number, IDs) viene del XML que
produce QNXT. Los dos archivos son redundancia pura: el `concat` dinámico del nombre del mapa
resuelve a dos copias iguales.

La compañía sí sigue importando en el workflow, para elegir el agreement X12 y el prefijo del
nombre del archivo.

## 8. Puntos de falla conocidos

| Escenario | Comportamiento actual |
| --- | --- |
| Archivo con `MMM` en el nombre por casualidad | Se procesa como MMM |
| Archivo sin `MMM` ni `PMC` en el nombre | No se procesa, sin alerta |
| XML que no valida contra `X220A1.xsd` | `Validate_XML` falla, la ejecución queda en `Failed`, sin respuesta de error controlada |
| Falta alguno de los 34 XSD en los artefactos | `Validate_XML` falla al resolver los `xsd:include` |
| `INS01` o `INS02` vacíos en el XML | Se emiten vacíos y el agreement debería rechazar |
| `IdCdQual` o `IdCd` vacíos en Sponsor/Carrier | `N103`/`N104` vacíos |
| `HD04` sin el formato `{codigo}\|{valor}` | ASES recibe un `HD04` que no puede interpretar; el mapping no valida el formato |
| Dos corridas de la misma compañía el mismo día | Mismo nombre de archivo |
| `company` distinto de MMM o PMC | Rama `else`, respuesta `99`, que el watcher ignora |
| El XML trae datos de COB o de defunción | Se pierden: el mapping no genera esos loops |
