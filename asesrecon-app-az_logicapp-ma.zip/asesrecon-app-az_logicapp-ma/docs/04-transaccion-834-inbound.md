# 04 — Transacción 834 Inbound: Benefit Enrollment (entrante)

[Volver al índice](README.md)

## 1. Resumen

ASES/PRMMIS entrega un X12 834 con el padrón de afiliados (altas, bajas, cambios de plan,
cambios de PCP, coordinación de beneficios, risk scores). El flujo lo decodifica y lo
convierte en un archivo posicional multi-registro que el sistema de enrollment del legado
consume.

| Aspecto | Valor |
| --- | --- |
| Logic App | `ma-x12-dev-enrollment-asesrecon-lapp` |
| Dirección | Entrante (ASES hacia MMM/PMC) |
| Entrada | X12 834 crudo, extensión `.x12` |
| Salida | Flat file posicional multi-registro, **739 caracteres por línea** |
| Implementation guide | `005010X220A1` |
| Workflows | [watch-834-inbound-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-inbound-mmm.json), [watch-834-inbound-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/watch-834-inbound-pmc.json), [x12-to-exp-834.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-enrollment-asesrecon-lapp/workflows/x12-to-exp-834.json) |
| Schemas | [X12_00501_834.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/X12_00501_834.xsd), [EnrollmentRequestInbound.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/EnrollmentRequestInbound.xsd) |
| Mappings | [X12_834_Inbound_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_MMM.btm), [X12_834_Inbound_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/X12_834_Inbound_Mapping_PMC.btm) |

Es el flujo **más complejo de los cuatro**: un solo XSLT de unos 1.100 elementos genera
cinco tipos de registro distintos por afiliado.

## 2. Diagrama macro

```mermaid
flowchart TB
    ASES[("ASES / PRMMIS")]
    Transport["Proceso externo de transporte<br/>(fuera de este repositorio)"]
    InFolder["ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2 / Inbound<br/>archivo *.x12 con 690320 o 690330 en el nombre"]
    WM["watch-834-inbound-mmm<br/>filtro 690320"]
    WP["watch-834-inbound-pmc<br/>filtro 690330"]
    Proc["x12-to-exp-834"]
    OutFolder["QUERYRESPONSE / InProcess / {COMPANY}<br/>690320_MMMP_271_yyyyMMdd.res<br/>-- ver hallazgo de la seccion 4.2"]
    Legacy["Sistema de enrollment del legado"]

    ASES --> Transport --> InFolder
    InFolder --> WM
    InFolder --> WP
    WM -->|"company = MMM"| Proc
    WP -->|"company = PMC"| Proc
    Proc --> OutFolder --> Legacy
```

El nombre `ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2` sugiere que ASES entrega tres variantes de
este archivo (diario, mensual y full). El flujo **no distingue entre ellas**: procesa
cualquier `.x12` que contenga el submitter ID en el nombre.

## 3. Watcher: `watch-834-inbound-mmm` / `watch-834-inbound-pmc`

```mermaid
flowchart TB
    T["Trigger: When_a_file_is_created_(properties_only)<br/>folderId = ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2 / Inbound<br/>condicion 1: endsWith(lower(Name), '.x12')<br/>condicion 2: contains(upper(Name), '690320')<br/>recurrencia 1 min, maxFileCount 1, splitOn triggerBody()"]
    G["Get_file_content"]
    C["Call_workflow_in_this_logic_app<br/>workflow: x12-to-exp-834<br/>body: fileContent, company = 'MMM'"]

    T --> G
    G -->|"runAfter: SUCCEEDED"| C
```

| Propiedad | `watch-834-inbound-mmm` | `watch-834-inbound-pmc` |
| --- | --- | --- |
| Carpeta vigilada | `ENRASES_ELIGIBILITYDAILYMONTHLYFULLV2\Inbound` | **la misma carpeta** |
| Condición 1 | `endsWith(toLower(Name), '.x12')` | idéntica |
| Condición 2 | `contains(toUpper(Name), '690320')` | `contains(toUpper(Name), '690330')` |
| `company` enviado | `"MMM"` | `"PMC"` |
| Conexión | `filesystem` | `filesystem` |

A diferencia del 270 y del 271, aquí **los dos watchers vigilan la misma carpeta** y se
reparten los archivos por el submitter ID embebido en el nombre.

**Hallazgo:** `contains` busca la subcadena en cualquier posición del nombre. Un archivo que
contenga por casualidad ambos números (por ejemplo un consolidado) dispararía los dos
watchers y se procesaría dos veces, una por compañía. Y un archivo sin ninguno de los dos
números queda sin procesar en silencio, sin alerta.

## 4. Procesador: `x12-to-exp-834`

Estructuralmente es **idéntico** a `x12-to-res-271`: mismo grafo de acciones, mismos
`foreach` anidados. Solo cambian el nombre del mapa y el schema de encoding.

```mermaid
flowchart TB
    T["Trigger: When_an_HTTP_request_is_received"]
    CFC["Compose_File_Content"]
    CC["Compose_Company"]
    DX["Decode_X12<br/>fallbackAgreementName {COMPANY}_ASES_Eleg_Request"]
    FE1["For_each_functional_groups"]
    FE2["For_each_transaction_sets"]
    TX["Transform_XML<br/>Xslt: X12_834_Inbound_Mapping_{COMPANY}.xslt"]
    EFF["Encode_flat_file<br/>FlatFileEncoding con EnrollmentRequestInbound.xsd"]
    CF["Create_file"]
    SR["Success_Response<br/>200 sin cuerpo"]

    T --> CFC
    T --> CC
    CFC --> DX
    CC --> DX
    DX --> FE1 --> FE2 --> TX --> EFF --> CF
    FE1 -->|"SUCCEEDED"| SR
```

| Acción | Depende de |
| --- | --- |
| `Compose_File_Content`, `Compose_Company` | nada |
| `Decode_X12` | ambas `Compose` |
| `For_each_functional_groups` | `Decode_X12` |
| `Transform_XML` | primera del `foreach` interno |
| `Encode_flat_file` | `Transform_XML` |
| `Create_file` | `Encode_flat_file` |
| `Success_Response` | `For_each_functional_groups` |

### 4.1 Diferencia de mayúsculas en `foreach`

`x12-to-exp-834` declara `"type": "Foreach"` (con F mayúscula) mientras `x12-to-res-271`
declara `"type": "foreach"`. Es cosmético: el runtime no distingue mayúsculas en el tipo de
acción. Solo delata que uno se copió del otro y se editó a mano.

### 4.2 Escritura del archivo de salida

```json
"folderPath": "@concat('\\1alexandria2.dev.pr.mmmhc.com\\manifiesto\\jobs\\ASES\\QUERYRESPONSE\\InProcess\\', toUpper(outputs('Compose_Company')))",
"name": "@concat(if(equals(toUpper(outputs('Compose_Company')), 'MMM'), '690320', '690330'), '_', toUpper(outputs('Compose_Company')), 'P_271_', formatDateTime(convertTimeZone(utcNow(), 'UTC', 'SA Western Standard Time'), 'yyyyMMdd'), '.res')"
```

**Hallazgo crítico: este bloque está copiado tal cual de `x12-to-res-271` y nunca se
ajustó.** Tres problemas concretos:

1. **Carpeta equivocada.** Escribe en `QUERYRESPONSE\InProcess\{COMPANY}`, que es la carpeta
   de salida del flujo 271 de elegibilidad. Nada tiene que ver con enrollment.
2. **Nombre equivocado.** Genera `690320_MMMP_271_yyyyMMdd.res`: código de transacción `271`
   y extensión `.res`, cuando debería ser un archivo de enrollment.
3. **Ruta UNC mal formada.** El literal empieza con **un solo** backslash escapado
   (`'\\1alexandria2...'` en JSON, es decir `\1alexandria2...` real) en lugar de dos. En el
   resto de los flujos el literal es `'\\\\1alexandria2...'`, es decir `\\1alexandria2...`.
   Sin el doble backslash inicial no es una ruta UNC válida.

La consecuencia combinada es que este flujo **compite por el mismo nombre de archivo con
`x12-to-res-271`**: los dos escriben `690320_MMMP_271_yyyyMMdd.res` en la misma carpeta el
mismo día. Si el punto 3 no lo hace fallar antes, el punto 1 y 2 provocan que el enrollment
sobrescriba la respuesta de elegibilidad o viceversa.

### 4.3 Riesgo del `Create_file` dentro del `foreach`

Igual que en el 271, `Create_file` está dentro del `foreach` interno con un nombre que solo
depende de compañía y fecha. Con más de un transaction set por interchange, todas las
iteraciones escriben el mismo nombre.

## 5. Layout del flat file de salida

[EnrollmentRequestInbound.xsd](../IntegrationAccount/IntegrationAccount/Mappings/834/Inbound/EnrollmentRequestInbound.xsd)

| Propiedad | Valor |
| --- | --- |
| Root | `Root` |
| Namespace | `http://IntegrationAccount.x005F_x0038_34.Inbound.EnrollmentRequestInbound` |
| Estructura del root | `delimited`, `child_order = infix`, sin delimitador declarado |
| Grupo `Member` | `delimited`, delimitador `0xD 0xA` (CRLF), `child_order = postfix`, de 1 a ilimitado |
| Sub-registros | Cinco registros `positional`, en secuencia fija, **739 caracteres cada uno** |

Es un archivo multi-registro de longitud fija: cada línea tiene 739 caracteres y se
identifica por el primer carácter (`RecordType`).

```mermaid
flowchart TB
    Root["Root"]
    Member["Member (1..N)<br/>uno por INSLoop1 del 834"]
    R1["MemberFirstSegment -- RecordType 'F'<br/>71 campos, 739 chars<br/>direcciones, contacto, carrier, cancelacion"]
    R2["MemberSecondSegment -- RecordType 'M'<br/>105 campos, 739 chars<br/>demografia, PCP, PMG, plan, cobertura"]
    R3["Household -- RecordType 'O'<br/>23 campos, 739 chars<br/>hasta 18 miembros del nucleo familiar"]
    R4["InsuranceCOB -- RecordType 'I'<br/>11 campos, 739 chars<br/>otros seguros del afiliado"]
    R5["RateCellRiskScore -- RecordType 'R'<br/>12 campos, 739 chars<br/>rate code y risk scores"]

    Root --> Member
    Member --> R1 --> R2 --> R3 --> R4 --> R5
```

Los cinco registros comparten el mismo encabezado:

| Posición | Campo | Valor |
| --- | --- | --- |
| 1 | `RecordType` | `F`, `M`, `O`, `I` o `R` |
| 2 | `TransactionId` | Siempre `E` |
| 3–10 | `ProcessDate` | Fecha en formato `MMDDCCYY` derivada de `BGN03` |
| 11–21 | `PersonId` (o `SSN` en `F` y `M`) | Identificador del afiliado |

**Hallazgo:** en `InsuranceCOB` el campo se llama `ProcesDate`, con una `s` de menos. El
mapping usa el mismo nombre mal escrito, así que funciona; es solo un nombre inconsistente
en el contrato.

**Hallazgo:** en el registro `Household`, los campos `Household Person 1` a
`Household Person 17` tienen 11 caracteres cada uno, pero `Household Person 18` declara
**312 caracteres** (posiciones 209 a 520). Es lo que hace que el registro llegue a 739, así
que parece un ajuste manual para cuadrar la longitud en lugar de un campo real de 18 personas
más un filler. Como el mapping emite el registro `Household` completamente vacío, hoy no
tiene consecuencia práctica.

### 5.1 Campos con valores fijos

| Registro | Campo | Valor fijo | Observación |
| --- | --- | --- | --- |
| `F` | `FILLER` | `00` | |
| `F` | `Municipality` | `0000` | **Hallazgo:** el municipio real nunca se extrae del 834 |
| `F` | `Facility` | `0000` | |
| `F` | `EligibleMembers` | `0` | |
| `M` | `FILLER3` | `01` | |
| `M` | `FILLER5`, `FILLER6`, `FILLER7` a `FILLER9`, `FILLER13` a `FILLER16`, `FILLER19` a `FILLER21` | `0` | |
| `M` | `FILLER12` | `00` | |
| `M` | `EligibilityIndicator` | `Y` | **Hallazgo:** siempre `Y`, incluso en bajas |
| `I` | `FILLER` | `01` | |
| `R` | `RiskScoreIndicator` | `1` | |
| `R` | `EffectiveDate` | `00000000` | **Hallazgo:** fecha cero literal |

## 6. Mapping `X12_834_Inbound_Mapping_MMM.btm`

| Árbol | Root | Referencia |
| --- | --- | --- |
| Origen (`SrcTree`) | `X12_00501_834` | `..\X12_00501_834.xsd` |
| Destino (`TrgTree`) | `Root` | `.\EnrollmentRequestInbound.xsd` |

Sin `ConstantValues`. Un solo functoid XSLT (ID 1) enlazado a `Root`.

### 6.1 Variables globales del transaction set

| Variable | Origen | Uso |
| --- | --- | --- |
| `$processDateRaw` | `BGN/BGN03` | Fecha del archivo |
| `$processDate` | `$processDateRaw` reformateada | `ProcessDate` de los cinco registros |
| `$masterPolicy` | `REF[REF01='38'][1]/REF02` (Master Policy Number) | `PolicyNumber` en `F` y `M`, y fallback del carrier |

### 6.2 Regla de conversión de fechas

Todas las fechas del EDI llegan en `CCYYMMDD` y el legado las espera en `MMDDCCYY`:

```xml
concat(substring($raw,5,2), substring($raw,7,2), substring($raw,1,4))
```

Es decir, `20260315` se convierte en `03152026`. La misma expresión se repite para
`processDate`, `eligBegin`, `eligEnd`, `dob`, `deathDate`, `carrierBegin`, `carrierEnd`,
`newCarrierBegin`, los seis efectivos de PCP/PMG y las dos fechas de póliza de COB.

**Hallazgo:** si el campo de origen viene vacío, la expresión no produce cadena vacía sino
el resultado de tres `substring` sobre vacío, que es también vacío. Correcto por casualidad,
pero si viniera una fecha con formato distinto (por ejemplo `RD8`), el resultado sería basura
silenciosa.

### 6.3 Iteración principal

```xml
<xsl:for-each select="s0:INSLoop1">
```

Un grupo `Member` (los cinco registros) por cada `INSLoop1` del 834, es decir **por cada
miembro** del padrón.

### 6.4 Selección de loops NM1

| Variable | Selector | Qué representa |
| --- | --- | --- |
| `$memberNM1Loop` | `NM1Loop1[NM1/NM101='IL' or NM1/NM101='74'][1]` | El afiliado (`IL` insured, `74` corrected insured) |
| `$contactNM1Loop` | `NM1Loop1[NM1/NM101='QD'][1]` | Persona responsable / contacto |
| `$mailingNM1Loop` | `NM1Loop1[NM1/NM101='31'][1]` | Dirección postal alterna |

### 6.5 Identificadores

| Variable | Origen | Significado |
| --- | --- | --- |
| `$personId` | `REF_3[REF01='0F'][1]/REF02` | Subscriber Number |
| `$mbi` | `REF_3[REF01='F6'][1]/REF02` | Medicare Beneficiary Identifier |
| `$ssn` | `$memberNM1[NM108='34']/NM109` | Seguro social, solo si el qualifier es `34` |

**Nota de simetría con el 270:** el registro `M` calcula `MPI` como
`concat('00', $personId)`, o sea le pone el prefijo de dos caracteres que el mapping del 270
después quita con `substring(MPI, 3)`. Los dos flujos son consistentes entre sí: el prefijo
`00` es una convención interna del legado que nunca viaja por EDI.

### 6.6 Loops HD: el patrón `HD04` con prefijo y pipe

Esta es la convención de negocio más importante del mapping. ASES codifica múltiples
atributos del plan en el elemento `HD04` (Plan Coverage Description) usando el formato
`{codigo}|{valor}`, y el mapping los recupera por prefijo:

| Variable | Prefijo de `HD04` | Atributo |
| --- | --- | --- |
| `$hd01a` / `$hd01b` | `01\|` | Carrier — ocurrencia 1 = actual, ocurrencia 2 = nuevo |
| `$hd03a` / `$hd03b` | `03\|` | Plan type actual / nuevo |
| `$hd05a` / `$hd05b` | `05\|` | Plan version actual / nueva |
| `$hd06a` | `06\|` | Región |
| `$hd30a` | `30\|` | Coverage code |
| `$hd31a` | `31\|` | Government group |
| `$hd37a` | `37\|` | Confined coverage |
| `$hd50a` | `50\|` | Rate code |
| `$hd60a` | `60\|` | Raw risk score |
| `$hd61a` | `61\|` | Risk score |

El valor se extrae con `substring-after(HD04, '|')`. Las fechas del carrier vienen de los
`DTP_5` dentro del `HDLoop1` correspondiente: `DTP01='348'` (Benefit Begin) y `DTP01='349'`
(Benefit End).

El patrón "primera ocurrencia = actual, segunda ocurrencia = nuevo" (`[1]` y `[2]`) es cómo
se representan los cambios prospectivos de plan. Depende enteramente del **orden** en que
ASES emita los loops.

**Hallazgo:** este esquema es frágil de dos maneras. Si ASES envía los loops en otro orden,
el plan futuro se interpreta como el actual. Y si envía tres ocurrencias del mismo prefijo,
la tercera se descarta sin aviso.

### 6.7 Loops LX: PCP y grupo médico

```xml
$pcp1a = (s0:HDLoop1/s0:LXLoop1[s0:NM1_2/s0:NM106='PCP1'])[1]
```

| Variable | Filtro `NM106` | Ocurrencia | Destino |
| --- | --- | --- | --- |
| `$pcp1a` / `$pcp1b` | `PCP1` | 1 / 2 | `PCP` / `NewPCP` |
| `$pcp2a` / `$pcp2b` | `PCP2` | 1 / 2 | `SecondPCP` / `NewSecondPCP` |
| `$pmg1a` / `$pmg1b` | `PMG1` | 1 / 2 | `PMGNPI`, `PMGMedicaidId` / sus versiones `New` |

De cada uno se toma:

| Elemento | Destino |
| --- | --- |
| `NM1_2/NM109` | NPI del proveedor |
| `NM1_2/NM105` | Medicaid ID del grupo médico |
| `PLA/PLA03` | Fecha efectiva del cambio |
| `PLA/PLA05` | Razón del cambio |

`PCPChangeReason` (registro `F`) y `PrimaryCareChangeReason` (registro `M`) usan la misma
cascada: primero `PLA05` de PCP1, si está vacío el de PMG1, si está vacío el de PCP2.

### 6.8 Derivación del carrier

Es la lógica más indirecta del mapping. El carrier no viene como tal: se deduce del
"trading partner" que ASES codifica en un `REF` pipe-delimitado dentro de un loop de
provider:

```xml
$additionalRef = LSLoop1/LXLoop2/N1Loop2[N1_4/N101='75'][1]/REF_11[REF01='ZZ'][1]/REF02
```

Ese valor tiene forma `algo|previousTP|futureTP|...` y se parte en dos:

| Variable | Extracción |
| --- | --- |
| `$previousTP` | Segundo segmento del pipe |
| `$futureTP` | Tercer segmento del pipe |
| `$currentTP` | `$previousTP` si no está vacío, si no `$masterPolicy` |

Luego se traduce el trading partner a un código de carrier de dos dígitos:

| Trading partner | Código de carrier |
| --- | --- |
| `690150` | `09` |
| `690350` | `10` |
| `690900` | `12` |
| `690450` | `13` |
| `690320` (MMM) | `29` |
| `690330` (PMC) | `33` |
| `690800` | `34` |
| `690700` | `42` |
| `690410` | `46` |
| cualquier otro | vacío |

`$carrierCode` sale de `$currentTP` y `$newCarrierCode` de `$futureTP`, con la misma tabla.

Este catálogo confirma que el `InquiryCarrier=29` hardcodeado en el
[mapping del 271](03-transaccion-271.md#7-diferencias-mmm-vs-pmc) es el código de MMM. El
valor de PMC sería `33`.

**Hallazgo:** el catálogo de nueve trading partners está incrustado en el XSLT y duplicado
dos veces dentro del mismo archivo (una para el carrier actual y otra para el nuevo), y otra
vez en cada uno de los dos mapas de compañía. Son cuatro copias del mismo catálogo que hay
que mantener sincronizadas.

**Hallazgo:** un trading partner desconocido produce carrier vacío sin error. El afiliado
entra al legado sin carrier.

### 6.9 Código de cancelación

```xml
<xsl:choose>
    <xsl:when test="s0:INS/s0:INS03 != '024'"/>
    <xsl:when test="s0:INS/s0:INS04='03' or s0:INS/s0:INS04='3'">08</xsl:when>
    <xsl:when test="s0:INS/s0:INS04='14'">31</xsl:when>
    <xsl:otherwise>30</xsl:otherwise>
</xsl:choose>
```

Se traduce así: si `INS03` (Maintenance Type Code) no es `024` (Cancellation or Termination),
el código queda vacío. Si sí es una terminación, se mira `INS04` (Maintenance Reason Code):
`03` o `3` da `08`, `14` da `31`, y cualquier otro motivo da `30` como genérico.

El resultado se escribe en `CancellationorTerminationCode` (registro `F`) y en
`CancellationCode` (registro `M`).

### 6.10 Otras reglas de derivación

| Campo destino | Regla |
| --- | --- |
| `Gender` (F) y `Sex` (M) | `DMG03`: `M` a `1`, `F` a `2`, **cualquier otro a `3`** |
| `MaritalStatusCode` | `DMG04`: `I` a `1`, `M` a `2`, `D` a `3`, `W` a `4`, otro a `5` |
| `LastName` / `SecondLastName` | `NM103` partido por `|`; si no hay pipe, todo va a `LastName` |
| `ContactLastName` / `ContactSecondLastName` | Igual, sobre el `NM103` del loop `QD` |
| `MiddleInitial` | Primer carácter de `NM105` |
| `MailingAddress1/2`, `MailingCity`, `MailingZIP` | Del loop `31` si existe, **si no del loop del afiliado** |
| `MailingZIP4` / `ResidenceZip4` | Caracteres 6 a 9 del ZIP si tiene más de 5; si el ZIP no está vacío pero tiene 5, se pone `9998`; si está vacío, vacío |
| `CommunicationNumber` | `PER04` si `PER03='TE'`, si no `PER06` si `PER05='TE'` |
| `Program` (M) | Primer carácter de `$coverageCode`: `1` a `1`, `2` a `2`, `3` a `3` |
| `HealthInsurerCode` (I) | Primeros 3 caracteres de `NM109` del insurer, o de `NM103` si `NM109` está vacío |
| `RiskScore` / `RawRiskScore` (R) | `format-number(number($raw), '000.0000')` |
| `EligibilityGroup` (M) | `HDLoop1/COBLoop1/REF_5[REF01='6P'][1]/REF02` |
| `LanguageSpoken` (M) | `LUI[LUI01='LE' and LUI04='7'][1]/LUI02` |
| `LanguageWritten` (M) | `LUI[LUI01='LE' and LUI04='6'][1]/LUI02` |
| `Race` / `Ethnicity` (M) | `DMG/C056/C05601` y `DMG/C056/C05603` |
| `DateofDeath` (M) | `INS12` convertido a `MMDDCCYY` |
| `CustomProperty1` (M) | `$carrierEnd` |

**Hallazgo:** el `9998` del ZIP+4 es un valor centinela sin documentar. Alguien que lea el
flat file sin este documento lo interpretará como un ZIP+4 real.

**Hallazgo:** el mapeo de género usa `3` como valor por defecto, mientras el
[mapping del 270](02-transaccion-270.md) usa `U` y el del 271 deja el campo vacío. Tres
convenciones distintas para el mismo concepto en el mismo repositorio.

### 6.11 Registro `Household`: emitido pero vacío

El XSLT genera el registro `O` con `RecordType`, `TransactionId`, `ProcessDate` y `PersonId`,
y **los 18 campos de personas del núcleo familiar vacíos**. Es un placeholder: la estructura
existe en el contrato pero la funcionalidad no está implementada.

### 6.12 Registro `InsuranceCOB`: cardinalidad inconsistente

```xml
<xsl:for-each select="s0:HDLoop1/s0:COBLoop1">
    ...
    <InsuranceCOB>...</InsuranceCOB>
</xsl:for-each>
```

**Hallazgo:** el schema declara `InsuranceCOB` con la cardinalidad por defecto, es decir
`minOccurs="1" maxOccurs="1"`, pero el XSLT lo emite dentro de un `for-each` sobre los loops
de coordinación de beneficios. Un afiliado sin COB produce **cero** registros `I` y uno con
dos seguros produce **dos**. En ambos casos el XML resultante no valida contra
`EnrollmentRequestInbound.xsd`, así que `Encode_flat_file` puede fallar. Lo mismo aplica a
`RateCellRiskScore` y `Household`, que sí se emiten siempre una vez y por eso no dan
problema.

Este es probablemente el hallazgo más importante del mapping después del bug de la ruta de
salida, porque afecta a cualquier afiliado sin otro seguro, que es el caso normal.

## 7. Diferencias MMM vs PMC

**No hay ninguna.** `X12_834_Inbound_Mapping_MMM.btm` y `X12_834_Inbound_Mapping_PMC.btm`
son idénticos byte a byte (verificado con `fc`).

Tiene sentido en este flujo: el carrier no se hardcodea por compañía, se **deriva** del
trading partner del propio 834 mediante el catálogo de la sección 6.8. Es decir, el mapping
ya es agnóstico de la compañía y los dos archivos son redundantes: el `concat` dinámico del
nombre del mapa resuelve a dos copias iguales.

## 8. Puntos de falla conocidos

| Escenario | Comportamiento actual |
| --- | --- |
| Ruta de salida con un solo backslash | Falla o escribe en un lugar inesperado, según el conector |
| Colisión con el archivo del flujo 271 | Mismo nombre, misma carpeta, mismo día |
| Afiliado sin loop COB | Cero registros `I`, el XML no cumple `minOccurs=1` |
| Afiliado con dos o más seguros | Varios registros `I`, el XML no cumple `maxOccurs=1` |
| Archivo con `690320` y `690330` en el nombre | Se procesa dos veces, una por compañía |
| Archivo sin ningún submitter ID en el nombre | No se procesa, sin alerta |
| Trading partner fuera del catálogo | `CarrierCode` vacío, sin error |
| Tercera ocurrencia de un mismo prefijo `HD04` | Se descarta sin aviso |
| Loops `HD04` en orden inesperado | El plan futuro se toma como actual |
| Interchange con varios transaction sets | Todas las iteraciones escriben el mismo nombre |
| `DMG03` con valor distinto de `M`/`F` | Género `3` |
| Baja de afiliado | `EligibilityIndicator` sale `Y` de todas formas |
