# 03 — Transacción 271: Eligibility Response (entrante)

[Volver al índice](README.md)

## 1. Resumen

ASES/PRMMIS deja un archivo X12 271 con la respuesta a las consultas del 270. El flujo lo
decodifica, transforma cada subscriber en un registro posicional y escribe un archivo `.res`
que el legado consume.

| Aspecto | Valor |
| --- | --- |
| Logic App | `ma-x12-dev-eligibility-asesrecon-lapp` |
| Dirección | Entrante (ASES hacia MMM/PMC) |
| Entrada | X12 271 crudo, extensión `.x12` |
| Salida | Flat file posicional, extensión `.res`, 269 caracteres por registro |
| Implementation guide | `005010X279A1` |
| Workflows | [watch-271-mmm.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-271-mmm.json), [watch-271-pmc.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/watch-271-pmc.json), [x12-to-res-271.json](../IntegrationAccount/IntegrationAccount/LogicApps/ma-x12-dev-eligibility-asesrecon-lapp/workflows/x12-to-res-271.json) |
| Schemas | [X12_00501_271.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_00501_271.xsd), [EligibilityResponse.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/EligibilityResponse.xsd) |
| Mappings | [X12_271_Mapping_MMM.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_MMM.btm), [X12_271_Mapping_PMC.btm](../IntegrationAccount/IntegrationAccount/Mappings/271/X12_271_Mapping_PMC.btm) |

Este flujo es el espejo del [270](02-transaccion-270.md), pero **no es una simple inversión**:
el 270 arma un EDI a partir de un flat file, mientras el 271 aplana un EDI jerárquico y
además tiene que elegir qué información de beneficios extraer.

## 2. Diagrama macro

```mermaid
flowchart TB
    ASES[("ASES / PRMMIS")]
    Transport["Proceso externo de transporte<br/>(fuera de este repositorio)"]
    InFolder["QUERYRESPONSE / Inbound / {COMPANY}<br/>archivo *.x12"]
    Watcher["watch-271-mmm / watch-271-pmc"]
    Proc["x12-to-res-271"]
    OutFolder["QUERYRESPONSE / InProcess / {COMPANY}<br/>690320_MMMP_271_yyyyMMdd.res"]
    Legacy["Sistema legado MMM / PMC<br/>consume el archivo .res"]

    ASES --> Transport --> InFolder
    InFolder -->|"trigger onnewfile cada 1 min"| Watcher
    Watcher -->|"fileContent + company"| Proc
    Proc --> OutFolder --> Legacy
```

## 3. Watcher: `watch-271-mmm` / `watch-271-pmc`

```mermaid
flowchart TB
    T["Trigger: When_a_file_is_created_(properties_only)<br/>folderId = QUERYRESPONSE / Inbound / MMM<br/>condicion: endsWith(lower(Name), '.x12')<br/>recurrencia 1 min, maxFileCount 1, splitOn triggerBody()"]
    G["Get_file_content<br/>GET /datasets/default/files/{Path}/content"]
    C["Call_workflow_in_this_logic_app<br/>workflow: x12-to-res-271<br/>body: fileContent = base64ToString($content), company = 'MMM'"]

    T --> G
    G -->|"runAfter: SUCCEEDED"| C
```

| Propiedad | `watch-271-mmm` | `watch-271-pmc` |
| --- | --- | --- |
| Carpeta vigilada | `QUERYRESPONSE\Inbound\MMM` | `QUERYRESPONSE\Inbound\PMC` |
| Condición de nombre | `endsWith(toLower(Name), '.x12')` | idéntica |
| `company` enviado | `"MMM"` | `"PMC"` |
| Conexión | `filesystem-7` | `filesystem-7` |

La separación por compañía es puramente por carpeta: la condición de nombre no discrimina
nada más que la extensión. Si un archivo de PMC se deja por error en la carpeta de MMM, se
procesará como MMM sin ninguna alerta.

## 4. Procesador: `x12-to-res-271`

Es el primer flujo con `foreach` anidados, porque un archivo X12 puede traer varios grupos
funcionales y cada grupo funcional varios transaction sets.

```mermaid
flowchart TB
    T["Trigger: When_an_HTTP_request_is_received"]
    CFC["Compose_File_Content<br/>triggerBody()?['fileContent'] sin cambios"]
    CC["Compose_Company<br/>toUpper(trim(company))"]
    DX["Decode_X12<br/>fallbackAgreementName {COMPANY}_ASES_Eleg_Request"]
    FE1["For_each_functional_groups<br/>interchange.functionalGroups"]
    FE2["For_each_transaction_sets<br/>items(...).transactionSets"]
    TX["Transform_XML<br/>Xslt: X12_271_Mapping_{COMPANY}.xslt<br/>content: xml(base64ToBinary(transactionSetContent))"]
    EFF["Encode_flat_file<br/>FlatFileEncoding con EligibilityResponse.xsd"]
    CF["Create_file<br/>QUERYRESPONSE / InProcess / {COMPANY}"]
    SR["Success_Response<br/>200 sin cuerpo"]

    T --> CFC
    T --> CC
    CFC --> DX
    CC --> DX
    DX --> FE1
    FE1 --> FE2
    FE2 --> TX --> EFF --> CF
    FE1 -->|"SUCCEEDED"| SR
```

Detalle de dependencias reales (`runAfter`):

| Acción | Depende de |
| --- | --- |
| `Compose_File_Content` | nada |
| `Compose_Company` | nada |
| `Decode_X12` | `Compose_File_Content` **y** `Compose_Company` |
| `For_each_functional_groups` | `Decode_X12` |
| `For_each_transaction_sets` | primera acción del `foreach` externo |
| `Transform_XML` | primera acción del `foreach` interno |
| `Encode_flat_file` | `Transform_XML` |
| `Create_file` | `Encode_flat_file` |
| `Success_Response` | `For_each_functional_groups` |

### 4.1 Navegación de la salida del `Decode_X12`

```
outputs('Decode_X12')?['body']?['interchange']?['functionalGroups']
    -> items('For_each_functional_groups')?['transactionSets']
        -> items('For_each_transaction_sets')?['transactionSetContent']?['$content']
```

El contenido de cada transaction set viene en base64 y hay que convertirlo a XML antes de
transformarlo:

```
@xml(base64ToBinary(items('For_each_transaction_sets')?['transactionSetContent']?['$content']))
```

**Hallazgo:** el `Create_file` está **dentro** del `foreach` interno y el nombre del archivo
solo depende de la compañía y la fecha. Si un interchange trae más de un transaction set (o
más de un grupo funcional), todas las iteraciones intentan escribir **exactamente el mismo
nombre de archivo**. La salida final depende del comportamiento del conector ante nombres
duplicados, no de la lógica del workflow. El diseño solo es correcto si ASES garantiza un
único ST por archivo.

**Hallazgo:** el flujo no revisa el resultado de la validación del agreement. `Decode_X12`
también produce `bad interchanges` / `bad transaction sets` y un acuse 997, pero el workflow
solo lee `interchange.functionalGroups`. Un transaction set rechazado por el agreement se
descarta en silencio.

### 4.2 Escritura del archivo de salida

```json
"folderPath": "@concat('\\\\1alexandria2.dev.pr.mmmhc.com\\manifiesto\\jobs\\ASES\\QUERYRESPONSE\\InProcess\\', toUpper(outputs('Compose_Company')))",
"name": "@concat(if(equals(toUpper(outputs('Compose_Company')), 'MMM'), '690320', '690330'), '_', toUpper(outputs('Compose_Company')), 'P_271_', formatDateTime(convertTimeZone(utcNow(), 'UTC', 'SA Western Standard Time'), 'yyyyMMdd'), '.res')"
```

El cuerpo es `@body('Encode_flat_file')`, el flat file completo.

| Compañía | Nombre generado el 8 de septiembre de 2026 |
| --- | --- |
| MMM | `690320_MMMP_271_20260908.res` |
| PMC | `690330_PMCP_271_20260908.res` |

## 5. Layout del flat file de salida

[EligibilityResponse.xsd](../IntegrationAccount/IntegrationAccount/Mappings/271/EligibilityResponse.xsd)

| Propiedad | Valor |
| --- | --- |
| Root | `Root` |
| Namespace | `http://IntegrationAccount.x005F_x0032_71.EligibilityResponse` |
| Estándar | Flat File, codepage 65001, carácter de relleno espacio |
| Estructura del root | `delimited`, delimitador `0x0A 0x0A` (**doble** LF), `child_order = prefix` |
| Estructura del registro | `positional`, justificación izquierda |
| Cardinalidad | `Record` de 0 a ilimitado |
| Longitud del registro | **269 caracteres** |

**Hallazgo:** el delimitador y el orden son distintos a los del request. El `.qry` usa un LF
simple en modo `postfix`; el `.res` usa **doble** LF en modo `prefix`. Es decir, el archivo
de respuesta empieza con dos saltos de línea y separa registros con dos saltos de línea.
Conviene confirmar con el equipo del legado que eso es lo que su parser espera, porque el
patrón asimétrico es sospechoso.

El registro tiene tres bloques lógicos:

**Bloque 1 — eco de la consulta (campos 1 a 10)**

| # | Campo | Posición | Largo | Origen |
| --- | --- | --- | --- | --- |
| 1 | `RecordType` | 1 | 1 | Literal `R` |
| 2 | `InquiryProcessDate` | 2–9 | 8 | `BHT04` del 271 |
| 3 | `InquirySocialSecurityNumber` | 10–18 | 9 | `REF02` con `REF01=SY` |
| 4 | `InquiryLastName` | 19–33 | 15 | `NM103` antes del pipe |
| 5 | `InquirySecondLastName` | 34–48 | 15 | `NM103` después del pipe |
| 6 | `InquiryFirstName` | 49–68 | 20 | `NM104` |
| 7 | `InquirySex` | 69 | 1 | `DMG03`: `M` a `1`, `F` a `2` |
| 8 | `InquiryDateOfBirth` | 70–77 | 8 | `DMG02` |
| 9 | `InquiryRegion` | 78 | 1 | Siempre vacío |
| 10 | `InquiryCarrier` | 79–80 | 2 | Literal `29` |

**Bloque 2 — datos de la persona según el payer (campos 11 a 16)**

| # | Campo | Posición | Largo | Origen |
| --- | --- | --- | --- | --- |
| 11 | `LastName` | 81–95 | 15 | Igual que el campo 4 |
| 12 | `SecondLastName` | 96–110 | 15 | Igual que el campo 5 |
| 13 | `FirstName` | 111–130 | 20 | Igual que el campo 6 |
| 14 | `Sex` | 131 | 1 | Igual que el campo 7 |
| 15 | `DateOfBirth` | 132–139 | 8 | Igual que el campo 8 |
| 16 | `Region` | 140 | 1 | Siempre vacío |

**Hallazgo:** los bloques 1 y 2 reciben exactamente los mismos valores. El schema está
diseñado para poder comparar lo consultado contra lo que devolvió el payer, pero el mapping
llena ambos bloques desde el mismo `NM1Loop1` del 271. La distinción es inútil hoy.

**Bloque 3 — resultado de elegibilidad (campos 17 a 31)**

| # | Campo | Posición | Largo | Origen |
| --- | --- | --- | --- | --- |
| 17 | `EligibilityIndicator` | 141 | 1 | `EB01`: `1` a `Y`, `6`/`06` a `N` |
| 18 | `PersonId` | 142–152 | 11 | `NM109` tal cual |
| 19 | `Filler1` | 153–154 | 2 | Siempre vacío |
| 20 | `MPI` | 155–167 | 13 | `NM109` rellenado con ceros a la izquierda |
| 21 | `Program` | 168 | 1 | Derivado de `EB05` |
| 22 | `EligibilityEffectiveDate` | 169–176 | 8 | Parte antes del guion en `DTP03` con `DTP01=307` |
| 23 | `EligibilityExpirationDate` | 177–184 | 8 | Parte después del guion |
| 24 | `ProcessDate` | 185–192 | 8 | `BHT04` |
| 25 | `MessageCode` | 193–198 | 6 | Siempre vacío |
| 26 | `DeductibleLevel` | 199 | 1 | Siempre vacío |
| 27 | `Municipality` | 200–203 | 4 | Del segmento `MSG` |
| 28 | `InquiryEffectiveDate` | 204–211 | 8 | Siempre vacío |
| 29 | `HealthCoverage` | 212–214 | 3 | Segmento entre pipes de `EB05` |
| 30 | `Filler2` | 215–219 | 5 | Siempre vacío |
| 31 | `Filler3` | 220–269 | 50 | `TRN02` del segmento con `TRN01=2` |

**Hallazgo:** siete campos nunca se llenan: `InquiryRegion`, `Region`, `MessageCode`,
`DeductibleLevel`, `InquiryEffectiveDate`, `Filler1` y `Filler2`. Los campos 9, 16, 25, 26 y
28 no son fillers por nombre, así que hay funcionalidad de negocio pendiente o el legado
simplemente los ignora.

**Hallazgo:** `PersonId` (11 posiciones) y `MPI` (13 posiciones) se alimentan del mismo
`NM109`. Si el `NM109` tiene más de 11 caracteres, `PersonId` queda truncado por el schema.

## 6. Mapping `X12_271_Mapping_MMM.btm`

| Árbol | Root | Referencia |
| --- | --- | --- |
| Origen (`SrcTree`) | `X12_00501_271` | `.\X12_00501_271.xsd` |
| Destino (`TrgTree`) | `Root` | `.\EligibilityResponse.xsd` |

`ConstantValues`: un solo valor, `R` hacia `Root/Record/RecordType`. Es redundante porque el
XSLT también emite `<RecordType>R</RecordType>`.

Toda la lógica está en un único functoid XSLT (ID 2) enlazado a `Root/Record`.

### 6.1 Selección del subscriber

```xml
<xsl:for-each select="/s0:X12_00501_271/s0:HLLoop1[s0:HL/HL03='22']">
```

Itera solo los loops HL de nivel subscriber (`HL03=22`), ignorando el Information Source
(`HL03=20`) y el Information Receiver (`HL03=21`). **Un registro `.res` por subscriber.**

**Hallazgo:** no se procesan los loops de dependiente (`HL03=23`). Es consistente con el 270,
que emite `HL04=0` en el subscriber declarando que no hay hijos.

### 6.2 Variables extraídas del EDI

| Variable | Expresión | Qué obtiene |
| --- | --- | --- |
| `$nm1Loop` | `s0:NM1Loop1[s0:NM1/NM101='IL'][1]` | Primer loop NM1 de tipo Insured/Subscriber |
| `$nm` | `$nm1Loop/s0:NM1[1]` | El segmento NM1 |
| `$nameRaw` | `normalize-space($nm/NM103)` | Apellido compuesto crudo |
| `$lastName` | `substring-before(concat($nameRaw, '\|'), '\|')` | Primer apellido (el `concat` evita el vacío cuando no hay pipe) |
| `$secondLastName` | `substring-after($nameRaw, '\|')` | Segundo apellido, vacío si no hay pipe |
| `$firstName` | `normalize-space($nm/NM104)` | Nombre |
| `$ssn` | `$nm1Loop/s0:REF[REF01='SY'][1]/REF02` | Seguro social |
| `$dmg` | `$nm1Loop/s0:DMG[1]` | Segmento demográfico |
| `$dob` | `$dmg/DMG02` | Fecha de nacimiento |
| `$gender` | `$dmg/DMG03` | Sexo (`M`, `F`, `U`) |
| `$mpiRaw` | `normalize-space($nm/NM109)` | Member ID |
| `$medicaid` | `$nm1Loop/s0:EBLoop1[s0:EB/EB04='MC'][1]` | **Primer loop de beneficios con `EB04=MC`** |
| `$eb01` | `$medicaid/s0:EB/EB01` | Código de estado del beneficio |
| `$eb05` | `$medicaid/s0:EB/EB05` | Descripción del plan |
| `$dtp307` | `$medicaid/s0:DTP_2[DTP01='307'][1]/DTP03` | Rango de fechas de elegibilidad |
| `$msg` | `$medicaid/s0:MSG[starts-with(MSG01,'Municipality')][1]/MSG01` | Mensaje con el municipio |
| `$munRaw` | `substring-after($msg, '-')` | Código de municipio |
| `$trn2` | `s0:TRN[TRN01='2'][1]/TRN02` | Trace asignado por el payer |

La deserialización del apellido compuesto es exactamente la operación inversa de la que hace
el mapping del 270 al construir `NM103` con el separador `|`.

### 6.3 Filtro de Medicaid (`EB04='MC'`)

```xml
<!-- Medicaid EB -->
<!-- Ignore Medicare MA / MB / OT -->
<xsl:variable name="medicaid" select="$nm1Loop/s0:EBLoop1[s0:EB/EB04='MC'][1]" />
```

Esta es la regla de negocio central del flujo. Un 271 de PRMMIS puede traer varios loops
`EBLoop1` (Medicare Part A `MA`, Part B `MB`, otros `OT`, Medicaid `MC`). El mapping se queda
**solo con el primer `MC`** y descarta el resto, porque este flujo reconcilia elegibilidad
Medicaid con ASES.

**Consecuencia:** si el 271 no trae ningún `EB04='MC'`, `$medicaid` queda vacío, `$eb01`
queda vacío y el registro sale con `EligibilityIndicator` vacío y sin programa, fechas,
municipio ni cobertura. No hay error ni marca de "no encontrado".

### 6.4 Reglas de derivación

| Campo destino | Regla exacta |
| --- | --- |
| `InquirySex` y `Sex` | `M` a `1`, `F` a `2`. **Sin `xsl:otherwise`**: cualquier otro valor (incluido `U`) deja el campo vacío |
| `EligibilityIndicator` | `EB01='1'` a `Y`; `EB01='6'` o `'06'` a `N`; cualquier otro código deja vacío |
| `MPI` | `substring(concat('0000000000000', $mpiRaw), string-length(...) - 12, 13)` — relleno de ceros a la izquierda hasta 13 |
| `Program` | Solo si `EB01='1'`: `contains($eb05,'TXIX')` a `1`, `contains($eb05,'CHIP')` a `2`, `contains($eb05,'CWLTH')` o `'Commonwealth'` a `3` |
| `EligibilityEffectiveDate` | Solo si `EB01='1'`: `substring-before(concat($dtp307,'-'), '-')` |
| `EligibilityExpirationDate` | Solo si `EB01='1'`: `substring-after($dtp307, '-')` |
| `Municipality` | Solo si `EB01='1'` y `$munRaw` no vacío: relleno de ceros a la izquierda hasta 4 |
| `HealthCoverage` | Solo si `EB01='1'`: `substring-before(concat(substring-after($eb05,'\|'),'\|'), '\|')`, es decir el **segundo** segmento de `EB05` separado por pipes |
| `Filler3` | `$trn2` |

**Hallazgo:** cinco campos (`Program`, las dos fechas, `Municipality`, `HealthCoverage`) solo
se llenan cuando `EB01='1'`. Para un afiliado inactivo (`EB01='6'`) el registro sale con
`EligibilityIndicator=N` y todo lo demás vacío, aunque el 271 sí traiga fechas históricas.

**Hallazgo:** `EB05` se usa como campo multivalor separado por pipes (programa en un
segmento, cobertura en otro). Igual que el `|` de `NM103` en el 270, es un acuerdo bilateral
con ASES que no está documentado en ningún lado del repositorio.

**Hallazgo:** `DTP03` se parsea con guion como separador de rango. El formato estándar de un
rango `RD8` en X12 usa `-`, así que es correcto, pero el mapping **no valida** que `DTP01`
sea de tipo rango: si viene una fecha simple `D8`, `EligibilityEffectiveDate` recibe la fecha
completa y `EligibilityExpirationDate` queda vacío.

## 7. Diferencias MMM vs PMC

**No hay ninguna.** `X12_271_Mapping_MMM.btm` y `X12_271_Mapping_PMC.btm` son idénticos byte
a byte.

En los workflows, la única diferencia es la carpeta vigilada y el literal `company`, que
solo afecta el nombre del mapa (que resuelve a dos archivos iguales), el nombre del agreement
de fallback, la carpeta de salida y el prefijo del archivo.

**Hallazgo:** `InquiryCarrier` está fijo en `29` para las dos compañías. Si PMC necesita otro
código de carrier, hoy no está implementado. Que los dos mapas sean idénticos sugiere que se
duplicaron "por simetría" con el 270 sin que hubiera una diferencia real de negocio; una sola
copia del mapa evitaría el riesgo de desincronización.

## 8. Puntos de falla conocidos

| Escenario | Comportamiento actual |
| --- | --- |
| Interchange con varios transaction sets | Todas las iteraciones escriben el mismo nombre de archivo |
| Transaction set rechazado por el agreement | Se descarta en silencio; el workflow no lee `badInterchanges` |
| 271 sin `EB04='MC'` | Registro con elegibilidad vacía, sin error |
| 271 sin loop `HL03=22` | El `for-each` no itera y el `.res` queda sin registros (`Record` admite `minOccurs=0`) |
| `DMG03` con valor `U` | `Sex` e `InquirySex` quedan vacíos |
| `EB01` distinto de `1`, `6`, `06` | `EligibilityIndicator` vacío |
| `NM103` sin pipe | `$secondLastName` vacío, correcto |
| Ya existe un archivo con el mismo nombre del día | Depende del conector File System |
| Archivo de PMC en la carpeta de MMM | Se procesa como MMM sin alerta |
